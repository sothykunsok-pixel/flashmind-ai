import express from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';
import { aiStatus } from './ai.js';
import authRoutes from './routes/auth.js';
import deckRoutes from './routes/decks.js';
import studyRoutes from './routes/study.js';
import aiRoutes from './routes/ai.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(express.json({ limit: '5mb' }));
app.use(cookieParser());
app.use(
  cors({
    origin: (origin, cb) => cb(null, true),
    credentials: true,
  }),
);

app.get('/api/health', (_req, res) => res.json({ ok: true, ai: aiStatus(), time: new Date().toISOString() }));

app.use('/api/auth', authRoutes);
app.use('/api', deckRoutes);
app.use('/api', studyRoutes);
app.use('/api', aiRoutes);

app.use('/api', (_req, res) => res.status(404).json({ error: 'Endpoint not found.' }));

// ── serve the built frontend (npm run build) ─────────────────
const dist = path.join(__dirname, '..', 'web-dist');
if (fs.existsSync(dist)) {
  app.use(
    express.static(dist, {
      index: false,
      maxAge: '1h',
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache');
      },
    }),
  );
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.setHeader('Cache-Control', 'no-cache');
    res.sendFile(path.join(dist, 'index.html'));
  });
} else {
  app.get('/', (_req, res) =>
    res
      .status(200)
      .send(
        '<pre style="font:14px ui-monospace;padding:2rem;line-height:1.6">FlashMind AI API is running.\n\n' +
          'The frontend is not built yet. Run:\n  npm run dev     → http://localhost:5173\n' +
          '  npm run build && npm start  → http://localhost:4000</pre>',
      ),
  );
}

// ── error handling ──────────────────────────────────────────
app.use((err, _req, res, _next) => {
  if (err?.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: `File too large (max ${config.maxUploadMb} MB).` });
  }
  console.error('[server error]', err);
  res.status(err.status || 500).json({ error: err.message || 'Something went wrong on the server.' });
});

const server = app.listen(config.port, () => {
  const status = aiStatus();
  console.log(`\n  \x1b[35mFlashMind AI\x1b[0m api → http://localhost:${config.port}`);
  console.log(`  AI mode: ${status.mode}${status.configured ? ` (${status.model} @ ${status.providerHost})` : ' — set AI_API_KEY in .env for live generation'}`);
  if (!fs.existsSync(dist)) console.log('  Frontend: run `npm run dev` (http://localhost:5173) or `npm run build`\n');
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => server.close(() => process.exit(0)));
}

export default app;
