import test from 'node:test';
import assert from 'node:assert/strict';
import { schedule } from '../routes/study.js';
import { extractJson, sanitizeCards, sanitizeQuiz, demoCards } from '../ai.js';
import { parseCsv, toCsv, slugify, isEmail } from '../utils.js';

test('scheduler: "again" resets the interval and lowers ease', () => {
  const next = schedule({ ease: 2.5, interval_days: 10, reps: 3, lapses: 0 }, 'again');
  assert.equal(next.interval, 0);
  assert.equal(next.reps, 0);
  assert.equal(next.lapses, 1);
  assert.ok(next.ease < 2.5);
  assert.ok(next.dueMinutes > 0);
});

test('scheduler: "easy" grows the interval and raises ease', () => {
  const next = schedule({ ease: 2.5, interval_days: 3, reps: 2, lapses: 0 }, 'easy');
  assert.ok(next.interval > 3);
  assert.ok(next.ease > 2.5);
  assert.equal(next.reps, 3);
});

test('scheduler: ease is clamped', () => {
  assert.ok(schedule({ ease: 1.3, interval_days: 1, reps: 1, lapses: 0 }, 'again').ease >= 1.3);
  assert.ok(schedule({ ease: 3.2, interval_days: 1, reps: 1, lapses: 0 }, 'easy').ease <= 3.2);
});

test('extractJson handles fenced JSON and surrounding prose', () => {
  const fenced = '```json\n{"cards":[{"question":"Q","answer":"A"}]}\n```';
  assert.equal(extractJson(fenced).cards.length, 1);
  const chatty = 'Sure! Here you go: {"cards":[{"question":"Q {x}","answer":"A"}]} hope that helps';
  assert.equal(extractJson(chatty).cards[0].question, 'Q {x}');
});

test('sanitizeCards drops duplicates and empty entries, caps the count', () => {
  const raw = {
    cards: [
      { question: 'What is ATP?', answer: 'Energy currency' },
      { question: 'what is atp?', answer: 'dup' },
      { question: '', answer: 'empty' },
      { question: 'Second?', answer: 'Two', difficulty: 'HARD' },
      { question: 'Third?', answer: 'Three' },
    ],
  };
  const cards = sanitizeCards(raw, 2, 'easy');
  assert.equal(cards.length, 2);
  assert.equal(cards[0].question, 'What is ATP?');
  assert.equal(cards[1].difficulty, 'hard');
});

test('sanitizeQuiz repairs a bad multiple-choice answerIndex', () => {
  const questions = sanitizeQuiz(
    {
      questions: [
        { type: 'multiple_choice', question: 'Pick one', options: ['a', 'b', 'c'], answerIndex: 9, answer: 'c' },
      ],
    },
    5,
    'mixed',
  );
  assert.equal(questions.length, 1);
  assert.equal(questions[0].answerIndex, 2);
});

test('demoCards always returns usable cards', () => {
  const cards = demoCards({ topic: 'Photosynthesis', material: '', count: 5, difficulty: 'medium' });
  assert.ok(cards.length > 0);
  for (const c of cards) {
    assert.ok(c.question.length > 5);
    assert.ok(c.answer.length > 0);
  }
});

test('csv round-trip survives quotes, commas and newlines', () => {
  const cards = [
    { question: 'What is "osmosis"?', answer: 'Water moves,\nacross a membrane', explanation: 'x', difficulty: 'easy' },
  ];
  const rows = parseCsv(toCsv(cards));
  assert.deepEqual(rows[0], ['question', 'answer', 'explanation', 'difficulty']);
  assert.equal(rows[1][0], 'What is "osmosis"?');
  assert.equal(rows[1][1], 'Water moves,\nacross a membrane');
});

test('slugify and isEmail', () => {
  assert.match(slugify('Cell Biology — Chapter 7!'), /^cell-biology-chapter-7-[0-9a-f]{8}$/);
  assert.ok(isEmail('a@b.co'));
  assert.ok(!isEmail('nope'));
});
