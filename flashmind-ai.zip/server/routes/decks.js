import express from 'express';
import multer from 'multer';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { all, one, run, touchDeck } from '../db.js';
import { authenticate, optionalAuth } from '../auth.js';
import { slugify, parseCsv, toCsv } from '../utils.js';
import { generateFlashcards, aiStatus } from '../ai.js';

const router = express.Router();
const upload = multer({
  dest: path.join(os.tmpdir(), 'flashmind-uploads'),
  limits: { fileSize: 10 * 1024 * 1024 },
});

const DECK_SELECT = `
  SELECT d.*,
    (SELECT COUNT(*) FROM cards c WHERE c.deck_id = d.id) AS card_count,
    (SELECT COUNT(*) FROM cards c WHERE c.deck_id = d.id AND c.reps > 0) AS studied_count,
    (SELECT COUNT(*) FROM cards c WHERE c.deck_id = d.id AND c.interval_days >= 1 AND c.last_grade IN ('hard','easy')) AS mastered_count,
    (SELECT COUNT(*) FROM cards c WHERE c.deck_id = d.id AND c.due_at <= datetime('now')) AS due_count,
    (SELECT COUNT(*) FROM cards c WHERE c.deck_id = d.id AND c.last_grade = 'again') AS struggle_count
  FROM decks d`;

const mapDeck = (d) => ({
  id: d.id,
  title: d.title,
  subject: d.subject,
  description: d.description,
  language: d.language,
  difficulty: d.difficulty,
  sourceType: d.source_type,
  folderId: d.folder_id,
  isPublic: Boolean(d.is_public),
  shareSlug: d.share_slug,
  createdAt: d.created_at,
  updatedAt: d.updated_at,
  lastStudiedAt: d.last_studied_at,
  cardCount: d.card_count ?? 0,
  studiedCount: d.studied_count ?? 0,
  masteredCount: d.mastered_count ?? 0,
  dueCount: d.due_count ?? 0,
  struggleCount: d.struggle_count ?? 0,
  progress: d.card_count ? Math.round(((d.mastered_count || 0) / d.card_count) * 100) : 0,
});

const mapCard = (c) => ({
  id: c.id,
  deckId: c.deck_id,
  question: c.question,
  answer: c.answer,
  explanation: c.explanation,
  difficulty: c.difficulty,
  ease: c.ease,
  intervalDays: c.interval_days,
  dueAt: c.due_at,
  reps: c.reps,
  lapses: c.lapses,
  lastGrade: c.last_grade,
  createdAt: c.created_at,
});

const ownsDeck = (deckId, userId) =>
  one('SELECT * FROM decks WHERE id = ? AND user_id = ?', Number(deckId), userId);

/* ───────────────────────────── folders ───────────────────────────── */

router.get('/folders', authenticate, (req, res) => {
  const rows = all(
    `SELECT f.*, (SELECT COUNT(*) FROM decks d WHERE d.folder_id = f.id) AS deck_count
     FROM folders f WHERE f.user_id = ? ORDER BY f.name COLLATE NOCASE`,
    req.userId,
  );
  res.json({
    folders: rows.map((f) => ({ id: f.id, name: f.name, color: f.color, deckCount: f.deck_count })),
  });
});

router.post('/folders', authenticate, (req, res) => {
  const name = String(req.body?.name || '').trim();
  if (!name) return res.status(400).json({ error: 'Folder name is required.' });
  const color = String(req.body?.color || '#8b5cf6').slice(0, 20);
  const { lastInsertRowid } = run(
    'INSERT INTO folders (user_id, name, color) VALUES (?, ?, ?)',
    req.userId,
    name.slice(0, 60),
    color,
  );
  const f = one('SELECT * FROM folders WHERE id = ?', Number(lastInsertRowid));
  res.status(201).json({ folder: { id: f.id, name: f.name, color: f.color, deckCount: 0 } });
});

router.patch('/folders/:id', authenticate, (req, res) => {
  const folder = one('SELECT * FROM folders WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!folder) return res.status(404).json({ error: 'Folder not found.' });
  const name = String(req.body?.name ?? folder.name).trim().slice(0, 60);
  const color = String(req.body?.color ?? folder.color).slice(0, 20);
  run('UPDATE folders SET name = ?, color = ? WHERE id = ?', name, color, folder.id);
  res.json({ ok: true });
});

router.delete('/folders/:id', authenticate, (req, res) => {
  const folder = one('SELECT * FROM folders WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!folder) return res.status(404).json({ error: 'Folder not found.' });
  run('DELETE FROM folders WHERE id = ?', folder.id);
  res.json({ ok: true });
});

/* ────────────────────────────── decks ────────────────────────────── */

router.get('/decks', authenticate, (req, res) => {
  const search = String(req.query.search || '').trim();
  const subject = String(req.query.subject || '').trim();
  const folder = req.query.folder;

  const where = ['d.user_id = ?'];
  const params = [req.userId];
  if (search) {
    where.push('(d.title LIKE ? OR d.subject LIKE ? OR d.description LIKE ?)');
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (subject && subject !== 'All') {
    where.push('d.subject = ?');
    params.push(subject);
  }
  if (folder === 'none') where.push('d.folder_id IS NULL');
  else if (folder) {
    where.push('d.folder_id = ?');
    params.push(Number(folder));
  }

  const rows = all(
    `${DECK_SELECT} WHERE ${where.join(' AND ')} ORDER BY COALESCE(d.last_studied_at, d.updated_at) DESC, d.id DESC`,
    ...params,
  );
  const subjects = all(
    'SELECT DISTINCT subject FROM decks WHERE user_id = ? ORDER BY subject COLLATE NOCASE',
    req.userId,
  ).map((r) => r.subject);

  res.json({ decks: rows.map(mapDeck), subjects });
});

router.post('/decks', authenticate, (req, res) => {
  const title = String(req.body?.title || '').trim();
  if (!title) return res.status(400).json({ error: 'Deck title is required.' });
  const cards = Array.isArray(req.body?.cards) ? req.body.cards : [];
  const folderId = req.body?.folderId ? Number(req.body.folderId) : null;

  const deck = createDeck(req.userId, {
    title,
    subject: req.body?.subject,
    description: req.body?.description,
    language: req.body?.language,
    difficulty: req.body?.difficulty,
    sourceType: req.body?.sourceType,
    folderId: folderId && one('SELECT id FROM folders WHERE id = ? AND user_id = ?', folderId, req.userId) ? folderId : null,
  });
  cards.forEach((c, i) => insertCard(deck.id, c, i));
  res.status(201).json({ deck: getDeck(deck.id, req.userId) });
});

function createDeck(userId, data) {
  const { lastInsertRowid } = run(
    `INSERT INTO decks (user_id, folder_id, title, subject, description, language, difficulty, source_type)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    userId,
    data.folderId ?? null,
    String(data.title || 'Untitled deck').slice(0, 160),
    String(data.subject || 'General').slice(0, 80),
    String(data.description || '').slice(0, 600),
    String(data.language || 'English').slice(0, 40),
    ['easy', 'medium', 'hard'].includes(String(data.difficulty)) ? data.difficulty : 'medium',
    String(data.sourceType || 'manual').slice(0, 20),
  );
  return one('SELECT * FROM decks WHERE id = ?', Number(lastInsertRowid));
}

function insertCard(deckId, card, position = 0) {
  const question = String(card?.question ?? '').trim();
  const answer = String(card?.answer ?? '').trim();
  if (!question || !answer) return null;
  const { lastInsertRowid } = run(
    `INSERT INTO cards (deck_id, question, answer, explanation, difficulty, position)
     VALUES (?, ?, ?, ?, ?, ?)`,
    deckId,
    question.slice(0, 600),
    answer.slice(0, 2000),
    String(card?.explanation || '').slice(0, 800),
    ['easy', 'medium', 'hard'].includes(String(card?.difficulty)) ? card.difficulty : 'medium',
    position,
  );
  return Number(lastInsertRowid);
}

function getDeck(deckId, userId) {
  const row = one(`${DECK_SELECT} WHERE d.id = ? AND d.user_id = ?`, Number(deckId), userId);
  return row ? mapDeck(row) : null;
}

router.get('/decks/:id', authenticate, (req, res) => {
  const deck = ownsDeck(req.params.id, req.userId);
  if (!deck) return res.status(404).json({ error: 'Deck not found.' });
  const cards = all('SELECT * FROM cards WHERE deck_id = ? ORDER BY position, id', deck.id);
  res.json({ deck: getDeck(deck.id, req.userId), cards: cards.map(mapCard) });
});

router.patch('/decks/:id', authenticate, (req, res) => {
  const deck = ownsDeck(req.params.id, req.userId);
  if (!deck) return res.status(404).json({ error: 'Deck not found.' });

  const body = req.body || {};
  const fields = [];
  const values = [];
  const str = (key, col, max) => {
    if (body[key] === undefined) return;
    fields.push(`${col} = ?`);
    values.push(String(body[key] ?? '').slice(0, max));
  };
  str('title', 'title', 160);
  str('subject', 'subject', 80);
  str('description', 'description', 600);
  str('language', 'language', 40);
  if (body.difficulty !== undefined && ['easy', 'medium', 'hard'].includes(body.difficulty)) {
    fields.push('difficulty = ?');
    values.push(body.difficulty);
  }
  if (body.folderId !== undefined) {
    const fid = body.folderId ? Number(body.folderId) : null;
    const valid = fid && one('SELECT id FROM folders WHERE id = ? AND user_id = ?', fid, req.userId);
    fields.push('folder_id = ?');
    values.push(valid ? fid : null);
  }
  if (body.isPublic !== undefined) {
    fields.push('is_public = ?');
    values.push(body.isPublic ? 1 : 0);
    const slug = deck.share_slug || slugify(body.title || deck.title);
    fields.push('share_slug = ?');
    values.push(slug);
  }
  if (body.title !== undefined && !String(body.title).trim()) {
    return res.status(400).json({ error: 'Deck title cannot be empty.' });
  }
  if (!fields.length) return res.status(400).json({ error: 'Nothing to update.' });

  fields.push("updated_at = datetime('now')");
  run(`UPDATE decks SET ${fields.join(', ')} WHERE id = ?`, ...values, deck.id);
  res.json({ deck: getDeck(deck.id, req.userId) });
});

router.delete('/decks/:id', authenticate, (req, res) => {
  const deck = ownsDeck(req.params.id, req.userId);
  if (!deck) return res.status(404).json({ error: 'Deck not found.' });
  run('DELETE FROM decks WHERE id = ?', deck.id);
  res.json({ ok: true });
});

router.post('/decks/:id/duplicate', authenticate, (req, res) => {
  const deck = ownsDeck(req.params.id, req.userId);
  if (!deck) return res.status(404).json({ error: 'Deck not found.' });
  const copy = createDeck(req.userId, {
    ...deck,
    title: `${deck.title} (copy)`,
    folderId: deck.folder_id,
    sourceType: deck.source_type,
  });
  const cards = all('SELECT * FROM cards WHERE deck_id = ? ORDER BY position, id', deck.id);
  cards.forEach((c, i) => insertCard(copy.id, c, i));
  res.status(201).json({ deck: getDeck(copy.id, req.userId) });
});

router.post('/decks/:id/expand', authenticate, async (req, res, next) => {
  try {
    const deck = ownsDeck(req.params.id, req.userId);
    if (!deck) return res.status(404).json({ error: 'Deck not found.' });
    const count = Math.max(1, Math.min(30, Number(req.body?.count || 5)));
    const existing = all('SELECT question, answer FROM cards WHERE deck_id = ?', deck.id);
    const material = String(req.body?.material || '').trim();
    const source = material || existing.map((c) => `Q: ${c.question}\nA: ${c.answer}`).join('\n\n');

    const { cards, demo } = await generateFlashcards({
      topic: deck.title,
      material: source,
      mode: 'source',
      count,
      difficulty: deck.difficulty,
      language: deck.language,
      exclude: existing.map((c) => c.question),
    });

    const start = existing.length;
    const inserted = [];
    cards.forEach((c, i) => {
      const id = insertCard(deck.id, c, start + i);
      if (id) inserted.push(id);
    });
    touchDeck(deck.id);
    const saved = inserted.length
      ? all(`SELECT * FROM cards WHERE id IN (${inserted.map(() => '?').join(',')})`, ...inserted).map(mapCard)
      : [];
    res.json({ cards: saved, demo, added: saved.length });
  } catch (err) {
    next(err);
  }
});

/* ────────────────────────────── cards ────────────────────────────── */

router.get('/decks/:id/cards', authenticate, (req, res) => {
  const deck = ownsDeck(req.params.id, req.userId);
  if (!deck) return res.status(404).json({ error: 'Deck not found.' });
  const cards = all('SELECT * FROM cards WHERE deck_id = ? ORDER BY position, id', deck.id);
  res.json({ cards: cards.map(mapCard) });
});

router.post('/decks/:id/cards', authenticate, (req, res) => {
  const deck = ownsDeck(req.params.id, req.userId);
  if (!deck) return res.status(404).json({ error: 'Deck not found.' });
  if (!String(req.body?.question || '').trim() || !String(req.body?.answer || '').trim()) {
    return res.status(400).json({ error: 'Both a question and an answer are required.' });
  }
  const max = one('SELECT COALESCE(MAX(position), -1) AS p FROM cards WHERE deck_id = ?', deck.id).p;
  const id = insertCard(deck.id, req.body, max + 1);
  touchDeck(deck.id);
  res.status(201).json({ card: mapCard(one('SELECT * FROM cards WHERE id = ?', id)) });
});

router.patch('/cards/:id', authenticate, (req, res) => {
  const card = one(
    `SELECT c.* FROM cards c JOIN decks d ON d.id = c.deck_id
     WHERE c.id = ? AND d.user_id = ?`,
    Number(req.params.id),
    req.userId,
  );
  if (!card) return res.status(404).json({ error: 'Card not found.' });

  const fields = [];
  const values = [];
  for (const [key, col, max] of [
    ['question', 'question', 600],
    ['answer', 'answer', 2000],
    ['explanation', 'explanation', 800],
  ]) {
    if (req.body?.[key] !== undefined) {
      const v = String(req.body[key]).slice(0, max);
      if (!v.trim()) return res.status(400).json({ error: 'Question and answer cannot be empty.' });
      fields.push(`${col} = ?`);
      values.push(v);
    }
  }
  if (req.body?.difficulty !== undefined && ['easy', 'medium', 'hard'].includes(req.body.difficulty)) {
    fields.push('difficulty = ?');
    values.push(req.body.difficulty);
  }
  if (req.body?.resetProgress) {
    fields.push("ease = 2.5, interval_days = 0, reps = 0, lapses = 0, last_grade = NULL, due_at = datetime('now')");
  }
  if (!fields.length) return res.status(400).json({ error: 'Nothing to update.' });

  run(`UPDATE cards SET ${fields.join(', ')} WHERE id = ?`, ...values, card.id);
  touchDeck(card.deck_id);
  res.json({ card: mapCard(one('SELECT * FROM cards WHERE id = ?', card.id)) });
});

router.delete('/cards/:id', authenticate, (req, res) => {
  const card = one(
    `SELECT c.* FROM cards c JOIN decks d ON d.id = c.deck_id
     WHERE c.id = ? AND d.user_id = ?`,
    Number(req.params.id),
    req.userId,
  );
  if (!card) return res.status(404).json({ error: 'Card not found.' });
  run('DELETE FROM cards WHERE id = ?', card.id);
  touchDeck(card.deck_id);
  res.json({ ok: true });
});

/* ─────────────────────── CSV import / export ─────────────────────── */

router.get('/decks/:id/export', authenticate, (req, res) => {
  const deck = ownsDeck(req.params.id, req.userId);
  if (!deck) return res.status(404).json({ error: 'Deck not found.' });
  const cards = all('SELECT * FROM cards WHERE deck_id = ? ORDER BY position, id', deck.id);
  const csv = toCsv(cards);
  const filename = `${deck.title.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.csv`;
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.send(csv);
});

router.post('/import/csv', authenticate, upload.single('file'), (req, res) => {
  let text = String(req.body?.csv || '');
  if (req.file) {
    text = fs.readFileSync(req.file.path, 'utf8');
    fs.promises.unlink(req.file.path).catch(() => {});
  }
  if (!text.trim()) return res.status(400).json({ error: 'No CSV content received.' });

  const rows = parseCsv(text);
  if (!rows.length) return res.status(400).json({ error: 'The CSV file is empty.' });

  const header = rows[0].map((h) => h.trim().toLowerCase());
  const hasHeader = header.includes('question') || header.includes('answer');
  const qi = hasHeader ? header.indexOf('question') : 0;
  const ai = hasHeader ? header.indexOf('answer') : 1;
  const ei = hasHeader ? header.indexOf('explanation') : -1;
  const di = hasHeader ? header.indexOf('difficulty') : -1;
  const dataRows = hasHeader ? rows.slice(1) : rows;

  const cards = dataRows
    .map((r) => ({
      question: String(r[qi] ?? '').trim(),
      answer: String(r[ai] ?? '').trim(),
      explanation: ei >= 0 ? String(r[ei] ?? '').trim() : '',
      difficulty: di >= 0 ? String(r[di] ?? '').trim().toLowerCase() : 'medium',
    }))
    .filter((c) => c.question && c.answer);

  if (!cards.length) {
    return res.status(400).json({ error: 'No valid rows found. Expected columns: question, answer.' });
  }
  if (cards.length > 1000) return res.status(400).json({ error: 'Maximum 1000 cards per import.' });

  const deck = createDeck(req.userId, {
    title: String(req.body?.title || 'Imported deck').slice(0, 160),
    subject: req.body?.subject || 'General',
    sourceType: 'import',
  });
  cards.forEach((c, i) => insertCard(deck.id, c, i));
  res.status(201).json({ deck: getDeck(deck.id, req.userId), imported: cards.length });
});

/* ───────────────────────── public / sharing ───────────────────────── */

router.get('/public/decks', optionalAuth, (req, res) => {
  const q = String(req.query.q || '').trim();
  const subject = String(req.query.subject || '').trim();
  const where = ['d.is_public = 1'];
  const params = [];
  if (q) {
    where.push('(d.title LIKE ? OR d.subject LIKE ? OR d.description LIKE ?)');
    params.push(`%${q}%`, `%${q}%`, `%${q}%`);
  }
  if (subject && subject !== 'All') {
    where.push('d.subject = ?');
    params.push(subject);
  }
  const rows = all(
    `${DECK_SELECT} WHERE ${where.join(' AND ')} ORDER BY d.updated_at DESC LIMIT 60`,
    ...params,
  );
  const subjects = all('SELECT DISTINCT subject FROM decks WHERE is_public = 1 ORDER BY subject').map(
    (r) => r.subject,
  );
  res.json({
    decks: rows.map((d) => ({
      ...mapDeck(d),
      author: one('SELECT name FROM users WHERE id = ?', d.user_id)?.name || 'FlashMind user',
    })),
    subjects,
  });
});

router.get('/public/decks/:slug', optionalAuth, (req, res) => {
  const deck = one('SELECT * FROM decks WHERE share_slug = ? AND is_public = 1', String(req.params.slug));
  if (!deck) return res.status(404).json({ error: 'This shared deck is not available.' });
  const cards = all('SELECT * FROM cards WHERE deck_id = ? ORDER BY position, id', deck.id);
  res.json({
    deck: {
      ...mapDeck(one(`${DECK_SELECT} WHERE d.id = ?`, deck.id)),
      author: one('SELECT name FROM users WHERE id = ?', deck.user_id)?.name || 'FlashMind user',
    },
    cards: cards.map((c) => ({ id: c.id, question: c.question, answer: c.answer, explanation: c.explanation })),
  });
});

router.post('/public/decks/:slug/clone', authenticate, (req, res) => {
  const deck = one('SELECT * FROM decks WHERE share_slug = ? AND is_public = 1', String(req.params.slug));
  if (!deck) return res.status(404).json({ error: 'This shared deck is not available.' });
  const copy = createDeck(req.userId, { ...deck, title: `${deck.title}`, sourceType: 'shared' });
  const cards = all('SELECT * FROM cards WHERE deck_id = ? ORDER BY position, id', deck.id);
  cards.forEach((c, i) => insertCard(copy.id, c, i));
  res.status(201).json({ deck: getDeck(copy.id, req.userId) });
});

router.get('/meta/ai', (req, res) => res.json(aiStatus()));

export { createDeck, insertCard, mapDeck, mapCard, DECK_SELECT };
export default router;
