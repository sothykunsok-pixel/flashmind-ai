import express from 'express';
import rateLimit from 'express-rate-limit';
import { one, run } from '../db.js';
import {
  hashPassword,
  verifyPassword,
  signToken,
  setAuthCookie,
  clearAuthCookie,
  authenticate,
  randomToken,
} from '../auth.js';
import { isEmail } from '../utils.js';
import { config } from '../config.js';

const router = express.Router();

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 40,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please wait a few minutes and try again.' },
});

const publicUser = (u) => ({
  id: u.id,
  email: u.email,
  name: u.name,
  dailyGoal: u.daily_goal,
  theme: u.theme,
  remindersEnabled: Boolean(u.reminders_enabled),
  reminderTime: u.reminder_time,
  createdAt: u.created_at,
});

router.post('/register', authLimiter, (req, res) => {
  const name = String(req.body?.name || '').trim().slice(0, 80);
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');

  if (name.length < 2) return res.status(400).json({ error: 'Please enter your name.' });
  if (!isEmail(email)) return res.status(400).json({ error: 'Please enter a valid email address.' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  if (one('SELECT id FROM users WHERE email = ?', email)) {
    return res.status(409).json({ error: 'An account with that email already exists.' });
  }

  const { lastInsertRowid } = run(
    'INSERT INTO users (email, name, password_hash) VALUES (?, ?, ?)',
    email,
    name,
    hashPassword(password),
  );
  const user = one('SELECT * FROM users WHERE id = ?', Number(lastInsertRowid));
  setAuthCookie(res, signToken(user.id));
  res.status(201).json({ user: publicUser(user) });
});

router.post('/login', authLimiter, (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const user = one('SELECT * FROM users WHERE email = ?', email);
  if (!user || !verifyPassword(password, user.password_hash)) {
    return res.status(401).json({ error: 'Incorrect email or password.' });
  }
  setAuthCookie(res, signToken(user.id));
  res.json({ user: publicUser(user) });
});

router.post('/logout', (req, res) => {
  clearAuthCookie(res);
  res.json({ ok: true });
});

router.get('/me', authenticate, (req, res) => {
  const user = one('SELECT * FROM users WHERE id = ?', req.userId);
  if (!user) {
    clearAuthCookie(res);
    return res.status(401).json({ error: 'Not authenticated' });
  }
  res.json({ user: publicUser(user) });
});

router.patch('/profile', authenticate, (req, res) => {
  const fields = [];
  const values = [];
  const { name, dailyGoal, theme, remindersEnabled, reminderTime } = req.body || {};

  if (name !== undefined) {
    if (String(name).trim().length < 2) return res.status(400).json({ error: 'Name is too short.' });
    fields.push('name = ?');
    values.push(String(name).trim().slice(0, 80));
  }
  if (dailyGoal !== undefined) {
    const g = Math.max(1, Math.min(500, Number(dailyGoal) || 20));
    fields.push('daily_goal = ?');
    values.push(g);
  }
  if (theme !== undefined && ['light', 'dark', 'system'].includes(theme)) {
    fields.push('theme = ?');
    values.push(theme);
  }
  if (remindersEnabled !== undefined) {
    fields.push('reminders_enabled = ?');
    values.push(remindersEnabled ? 1 : 0);
  }
  if (reminderTime !== undefined) {
    if (!/^\d{2}:\d{2}$/.test(String(reminderTime))) return res.status(400).json({ error: 'Invalid reminder time.' });
    fields.push('reminder_time = ?');
    values.push(String(reminderTime));
  }
  if (!fields.length) return res.status(400).json({ error: 'Nothing to update.' });

  run(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`, ...values, req.userId);
  res.json({ user: publicUser(one('SELECT * FROM users WHERE id = ?', req.userId)) });
});

router.post('/change-password', authenticate, (req, res) => {
  const current = String(req.body?.currentPassword || '');
  const next = String(req.body?.newPassword || '');
  if (next.length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters.' });
  const user = one('SELECT * FROM users WHERE id = ?', req.userId);
  if (!verifyPassword(current, user.password_hash)) return res.status(400).json({ error: 'Current password is incorrect.' });
  run('UPDATE users SET password_hash = ? WHERE id = ?', hashPassword(next), req.userId);
  res.json({ ok: true });
});

/**
 * Password reset. No SMTP is configured out of the box, so the reset link is
 * written to the server log and returned as `devResetUrl` outside production.
 */
router.post('/forgot-password', authLimiter, (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const user = one('SELECT * FROM users WHERE email = ?', email);
  const generic = { message: 'If that email is registered, a password reset link has been sent.' };
  if (!user) return res.json(generic);

  const token = randomToken();
  const expires = new Date(Date.now() + 1000 * 60 * 30).toISOString().slice(0, 19).replace('T', ' ');
  run('UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?', token, expires, user.id);

  const base = config.appUrl || `${req.protocol}://${req.get('host')}`;
  const link = `${base}/reset-password?token=${token}`;
  console.log(`\n[password reset] ${user.email} → ${link}\n`);

  res.json(config.isProd ? generic : { ...generic, devResetUrl: link });
});

router.post('/reset-password', authLimiter, (req, res) => {
  const token = String(req.body?.token || '');
  const password = String(req.body?.password || '');
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  const user = one('SELECT * FROM users WHERE reset_token = ?', token);
  if (!user || !user.reset_expires || user.reset_expires < new Date().toISOString().slice(0, 19).replace('T', ' ')) {
    return res.status(400).json({ error: 'This reset link is invalid or has expired.' });
  }
  run(
    'UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?',
    hashPassword(password),
    user.id,
  );
  setAuthCookie(res, signToken(user.id));
  res.json({ user: publicUser(one('SELECT * FROM users WHERE id = ?', user.id)) });
});

export default router;
