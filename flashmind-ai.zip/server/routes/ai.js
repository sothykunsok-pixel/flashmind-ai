import express from 'express';
import multer from 'multer';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import rateLimit from 'express-rate-limit';
import { all, one } from '../db.js';
import { authenticate } from '../auth.js';
import { extractText } from '../parsers.js';
import { generateFlashcards, summarize, explainSimply, generateQuiz, aiStatus } from '../ai.js';
import { mapCard } from './decks.js';
import { config } from '../config.js';

const router = express.Router();

const upload = multer({
  dest: path.join(os.tmpdir(), 'flashmind-uploads'),
  limits: { fileSize: config.maxUploadMb * 1024 * 1024 },
});

const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'You are generating very fast — please wait a minute and try again.' },
});

function fail(res, err) {
  const status = err.status === 429 ? 429 : err.status >= 500 ? 502 : 502;
  res.status(status).json({
    error: err.message || 'AI generation failed.',
    retryable: true,
    hint: /API key|401|403/.test(err.message || '')
      ? 'Check AI_API_KEY / AI_BASE_URL / AI_MODEL in your .env file.'
      : 'You can retry — or switch to Demo mode in Settings.',
  });
}

router.get('/ai/status', (req, res) => res.json(aiStatus()));

/** Upload a PDF / DOCX / TXT and get plain text back for the generator. */
router.post('/upload', authenticate, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded.' });
  try {
    const text = await extractText(req.file);
    if (!text.trim()) {
      return res.status(422).json({
        error: 'No readable text found in that file (it may be a scanned image PDF).',
      });
    }
    res.json({
      text,
      chars: text.length,
      filename: req.file.originalname,
      truncated: text.length > 16000,
    });
  } catch (err) {
    res.status(422).json({ error: err.message || 'Could not read that file.' });
  } finally {
    fs.promises.unlink(req.file.path).catch(() => {});
  }
});

router.post('/ai/flashcards', authenticate, aiLimiter, async (req, res) => {
  try {
    const material = String(req.body?.material || '').trim();
    const topic = String(req.body?.topic || '').trim();
    const mode = req.body?.mode === 'topic' || (!material && topic) ? 'topic' : 'source';
    if (!material && !topic) {
      return res.status(400).json({ error: 'Add a topic or paste some study material first.' });
    }
    const count = [5, 10, 20, 30, 50].includes(Number(req.body?.count)) ? Number(req.body.count) : 10;

    const result = await generateFlashcards({
      topic: topic || req.body?.title || 'Study topic',
      material,
      mode,
      count,
      difficulty: ['easy', 'medium', 'hard'].includes(req.body?.difficulty) ? req.body.difficulty : 'medium',
      language: String(req.body?.language || 'English').slice(0, 40),
    });
    res.json({ ...result, status: aiStatus() });
  } catch (err) {
    console.error('[ai/flashcards]', err.message);
    fail(res, err);
  }
});

router.post('/ai/summarize', authenticate, aiLimiter, async (req, res) => {
  try {
    const material = String(req.body?.material || '').trim();
    if (material.length < 80) return res.status(400).json({ error: 'Add a bit more material to summarize.' });
    const result = await summarize({ material, language: String(req.body?.language || 'English') });
    res.json(result);
  } catch (err) {
    console.error('[ai/summarize]', err.message);
    fail(res, err);
  }
});

router.post('/ai/explain', authenticate, aiLimiter, async (req, res) => {
  try {
    const question = String(req.body?.question || '').trim();
    const answer = String(req.body?.answer || '').trim();
    if (!question || !answer) return res.status(400).json({ error: 'A question and answer are required.' });
    const result = await explainSimply({
      question,
      answer,
      language: String(req.body?.language || 'English'),
    });
    res.json(result);
  } catch (err) {
    console.error('[ai/explain]', err.message);
    fail(res, err);
  }
});

router.post('/ai/quiz', authenticate, aiLimiter, async (req, res) => {
  try {
    let cards = [];
    if (req.body?.deckId) {
      const deck = one('SELECT * FROM decks WHERE id = ? AND user_id = ?', Number(req.body.deckId), req.userId);
      if (!deck) return res.status(404).json({ error: 'Deck not found.' });
      cards = all('SELECT * FROM cards WHERE deck_id = ? ORDER BY position, id', deck.id).map(mapCard);
    } else if (Array.isArray(req.body?.cards)) {
      cards = req.body.cards
        .map((c) => ({ question: String(c?.question || ''), answer: String(c?.answer || '') }))
        .filter((c) => c.question && c.answer);
    }
    if (cards.length < 2) {
      return res.status(400).json({ error: 'This deck needs at least 2 cards to build a quiz.' });
    }
    const type = ['multiple_choice', 'true_false', 'fill_blank', 'short_answer', 'mixed'].includes(req.body?.type)
      ? req.body.type
      : 'mixed';
    const result = await generateQuiz({
      cards,
      type,
      count: Math.max(1, Math.min(30, Number(req.body?.count || 8))),
      language: String(req.body?.language || 'English'),
      deckTitle: String(req.body?.deckTitle || ''),
    });
    res.json(result);
  } catch (err) {
    console.error('[ai/quiz]', err.message);
    fail(res, err);
  }
});

export default router;
