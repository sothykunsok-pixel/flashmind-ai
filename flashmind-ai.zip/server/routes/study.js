import express from 'express';
import { all, one, run, touchDeck } from '../db.js';
import { authenticate } from '../auth.js';
import { mapCard, mapDeck, DECK_SELECT } from './decks.js';

const router = express.Router();

const GRADES = new Set(['again', 'hard', 'easy']);

/** Simplified SM-2 scheduler. */
export function schedule(card, grade) {
  let { ease = 2.5, interval_days: interval = 0, reps = 0, lapses = 0 } = card;
  let dueMinutes = 0;

  if (grade === 'again') {
    lapses += 1;
    ease = Math.max(1.3, ease - 0.2);
    interval = 0;
    reps = 0;
    dueMinutes = 10;
  } else if (grade === 'hard') {
    ease = Math.max(1.3, ease - 0.05);
    interval = interval < 1 ? 1 : Math.max(1, interval * 1.2);
    reps += 1;
  } else {
    ease = Math.min(3.2, ease + 0.1);
    interval = interval < 1 ? 3 : Math.max(1, interval * ease);
    reps += 1;
  }

  interval = Math.min(interval, 365);
  const due = new Date(Date.now() + (dueMinutes ? dueMinutes * 60000 : interval * 86400000));
  const dueAt = due.toISOString().slice(0, 19).replace('T', ' ');
  return { ease, interval, reps, lapses, dueAt, dueMinutes };
}

router.post('/study/review', authenticate, (req, res) => {
  const grade = String(req.body?.grade || '').toLowerCase();
  if (!GRADES.has(grade)) return res.status(400).json({ error: 'Grade must be again, hard or easy.' });

  const card = one(
    `SELECT c.* FROM cards c JOIN decks d ON d.id = c.deck_id
     WHERE c.id = ? AND d.user_id = ?`,
    Number(req.body?.cardId),
    req.userId,
  );
  if (!card) return res.status(404).json({ error: 'Card not found.' });

  const s = schedule(card, grade);
  run(
    'UPDATE cards SET ease = ?, interval_days = ?, reps = ?, lapses = ?, due_at = ?, last_grade = ? WHERE id = ?',
    s.ease,
    s.interval,
    s.reps,
    s.lapses,
    s.dueAt,
    grade,
    card.id,
  );
  run(
    'INSERT INTO reviews (user_id, deck_id, card_id, grade, correct) VALUES (?, ?, ?, ?, ?)',
    req.userId,
    card.deck_id,
    card.id,
    grade,
    grade === 'again' ? 0 : 1,
  );
  run("UPDATE decks SET last_studied_at = datetime('now') WHERE id = ?", card.deck_id);

  res.json({
    card: mapCard(one('SELECT * FROM cards WHERE id = ?', card.id)),
    nextDueIn: s.dueMinutes ? `${s.dueMinutes} minutes` : `${Math.round(s.interval)} day(s)`,
  });
});

router.get('/study/queue', authenticate, (req, res) => {
  const deckId = req.query.deckId ? Number(req.query.deckId) : null;
  const limit = Math.max(1, Math.min(200, Number(req.query.limit || 50)));
  const smart = String(req.query.smart || 'true') !== 'false';

  const where = ['d.user_id = ?'];
  const params = [req.userId];
  if (deckId) {
    where.push('c.deck_id = ?');
    params.push(deckId);
  }

  const order = smart
    ? `CASE WHEN c.due_at <= datetime('now') THEN 0 ELSE 1 END,
       c.lapses DESC, c.reps ASC, c.due_at ASC`
    : 'c.position, c.id';

  const rows = all(
    `SELECT c.*, d.title AS deck_title FROM cards c JOIN decks d ON d.id = c.deck_id
     WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT ?`,
    ...params,
    limit,
  );
  res.json({ cards: rows.map((c) => ({ ...mapCard(c), deckTitle: c.deck_title })) });
});

router.get('/stats', authenticate, (req, res) => {
  const user = one('SELECT * FROM users WHERE id = ?', req.userId);
  const deckCount = one('SELECT COUNT(*) AS n FROM decks WHERE user_id = ?', req.userId).n;
  const cardCount = one(
    'SELECT COUNT(*) AS n FROM cards c JOIN decks d ON d.id = c.deck_id WHERE d.user_id = ?',
    req.userId,
  ).n;

  const today = one(
    `SELECT COUNT(*) AS reviews, COALESCE(SUM(correct),0) AS correct
     FROM reviews WHERE user_id = ? AND date(created_at) = date('now')`,
    req.userId,
  );
  const studiedToday = one(
    `SELECT COUNT(DISTINCT card_id) AS n FROM reviews
     WHERE user_id = ? AND date(created_at) = date('now')`,
    req.userId,
  ).n;

  const totals = one(
    'SELECT COUNT(*) AS reviews, COALESCE(SUM(correct),0) AS correct FROM reviews WHERE user_id = ?',
    req.userId,
  );

  const dueToday = one(
    `SELECT COUNT(*) AS n FROM cards c JOIN decks d ON d.id = c.deck_id
     WHERE d.user_id = ? AND c.due_at <= datetime('now')`,
    req.userId,
  ).n;

  const mastered = one(
    `SELECT COUNT(*) AS n FROM cards c JOIN decks d ON d.id = c.deck_id
     WHERE d.user_id = ? AND c.interval_days >= 1 AND c.last_grade IN ('hard','easy')`,
    req.userId,
  ).n;

  // streak: consecutive days with at least one review, counting back from today
  const days = all(
    `SELECT DISTINCT date(created_at) AS d FROM reviews WHERE user_id = ? ORDER BY d DESC LIMIT 400`,
    req.userId,
  ).map((r) => r.d);
  const daySet = new Set(days);
  const iso = (dt) => dt.toISOString().slice(0, 10);
  const cursor = new Date();
  if (!daySet.has(iso(cursor))) cursor.setDate(cursor.getDate() - 1);
  let streak = 0;
  while (daySet.has(iso(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }

  const recent = all(
    `${DECK_SELECT} WHERE d.user_id = ? ORDER BY COALESCE(d.last_studied_at, d.updated_at) DESC LIMIT 4`,
    req.userId,
  ).map(mapDeck);

  const continueDeck = one(
    `${DECK_SELECT} WHERE d.user_id = ? AND d.last_studied_at IS NOT NULL
     ORDER BY d.last_studied_at DESC LIMIT 1`,
    req.userId,
  );

  const lastQuiz = one(
    `SELECT * FROM quiz_attempts WHERE user_id = ? ORDER BY id DESC LIMIT 1`,
    req.userId,
  );

  res.json({
    stats: {
      deckCount,
      cardCount,
      reviewsToday: today.reviews,
      correctToday: today.correct,
      studiedToday,
      dueToday,
      mastered,
      streak,
      dailyGoal: user.daily_goal,
      goalPercent: Math.min(100, Math.round((today.reviews / Math.max(1, user.daily_goal)) * 100)),
      totalReviews: totals.reviews,
      accuracy: totals.reviews ? Math.round((totals.correct / totals.reviews) * 100) : 0,
      lastQuiz: lastQuiz
        ? {
            id: lastQuiz.id,
            type: lastQuiz.quiz_type,
            total: lastQuiz.total,
            correct: lastQuiz.correct,
            createdAt: lastQuiz.created_at,
          }
        : null,
    },
    recentDecks: recent,
    continueDeck: continueDeck ? mapDeck(continueDeck) : null,
  });
});

router.get('/activity', authenticate, (req, res) => {
  const days = Math.max(1, Math.min(90, Number(req.query.days || 7)));
  const rows = all(
    `SELECT date(created_at) AS day, COUNT(*) AS reviews, COALESCE(SUM(correct),0) AS correct
     FROM reviews
     WHERE user_id = ? AND date(created_at) >= date('now', ?)
     GROUP BY day`,
    req.userId,
    `-${days - 1} days`,
  );
  const byDay = new Map(rows.map((r) => [r.day, r]));
  const out = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date();
    d.setUTCDate(d.getUTCDate() - i);
    const key = d.toISOString().slice(0, 10);
    const row = byDay.get(key);
    out.push({
      date: key,
      reviews: row?.reviews || 0,
      correct: row?.correct || 0,
      accuracy: row?.reviews ? Math.round((row.correct / row.reviews) * 100) : null,
    });
  }
  res.json({ activity: out });
});

router.post('/quiz/attempts', authenticate, (req, res) => {
  const total = Math.max(0, Math.min(200, Number(req.body?.total || 0)));
  const correct = Math.max(0, Math.min(total, Number(req.body?.correct || 0)));
  const deckId = req.body?.deckId ? Number(req.body.deckId) : null;
  if (deckId && !one('SELECT id FROM decks WHERE id = ? AND user_id = ?', deckId, req.userId)) {
    return res.status(404).json({ error: 'Deck not found.' });
  }
  const { lastInsertRowid } = run(
    'INSERT INTO quiz_attempts (user_id, deck_id, quiz_type, total, correct, details) VALUES (?, ?, ?, ?, ?, ?)',
    req.userId,
    deckId,
    String(req.body?.type || 'mixed').slice(0, 30),
    total,
    correct,
    JSON.stringify(Array.isArray(req.body?.details) ? req.body.details.slice(0, 100) : []),
  );
  res.status(201).json({ id: Number(lastInsertRowid) });
});

router.get('/quiz/attempts', authenticate, (req, res) => {
  const rows = all(
    `SELECT q.*, d.title AS deck_title FROM quiz_attempts q
     LEFT JOIN decks d ON d.id = q.deck_id
     WHERE q.user_id = ? ORDER BY q.id DESC LIMIT 25`,
    req.userId,
  );
  res.json({
    attempts: rows.map((r) => ({
      id: r.id,
      deckId: r.deck_id,
      deckTitle: r.deck_title,
      type: r.quiz_type,
      total: r.total,
      correct: r.correct,
      score: r.total ? Math.round((r.correct / r.total) * 100) : 0,
      createdAt: r.created_at,
    })),
  });
});

export default router;
