import { config, aiConfigured } from './config.js';

const MAX_SOURCE_CHARS = 16000;

export function aiStatus() {
  return {
    configured: aiConfigured(),
    mode: aiConfigured() ? 'live' : 'demo',
    model: aiConfigured() ? config.ai.model : 'demo-generator',
    providerHost: aiConfigured() ? new URL(config.ai.baseUrl).host : null,
  };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Balanced-brace JSON extraction that tolerates code fences and prose around the object. */
export function extractJson(text) {
  if (!text) throw new Error('Empty AI response');
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const src = fenced ? fenced[1] : text;
  const start = src.search(/[[{]/);
  if (start === -1) throw new Error('AI response contained no JSON');
  const open = src[start];
  const close = open === '{' ? '}' : ']';
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < src.length; i++) {
    const ch = src[i];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === '\\') esc = true;
      else if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') inStr = true;
    else if (ch === open) depth++;
    else if (ch === close) {
      depth--;
      if (depth === 0) return JSON.parse(src.slice(start, i + 1));
    }
  }
  throw new Error('AI response contained incomplete JSON');
}

async function callAI({ system, user, temperature = 0.4, maxTokens = 4000 }) {
  const body = {
    model: config.ai.model,
    temperature,
    max_tokens: maxTokens,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: user },
    ],
  };
  if (config.ai.jsonMode) body.response_format = { type: 'json_object' };

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), config.ai.timeoutMs);
  try {
    const res = await fetch(`${config.ai.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${config.ai.apiKey}`,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await res.text();
    if (!res.ok) {
      let detail = text.slice(0, 400);
      try {
        detail = JSON.parse(text)?.error?.message || detail;
      } catch {}
      const err = new Error(`AI provider error (${res.status}): ${detail}`);
      err.status = res.status;
      err.retryable = res.status === 429 || res.status >= 500;
      throw err;
    }
    const data = JSON.parse(text);
    const content = data?.choices?.[0]?.message?.content;
    if (!content) throw new Error('AI provider returned an empty response');
    return content;
  } catch (err) {
    if (err.name === 'AbortError') {
      const e = new Error(`AI request timed out after ${Math.round(config.ai.timeoutMs / 1000)}s`);
      e.retryable = true;
      throw e;
    }
    if (err.retryable === undefined) err.retryable = true;
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/** Calls the model and returns validated JSON, retrying transient failures and JSON repairs. */
async function askJson({ system, user, temperature, maxTokens = 4000, attempts = 3 }) {
  let lastErr;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      const raw = await callAI({
        system,
        user:
          attempt === 1
            ? user
            : `${user}\n\nIMPORTANT: Your previous reply was not valid JSON. Reply with ONLY a single valid JSON object, no prose, no code fences.`,
        temperature,
        maxTokens,
      });
      return extractJson(raw);
    } catch (err) {
      lastErr = err;
      const retryable = err.retryable !== false && attempt < attempts;
      if (!retryable) break;
      await sleep(700 * attempt * attempt);
    }
  }
  throw lastErr;
}

/* ──────────────────────────── prompts ──────────────────────────── */

const CARD_SCHEMA = `{
  "cards": [
    {
      "question": "clear, specific question (no more than 220 characters)",
      "answer": "concise, complete answer (no more than 480 characters)",
      "explanation": "optional one-sentence clarification or example, or empty string",
      "difficulty": "easy" | "medium" | "hard"
    }
  ]
}`;

function cardSystemPrompt({ difficulty, language, grounded }) {
  return `You are FlashMind, an expert instructional designer who writes high-quality spaced-repetition flashcards.

RULES:
1. Return ONLY valid JSON matching this schema: ${CARD_SCHEMA}
2. Produce exactly the number of cards requested by the user.
3. One atomic fact per card. Never combine two ideas in one question.
4. Questions must be self-contained (no "according to the text", no "in the passage above").
5. Answers must be concise, accurate and directly answer the question.
6. No duplicate or near-duplicate questions. Cover distinct concepts.
7. Difficulty target: ${difficulty}. Easy = recall of a single definition/fact. Medium = understanding or comparison. Hard = application, analysis or multi-step reasoning.
8. Write every question, answer and explanation in ${language}.
9. ${
    grounded
      ? 'GROUNDING IS STRICT: use ONLY facts, definitions and examples that appear in the supplied source material. Never invent names, numbers, dates or claims. If the source only supports fewer facts, return fewer cards rather than padding.'
      : 'You may use accurate general knowledge about the requested topic. Never invent specifics that are not true.'
  }
10. Where useful, include a short concrete example inside "explanation".
11. Escape quotes properly. Do not use markdown code fences.`;
}

function truncate(text) {
  const t = String(text || '').trim();
  if (t.length <= MAX_SOURCE_CHARS) return t;
  return `${t.slice(0, MAX_SOURCE_CHARS)}\n\n[...source truncated to ${MAX_SOURCE_CHARS} characters...]`;
}

/* ─────────────────────── flashcard generation ─────────────────────── */

export async function generateFlashcards({
  topic,
  material,
  count = 10,
  difficulty = 'medium',
  language = 'English',
  mode = 'source',
  exclude = [],
}) {
  const grounded = mode === 'source' && material && material.trim().length > 0;
  if (!aiConfigured()) {
    return { cards: demoCards({ topic, material, count, difficulty }), demo: true };
  }

  const user = [
    `Create ${count} flashcards.`,
    grounded
      ? `SOURCE MATERIAL (the only permitted source of facts):\n"""\n${truncate(material)}\n"""`
      : `TOPIC: ${topic || material}`,
    exclude.length
      ? `Do NOT repeat or rephrase any of these existing questions:\n${exclude
          .slice(0, 80)
          .map((q) => `- ${q}`)
          .join('\n')}`
      : '',
    `Remember: exactly ${count} cards, difficulty ${difficulty}, language ${language}, JSON only.`,
  ]
    .filter(Boolean)
    .join('\n\n');

  const data = await askJson({
    system: cardSystemPrompt({ difficulty, language, grounded }),
    user,
    temperature: difficulty === 'hard' ? 0.55 : 0.4,
    maxTokens: Math.min(8000, 400 + count * 220),
  });

  const cards = sanitizeCards(data, count, difficulty);
  if (!cards.length) throw new Error('The AI did not return any usable flashcards. Please try again.');
  return { cards, demo: false };
}

export function sanitizeCards(data, count, difficulty) {
  const raw = Array.isArray(data?.cards) ? data.cards : Array.isArray(data) ? data : [];
  const seen = new Set();
  const out = [];
  for (const c of raw) {
    const question = String(c?.question ?? c?.front ?? '').trim();
    const answer = String(c?.answer ?? c?.back ?? '').trim();
    if (question.length < 6 || answer.length < 1) continue;
    const key = question.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({
      question: question.slice(0, 400),
      answer: answer.slice(0, 1200),
      explanation: String(c?.explanation ?? c?.hint ?? '').slice(0, 600),
      difficulty: ['easy', 'medium', 'hard'].includes(String(c?.difficulty).toLowerCase())
        ? String(c.difficulty).toLowerCase()
        : difficulty,
    });
    if (out.length >= count) break;
  }
  return out;
}

/* ─────────────────────────── summarization ─────────────────────────── */

export async function summarize({ material, language = 'English' }) {
  if (!aiConfigured()) return { summary: demoSummary(material), demo: true };
  const data = await askJson({
    system: `You are FlashMind, a study assistant. Return ONLY JSON:
{"summary":"a compact 4-8 sentence overview","keyConcepts":[{"term":"...","definition":"..."}],"outline":["..."]}
Write in ${language}. Base everything strictly on the supplied material.`,
    user: `Summarize and extract the most important concepts from this study material:\n"""\n${truncate(material)}\n"""`,
    temperature: 0.3,
    maxTokens: 2000,
  });
  return {
    summary: String(data?.summary || demoSummary(material)),
    keyConcepts: Array.isArray(data?.keyConcepts)
      ? data.keyConcepts
          .map((k) => ({ term: String(k?.term || ''), definition: String(k?.definition || '') }))
          .filter((k) => k.term)
          .slice(0, 14)
      : [],
    outline: Array.isArray(data?.outline) ? data.outline.map(String).slice(0, 14) : [],
    demo: false,
  };
}

/* ─────────────────────────── explain simply ─────────────────────────── */

export async function explainSimply({ question, answer, language = 'English' }) {
  if (!aiConfigured()) {
    const first = String(answer || '')
      .split(/(?<=[.!?])\s+/)
      .slice(0, 2)
      .join(' ');
    return {
      explanation: `In simple words: ${first || answer}\n\nTip: read it aloud, then say it back in your own words without looking.`,
      demo: true,
    };
  }
  const data = await askJson({
    system: `You are a patient tutor. Return ONLY JSON: {"explanation":"..."}. Explain in plain ${language} at a level a motivated 14-year-old understands. Use a short analogy and at most one tiny example. Maximum 130 words. No markdown headings.`,
    user: `Question: ${question}\nAccepted answer: ${answer}\nExplain this simply.`,
    temperature: 0.5,
    maxTokens: 700,
  });
  return { explanation: String(data?.explanation || ''), demo: false };
}

/* ───────────────────────────── quiz ───────────────────────────── */

const QUIZ_SCHEMA = `{"questions":[
 {"type":"multiple_choice","question":"...","options":["A","B","C","D"],"answerIndex":0,"explanation":"..."},
 {"type":"true_false","question":"...","answer":true,"explanation":"..."},
 {"type":"fill_blank","question":"sentence containing ____ ","answer":"word","acceptedAnswers":["word"],"explanation":"..."},
 {"type":"short_answer","question":"...","answer":"model answer","acceptedKeywords":["key","terms"],"explanation":"..."}
]}`;

export async function generateQuiz({ cards, type = 'mixed', count = 8, language = 'English', deckTitle = '' }) {
  const safeCount = Math.max(1, Math.min(count, Math.max(1, cards.length)));
  if (!aiConfigured()) return { questions: demoQuiz({ cards, type, count: safeCount }), demo: true };

  const source = cards
    .slice(0, 60)
    .map((c, i) => `${i + 1}. Q: ${c.question}\n   A: ${c.answer}`)
    .join('\n');

  const data = await askJson({
    system: `You are FlashMind, an exam writer. Return ONLY JSON: ${QUIZ_SCHEMA}

RULES:
- "type" must be one of multiple_choice, true_false, fill_blank, short_answer.
- ${
      type === 'mixed'
        ? 'Mix the four types roughly evenly.'
        : `Every question must have type "${type}".`
    }
- multiple_choice: exactly 4 plausible options, exactly one correct, answerIndex is 0-3.
- true_false: "answer" is a boolean.
- fill_blank: exactly one ____ blank inside the question, answer is the missing word/phrase.
- short_answer: answer is a model answer of at most 25 words; acceptedKeywords are 1-5 essential words.
- Test only facts that the given cards support. No trick questions. Write in ${language}.
- No duplicate questions.`,
    user: `Deck: ${deckTitle}\nCreate ${safeCount} quiz questions from these flashcards:\n\n${source}`,
    temperature: 0.45,
    maxTokens: Math.min(6000, 500 + safeCount * 300),
  });

  const questions = sanitizeQuiz(data, safeCount, type);
  if (!questions.length) throw new Error('The AI did not return usable quiz questions. Please try again.');
  return { questions, demo: false };
}

export function sanitizeQuiz(data, count, type) {
  const raw = Array.isArray(data?.questions) ? data.questions : [];
  const out = [];
  for (const q of raw) {
    let qtype = String(q?.type || type).toLowerCase().replace(/\s+/g, '_');
    if (qtype === 'mixed') qtype = 'multiple_choice';
    if (!['multiple_choice', 'true_false', 'fill_blank', 'short_answer'].includes(qtype)) continue;
    if (type !== 'mixed' && qtype !== type) continue;
    const question = String(q?.question || '').trim();
    if (!question) continue;

    if (qtype === 'multiple_choice') {
      const options = Array.isArray(q.options) ? q.options.map((o) => String(o).trim()).filter(Boolean) : [];
      if (options.length < 3) continue;
      const opts = options.slice(0, 4);
      let answerIndex = Number(q.answerIndex);
      if (!Number.isInteger(answerIndex) || answerIndex < 0 || answerIndex >= opts.length) {
        const found = opts.findIndex((o) => o.toLowerCase() === String(q.answer || '').toLowerCase());
        answerIndex = found >= 0 ? found : 0;
      }
      out.push({ type: qtype, question, options: opts, answerIndex, explanation: String(q.explanation || '') });
    } else if (qtype === 'true_false') {
      const answer = typeof q.answer === 'boolean' ? q.answer : /^(true|yes|t)$/i.test(String(q.answer));
      out.push({ type: qtype, question, answer, explanation: String(q.explanation || '') });
    } else if (qtype === 'fill_blank') {
      const answer = String(q.answer || '').trim();
      if (!answer) continue;
      const accepted = Array.isArray(q.acceptedAnswers)
        ? q.acceptedAnswers.map(String).filter(Boolean)
        : [answer];
      out.push({
        type: qtype,
        question: question.includes('____') ? question : `${question} ____`,
        answer,
        acceptedAnswers: [...new Set([answer, ...accepted])].slice(0, 5),
        explanation: String(q.explanation || ''),
      });
    } else {
      const answer = String(q.answer || '').trim();
      if (!answer) continue;
      const keywords = Array.isArray(q.acceptedKeywords)
        ? q.acceptedKeywords.map(String).filter(Boolean)
        : answer.split(/\s+/).filter((w) => w.length > 3).slice(0, 4);
      out.push({ type: qtype, question, answer, acceptedKeywords: keywords.slice(0, 6), explanation: String(q.explanation || '') });
    }
    if (out.length >= count) break;
  }
  return out;
}

/* ══════════════════════════ DEMO MODE (no API key) ══════════════════════════
   A deterministic local generator so the whole product works without an AI key.
   Produces real study cards from the user's own text — clearly flagged as demo. */

const STOP = new Set(
  'the a an and or but if then than that this these those of in on at to for from by with as is are was were be been being it its into their there they we you he she his her our your not no can could should would may might must will shall do does did have has had which who whom whose what when where why how all any both each few more most other some such only own same so too very just also about above after again against because before below between during through under until up down out off over'.split(
    /\s+/,
  ),
);

function sentences(text) {
  return String(text || '')
    .replace(/\s+/g, ' ')
    .split(/(?<=[.!?])\s+(?=[A-Z0-9"“(])/g)
    .map((s) => s.trim())
    .filter((s) => s.length >= 45 && s.length <= 320);
}

function keyTerms(text) {
  const words = String(text || '').match(/[A-Za-z][A-Za-z'-]{3,}/g) || [];
  const freq = new Map();
  for (const w of words) {
    const k = w.toLowerCase();
    if (STOP.has(k)) continue;
    freq.set(k, (freq.get(k) || 0) + 1);
  }
  return [...freq.entries()].sort((a, b) => b[1] - a[1]).map(([w]) => w);
}

export function demoCards({ topic, material, count = 10, difficulty = 'medium' }) {
  const src = (material || '').trim();
  const out = [];
  const seen = new Set();

  if (src) {
    const sents = sentences(src);
    const terms = keyTerms(src);
    for (let i = 0; i < sents.length && out.length < count; i++) {
      const s = sents[i];
      const key = s.toLowerCase().replace(/[^a-z0-9]+/g, ' ').slice(0, 60);
      if (seen.has(key)) continue;
      seen.add(key);

      // prefer a "X is/are/means Y" definition pattern
      const def = s.match(/^(.{4,90}?)\s+(?:is|are|means|refers to|describes|represents|defines)\s+(.+)$/i);
      if (def && def[2].length > 25) {
        const subj = def[1].replace(/^(the|a|an)\s+/i, '').trim();
        const plural = /(?:[^s]s|ae|i)$/i.test(subj) && !/(?:ss|sis|us|ics|is|as|os)$/i.test(subj);
        out.push({
          question: `What ${plural ? 'are' : 'is'} ${subj}?`,
          answer: def[2].replace(/\.$/, '').trim(),
          explanation: 'Definition taken directly from your study material.',
          difficulty,
        });
        continue;
      }

      const term = terms.find((t) => new RegExp(`\\b${t}\\b`, 'i').test(s));
      if (term && s.length < 260) {
        const blanked = s.replace(new RegExp(`\\b${term}\\b`, 'i'), '____');
        out.push({
          question: `Fill in the blank: ${blanked}`,
          answer: term,
          explanation: 'Key term from your study material.',
          difficulty: 'easy',
        });
        continue;
      }

      const short = s.length > 170 ? `${s.slice(0, 167)}...` : s;
      out.push({
        question: `Complete the statement: "${short.replace(/\.$/, '')} ..."`,
        answer: s,
        explanation: 'Recall the full statement from your notes.',
        difficulty: 'medium',
      });
    }
  }

  if (!out.length) {
    const t = topic || 'this topic';
    const generic = [
      [`What is the core definition of ${t}?`, `A precise statement of what ${t} is and what it covers.`, 'Start with the formal definition, then one example.'],
      [`Why does ${t} matter in practice?`, `It explains how the main ideas of ${t} connect and where they are applied.`, ''],
      [`List the key components of ${t}.`, `The main parts or stages that make up ${t}.`, ''],
      [`Give a concrete example of ${t}.`, `A real, worked example that demonstrates ${t} in action.`, ''],
      [`What is a common misconception about ${t}?`, `A frequent misunderstanding and the correction.`, ''],
      [`How would you apply ${t} to a new problem?`, `Identify the situation, choose the right principle of ${t}, then reason step by step.`, ''],
      [`Which terms are essential vocabulary for ${t}?`, `The vocabulary you must be able to define from memory.`, ''],
      [`How do the parts of ${t} relate to each other?`, `Cause/effect or part/whole relationships between the main ideas.`, ''],
      [`What would you check to verify an answer about ${t}?`, `The assumptions and the definition each step relies on.`, ''],
      [`Summarise ${t} in two sentences.`, `A compact summary naming the main idea and its purpose.`, ''],
    ];
    for (let i = 0; i < Math.min(count, generic.length); i++) {
      out.push({ question: generic[i][0], answer: generic[i][1], explanation: generic[i][2], difficulty });
    }
  }

  return out.slice(0, count).map((c) => ({
    question: c.question,
    answer: c.answer,
    explanation: c.explanation || 'Demo mode: add AI_API_KEY to generate real AI flashcards from your material.',
    difficulty: c.difficulty || difficulty,
  }));
}

export function demoSummary(material) {
  const sents = sentences(material);
  const picked = sents.slice(0, 5).join(' ');
  const terms = keyTerms(material).slice(0, 10);
  return `${picked || 'Add study material to generate a summary.'}\n\nKey terms: ${terms.join(', ') || '—'}\n\n(Demo summary — connect AI_API_KEY for real AI summarization.)`;
}

export function demoQuiz({ cards, type, count }) {
  const pool = cards.filter((c) => c.question && c.answer);
  const types = ['multiple_choice', 'true_false', 'fill_blank', 'short_answer'];
  const out = [];

  const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();

  for (let i = 0; i < Math.min(count, pool.length); i++) {
    const card = pool[i];
    const qtype = type === 'mixed' ? types[i % types.length] : type;

    if (qtype === 'multiple_choice') {
      const distractors = pool
        .filter((c) => c.id !== card.id && norm(c.answer) !== norm(card.answer))
        .map((c) => c.answer)
        .slice(0, 12);
      const options = [card.answer, ...distractors].slice(0, 4);
      if (options.length < 3) continue;
      const shuffled = options.sort(() => Math.random() - 0.5);
      out.push({
        type: qtype,
        question: card.question,
        options: shuffled,
        answerIndex: shuffled.indexOf(card.answer),
        explanation: card.explanation || '',
      });
    } else if (qtype === 'true_false') {
      const isTrue = i % 2 === 0;
      const wrong = pool.find((c) => c.id !== card.id);
      if (!isTrue && !wrong) continue;
      out.push({
        type: qtype,
        question: isTrue
          ? `${card.question} — ${card.answer}`
          : `${card.question} — ${wrong.answer}`,
        answer: isTrue,
        explanation: isTrue ? card.explanation || '' : `The correct answer is: ${card.answer}`,
      });
    } else if (qtype === 'fill_blank') {
      const words = card.answer.split(/\s+/).filter((w) => w.length > 3);
      const target = words[0];
      if (!target) continue;
      const blanked = card.answer.replace(target, '____');
      out.push({
        type: qtype,
        question: `${card.question} → ${blanked}`,
        answer: target.replace(/[.,;:]$/, ''),
        acceptedAnswers: [target.replace(/[.,;:]$/, '')],
        explanation: card.explanation || '',
      });
    } else {
      out.push({
        type: qtype,
        question: card.question,
        answer: card.answer,
        acceptedKeywords: card.answer.split(/\s+/).filter((w) => w.length > 3).slice(0, 4),
        explanation: card.explanation || '',
      });
    }
    if (out.length >= count) break;
  }
  return out;
}
