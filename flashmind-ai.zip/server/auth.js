import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { config } from './config.js';

export const hashPassword = (pw) => bcrypt.hashSync(pw, 10);
export const verifyPassword = (pw, hash) => bcrypt.compareSync(pw, hash);

export const signToken = (userId) =>
  jwt.sign({ uid: userId }, config.jwtSecret, { expiresIn: config.jwtExpiresIn });

export const verifyToken = (token) => {
  try {
    const payload = jwt.verify(token, config.jwtSecret);
    return payload?.uid ? payload : null;
  } catch {
    return null;
  }
};

export const randomToken = () => crypto.randomBytes(32).toString('hex');

const COOKIE = 'fm_token';

export function setAuthCookie(res, token) {
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.cookieSecure,
    maxAge: 1000 * 60 * 60 * 24 * 7,
    path: '/',
  });
}

export function clearAuthCookie(res) {
  res.clearCookie(COOKIE, { path: '/' });
}

/** Extracts the JWT from the httpOnly cookie or an Authorization: Bearer header. */
function readToken(req) {
  const header = req.headers.authorization || '';
  if (header.startsWith('Bearer ')) return header.slice(7).trim();
  if (req.cookies?.[COOKIE]) return req.cookies[COOKIE];
  return null;
}

export function authenticate(req, res, next) {
  const token = readToken(req);
  const payload = token && verifyToken(token);
  if (!payload) return res.status(401).json({ error: 'Not authenticated' });
  const user = req.dbUser;
  req.userId = payload.uid;
  next();
}

export function optionalAuth(req, _res, next) {
  const token = readToken(req);
  const payload = token && verifyToken(token);
  req.userId = payload?.uid ?? null;
  next();
}
