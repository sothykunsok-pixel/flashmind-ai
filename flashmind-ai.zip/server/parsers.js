import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);

/** Extracts plain text from an uploaded PDF / DOCX / TXT / MD file. */
export async function extractText(file) {
  const ext = path.extname(file.originalname || file.path).toLowerCase();
  const buf = await fs.readFile(file.path);

  if (ext === '.pdf') {
    // import the inner module directly: pdf-parse's index runs a debug block on import
    const pdfParse = require('pdf-parse/lib/pdf-parse.js');
    const data = await pdfParse(buf);
    return normalize(data.text);
  }

  if (ext === '.docx') {
    const mammoth = require('mammoth');
    const { value } = await mammoth.extractRawText({ buffer: buf });
    return normalize(value);
  }

  if (ext === '.txt' || ext === '.md' || ext === '.csv' || ext === '.text') {
    return normalize(buf.toString('utf8'));
  }

  if (ext === '.doc') {
    throw new Error('Legacy .doc files are not supported — please save as .docx, .pdf or .txt.');
  }

  throw new Error(`Unsupported file type "${ext}". Upload a PDF, DOCX or TXT file.`);
}

function normalize(text) {
  return String(text || '')
    .replace(/\r\n?/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}
