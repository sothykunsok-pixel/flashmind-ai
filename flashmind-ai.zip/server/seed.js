/**
 * Seeds a demo account so the app is never empty on first run.
 *   npm run seed
 * Login:  demo@flashmind.app  /  demo1234
 */
import { one, run } from './db.js';
import { hashPassword } from './auth.js';

const EMAIL = 'demo@flashmind.app';
const PASSWORD = 'demo1234';

const DECKS = [
  {
    title: 'Cell Biology Essentials',
    subject: 'Biology',
    description: 'Organelles, membranes and transport — built from a textbook chapter.',
    difficulty: 'medium',
    cards: [
      ['What is the function of the mitochondrion?', 'It produces ATP through cellular respiration, supplying the energy the cell needs to do work.', 'Often called the "powerhouse of the cell".'],
      ['What is the role of the ribosome?', 'It assembles proteins by translating messenger RNA into a chain of amino acids.', ''],
      ['What does the cell membrane control?', 'Which substances enter and leave the cell, through selective permeability.', 'Phospholipid bilayer with embedded proteins.'],
      ['What is the difference between prokaryotic and eukaryotic cells?', 'Prokaryotic cells have no membrane-bound nucleus or organelles; eukaryotic cells do.', 'Bacteria are prokaryotes; plants, animals and fungi are eukaryotes.'],
      ['What is osmosis?', 'The movement of water across a semi-permeable membrane from low to high solute concentration.', 'A form of passive transport — no ATP required.'],
      ['What does the Golgi apparatus do?', 'It modifies, sorts and packages proteins and lipids into vesicles for transport.', ''],
      ['Where is DNA stored in a eukaryotic cell?', 'In the nucleus, packaged into chromosomes.', ''],
      ['What is active transport?', 'Movement of substances against a concentration gradient using energy from ATP.', 'Example: the sodium-potassium pump.'],
    ],
  },
  {
    title: 'Spanish — Travel Phrases',
    subject: 'Languages',
    description: 'Survival Spanish for airports, hotels and restaurants.',
    difficulty: 'easy',
    cards: [
      ['How do you say "Where is the train station?" in Spanish?', '¿Dónde está la estación de tren?', ''],
      ['What does "la cuenta, por favor" mean?', 'The bill, please.', 'Used at the end of a meal.'],
      ['How do you ask for a room for two nights?', '¿Tiene una habitación para dos noches?', ''],
      ['What is "el aeropuerto"?', 'The airport.', ''],
      ['How do you say "I need help"?', 'Necesito ayuda.', ''],
      ['What does "¿A qué hora sale el autobús?" mean?', 'What time does the bus leave?', ''],
      ['How do you say "I would like a coffee, please"?', 'Quisiera un café, por favor.', 'Quisiera is the polite conditional form.'],
    ],
  },
  {
    title: 'World War II — Causes & Turning Points',
    subject: 'History',
    description: 'From the Treaty of Versailles to D-Day.',
    difficulty: 'hard',
    cards: [
      ['How did the Treaty of Versailles contribute to the outbreak of WWII?', 'Its harsh reparations, territorial losses and war-guilt clause destabilised Germany and fuelled resentment that extremist politics exploited.', ''],
      ['What was the policy of appeasement?', 'Britain and France conceding to Hitler\'s territorial demands — notably at Munich in 1938 — to avoid war.', ''],
      ['What was the significance of the invasion of Poland in 1939?', 'It triggered the British and French declarations of war, beginning WWII in Europe.', ''],
      ['Why was the Battle of Stalingrad a turning point?', 'The encirclement and surrender of the German Sixth Army ended Germany\'s offensive momentum on the Eastern Front.', ''],
      ['What was Operation Overlord?', 'The Allied D-Day invasion of Normandy on 6 June 1944, opening the Western Front.', ''],
      ['What did the Lend-Lease Act do?', 'It let the US supply materiel to Allied nations before entering the war itself.', ''],
    ],
  },
];

const user = one('SELECT * FROM users WHERE email = ?', EMAIL);
let userId;
if (user) {
  userId = user.id;
  console.log('Demo account already exists — adding decks only if missing.');
} else {
  const { lastInsertRowid } = run(
    'INSERT INTO users (email, name, password_hash, daily_goal) VALUES (?, ?, ?, ?)',
    EMAIL,
    'Demo Student',
    hashPassword(PASSWORD),
    20,
  );
  userId = Number(lastInsertRowid);
  console.log(`Created demo user ${EMAIL} / ${PASSWORD}`);
}

for (const d of DECKS) {
  if (one('SELECT id FROM decks WHERE user_id = ? AND title = ?', userId, d.title)) continue;
  const { lastInsertRowid: deckId } = run(
    `INSERT INTO decks (user_id, title, subject, description, difficulty, source_type, is_public, share_slug)
     VALUES (?, ?, ?, ?, ?, 'seed', ?, ?)`,
    userId,
    d.title,
    d.subject,
    d.description,
    d.difficulty,
    d.subject === 'Languages' ? 1 : 1,
    `${d.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}`,
  );
  const deck = Number(deckId);
  d.cards.forEach((card, i) => {
    run(
      'INSERT INTO cards (deck_id, question, answer, explanation, difficulty, position) VALUES (?, ?, ?, ?, ?, ?)',
      deck,
      card[0],
      card[1],
      card[2] || '',
      d.difficulty,
      i,
    );
  });

  // spread some study history over the last 6 days so the dashboard chart is alive
  const cards = one('SELECT COUNT(*) AS n FROM cards WHERE deck_id = ?', deck).n;
  for (let day = 5; day >= 0; day--) {
    const n = 2 + ((day * 3 + cards) % 4);
    for (let k = 0; k < n; k++) {
      const grade = k % 5 === 0 ? 'again' : k % 3 === 0 ? 'hard' : 'easy';
      run(
        `INSERT INTO reviews (user_id, deck_id, card_id, grade, correct, created_at)
         SELECT ?, ?, id, ?, ?, datetime('now', ?) FROM cards WHERE deck_id = ? ORDER BY id LIMIT 1 OFFSET ?`,
        userId,
        deck,
        grade,
        grade === 'again' ? 0 : 1,
        `-${day} days`,
        deck,
        (day + k) % cards,
      );
    }
  }
  run(
    `UPDATE cards SET reps = 2, interval_days = 3, ease = 2.6, last_grade = 'easy'
     WHERE deck_id = ? AND id IN (SELECT id FROM cards WHERE deck_id = ? ORDER BY id LIMIT 3)`,
    deck,
    deck,
  );
  run("UPDATE decks SET last_studied_at = datetime('now', '-1 days') WHERE id = ?", deck);
}

console.log('Seed complete.');
