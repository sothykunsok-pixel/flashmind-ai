import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, '..', '.env') });

const bool = (v, d = false) => (v === undefined || v === '' ? d : /^(1|true|yes|on)$/i.test(v));

export const config = {
  port: Number(process.env.PORT || 4000),
  isProd: process.env.NODE_ENV === 'production',
  jwtSecret: process.env.JWT_SECRET || 'dev-only-insecure-secret-change-me',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  maxUploadMb: Number(process.env.MAX_UPLOAD_MB || 15),
  appUrl: process.env.APP_URL || '',
  // secure cookies require HTTPS; set COOKIE_SECURE=false only for plain-HTTP self-hosting
  cookieSecure: bool(process.env.COOKIE_SECURE, process.env.NODE_ENV === 'production'),
  ai: {
    apiKey: process.env.AI_API_KEY || '',
    baseUrl: (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, ''),
    model: process.env.AI_MODEL || 'gpt-4o-mini',
    timeoutMs: Number(process.env.AI_TIMEOUT_MS || 90000),
    jsonMode: bool(process.env.AI_JSON_MODE, true),
  },
};

export const aiConfigured = () => Boolean(config.ai.apiKey);

if (config.isProd && config.jwtSecret.includes('change-me')) {
  console.warn('\x1b[31m[security] JWT_SECRET is still the example value — set a real secret in .env\x1b[0m');
}
