# FlashMind AI

Turn notes, PDFs and lecture slides into study flashcards, then learn them with spaced repetition and AI quizzes.

A complete full-stack application: **React + Vite** frontend, **Express** API, **SQLite** database (built into Node — no native build step), JWT auth, and a provider-agnostic AI layer.

![Dashboard](docs/screenshots/dashboard.png)

| Study mode | Generator | Quiz results |
| --- | --- | --- |
| ![](docs/screenshots/study.png) | ![](docs/screenshots/generator.png) | ![](docs/screenshots/quiz-results.png) |

| Dark mode | Mobile |
| --- | --- |
| ![](docs/screenshots/dashboard-dark.png) | ![](docs/screenshots/mobile.png) |

---

## Quick start

```bash
cp .env.example .env          # then edit the values
npm install
npm run seed                  # optional: demo account + 3 sample decks
npm run dev                   # API :4000 + Vite :5173
```

Open **http://localhost:5173**.

Demo login created by `npm run seed`:

| Email | Password |
| --- | --- |
| `demo@flashmind.app` | `demo1234` |

### Production

```bash
npm run build     # builds the React app into web-dist/
npm start         # Express serves the API *and* the built frontend on :4000
```

Or with Docker:

```bash
docker build -t flashmind .
docker run -p 4000:4000 --env-file .env -v flashmind-data:/app/server/data flashmind
```

---

## Deploying

The app is a single Node process serving both the API and the built frontend, with SQLite on a mounted volume. Two ready-made configs ship in the repo.

### Fly.io (recommended — cheapest option with a real volume)

```bash
fly launch --no-deploy --copy-config      # uses fly.toml (app name / region)
fly volumes create flashmind_data --size 1 --region sin
fly secrets set JWT_SECRET="$(openssl rand -hex 48)"
fly secrets set AI_API_KEY="sk-..."       # optional
fly deploy
```

`fly.toml` mounts the volume at `/data`, sets `DATA_DIR=/data`, terminates TLS and forces HTTPS (so auth cookies are `Secure`), and health-checks `/api/health` every 15s.

### Render

Commit `render.yaml` and create a Blueprint. It provisions the Docker service, a 1 GB disk at `/var/data`, a generated `JWT_SECRET`, and `DATA_DIR` pointing at the disk. `plan: starter` is required because persistent disks are not available on free instances.

### Any VPS / Docker host

```bash
docker build -t flashmind .
docker run -d --name flashmind -p 4000:4000 \
  -v flashmind-data:/data \
  -e NODE_ENV=production -e DATA_DIR=/data \
  -e COOKIE_SECURE=true \
  -e JWT_SECRET="$(openssl rand -hex 48)" \
  -e AI_API_KEY="sk-..." \
  flashmind
```

Put a TLS-terminating reverse proxy (Caddy, Nginx, Cloudflare Tunnel) in front. `COOKIE_SECURE=true` requires HTTPS; set it to `false` only for plain-HTTP intranet use.

### Production checklist

| Item | Why |
| --- | --- |
| `DATA_DIR` on a volume | SQLite + WAL files must survive restarts/redeploys — verify with the persistence test below |
| `JWT_SECRET` from `openssl rand -hex 48` | Rotating it logs everyone out; the example value is refused in production |
| `COOKIE_SECURE=true` | Auth cookie is `HttpOnly; Secure; SameSite=Lax` behind TLS |
| One instance only | SQLite is single-writer; scale up, not out, or move to Postgres |
| `/api/health` as the health check | Returns AI mode so you can confirm configuration |
| Reverse-proxy headers | `trust proxy` is enabled so `Secure` cookies work behind TLS termination |

**Persistence smoke test** (runs in ~10s):

```bash
DATA_DIR=/tmp/fm-volume JWT_SECRET=x node server/index.js &   # create a deck
kill %1; DATA_DIR=/tmp/fm-volume JWT_SECRET=x node server/index.js &
# log in again — the deck is still there
```

## AI configuration

Everything AI-related runs **server-side only**. The browser never receives the key.

```env
AI_API_KEY=sk-...
AI_BASE_URL=https://api.openai.com/v1
AI_MODEL=gpt-4o-mini
AI_JSON_MODE=true
```

The client is OpenAI-compatible, so any `/chat/completions` provider works — OpenAI, OpenRouter, Groq, Together, Azure gateways, or a local Ollama at `http://localhost:11434/v1`.

**Without a key the app still works.** It runs in *demo mode*: a local heuristic generator builds cards, summaries and quizzes from your own text, and every response is labelled `demo: true` in the API and flagged in the UI. Add a key and restart to switch to live AI — no other changes needed.

### How the AI layer stays reliable

| Concern | Handling |
| --- | --- |
| Invalid JSON | `response_format: json_object` where supported, balanced-brace extraction, code-fence stripping, 3 attempts with exponential backoff |
| Hallucination | In *source* mode the system prompt forbids facts not present in the supplied material |
| Duplicates | Generator is told to avoid them, and server-side dedupe by normalised question |
| Malformed quiz items | `sanitizeQuiz()` repairs missing `answerIndex`, pads accepted answers, drops unusable questions |
| Long inputs | Source truncated to 16k characters with an explicit marker |
| Timeouts / 429 / 5xx | Aborts after `AI_TIMEOUT_MS`, retries transient failures |
| Cost control | Per-IP rate limit (20 generations/min), capped `max_tokens` per request |

---

## Architecture

```
├── server/
│   ├── index.js            Express app, static hosting, error handling
│   ├── config.js           env loading + feature flags
│   ├── db.js               node:sqlite schema, migrations, helpers
│   ├── auth.js             bcrypt, JWT, httpOnly cookie
│   ├── ai.js               provider client, prompts, validation, demo generator
│   ├── parsers.js          PDF / DOCX / TXT text extraction
│   ├── utils.js            CSV parser/writer, slugs, validation
│   ├── seed.js             demo data
│   ├── routes/
│   │   ├── auth.js         register, login, logout, profile, password reset
│   │   ├── decks.js        folders, decks, cards, CSV, public/shared decks
│   │   ├── study.js        SRS reviews, queue, stats, activity, quiz attempts
│   │   └── ai.js           upload, generate, summarize, explain, quiz
│   └── test/core.test.js   scheduler, JSON repair, sanitizer, CSV tests
└── web/
    ├── index.html
    └── src/
        ├── App.jsx         routes + guards
        ├── styles.css      design system (light/dark, gradients, 3D card)
        ├── context/        auth + theme, toasts
        ├── components/     Layout, Flashcard, ActivityChart, DeckCard, Modal…
        ├── lib/            api client, formatting/grading helpers
        └── pages/          Dashboard, Decks, DeckDetail, Create, Study,
                            Quiz, Progress, Settings, Explore, SharedDeck, Login
```

### Database

SQLite via Node's built-in `node:sqlite` (`DatabaseSync`) — synchronous, zero native modules, WAL mode. Tables: `users`, `folders`, `decks`, `cards`, `reviews`, `quiz_attempts`. Every deck/card query is scoped by `user_id`, so users can only ever read their own data.

### Spaced repetition

`server/routes/study.js` implements a simplified SM-2:

| Grade | Interval | Ease | Due |
| --- | --- | --- | --- |
| Again | reset to 0 | −0.20 (min 1.3) | +10 minutes |
| Hard | ×1.2 (min 1 day) | −0.05 | +interval |
| Easy | ×ease (first = 3 days) | +0.10 (max 3.2) | +interval |

Streak = consecutive days with at least one review. Mastery = cards with `interval_days >= 1` and a last grade of hard/easy.

---

## Features

**Generator** — topic or pasted material; PDF/DOCX/TXT upload with server-side text extraction; 5–50 cards; Easy/Medium/Hard; 20 languages; preview-and-edit before saving; smart summarisation; "generate more cards" on an existing deck.

**Study mode** — one card at a time, 3D flip, shuffle, keyboard shortcuts (`Space`, `←`/`→`, `1`/`2`/`3`), Again/Hard/Easy grading, progress and counter, session summary, Smart Review queue that pulls lapses across decks, and per-card "Explain simply".

**Quizzes** — multiple choice, true/false, fill-in-the-blank, short answer or mixed; instant feedback with explanations; score screen; missed-question review; every attempt stored.

**Dashboard & progress** — totals, cards studied today, streak, accuracy, cards due, daily goal ring, 7/30-day activity chart, continue-studying card, mastery per deck, quiz history.

**Library** — search, subject filters, folders, duplicate, rename, per-card CRUD, CSV import/export, public decks with shareable `/s/<slug>` links and one-click copy into your library.

**Accounts** — registration, login, logout, password reset tokens, password change, profile, daily goal, theme (light/dark/system), reminder preference.

---

## API reference

All routes are JSON and, except for auth/public routes, require the auth cookie (or `Authorization: Bearer <token>`).

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/api/auth/register` · `login` · `logout` | Session lifecycle |
| GET/PATCH | `/api/auth/me` · `/api/auth/profile` | Current user, profile & prefs |
| POST | `/api/auth/forgot-password` · `/api/auth/reset-password` · `/api/auth/change-password` | Passwords |
| GET/POST | `/api/decks` | List (search/subject/folder) · create with cards |
| GET/PATCH/DELETE | `/api/decks/:id` | Single deck |
| POST | `/api/decks/:id/duplicate` · `/api/decks/:id/expand` | Copy · AI-expand |
| GET/POST | `/api/decks/:id/cards` | List · create card |
| PATCH/DELETE | `/api/cards/:id` | Edit (incl. reset progress) · delete |
| GET/POST/PATCH/DELETE | `/api/folders` | Folder management |
| GET | `/api/decks/:id/export` | CSV download |
| POST | `/api/import/csv` | CSV upload |
| POST | `/api/study/review` | Grade a card (`again`/`hard`/`easy`) |
| GET | `/api/study/queue` | Smart / deck study queue |
| GET | `/api/stats` · `/api/activity?days=` | Dashboard metrics |
| POST/GET | `/api/quiz/attempts` | Save / list quiz results |
| POST | `/api/upload` | Extract text from PDF/DOCX/TXT |
| POST | `/api/ai/flashcards` · `summarize` · `explain` · `quiz` | AI features |
| GET | `/api/public/decks` · `/api/public/decks/:slug` | Explore / shared deck |
| POST | `/api/public/decks/:slug/clone` | Copy a shared deck |
| GET | `/api/health` · `/api/meta/ai` | Health + AI status |

---

## Tests

```bash
npm test
```

Covers the SM-2 scheduler, JSON extraction/repair, card & quiz sanitising, the demo generator, and CSV round-tripping.

---

## Security notes

- Passwords hashed with bcrypt (cost 10); sessions are JWT in an `httpOnly`, `sameSite=lax` cookie (`secure` in production).
- Auth and AI endpoints are rate limited; registration validates email format and password length.
- Uploads are size-capped, written to the OS temp dir, parsed by extension, and deleted immediately after extraction.
- All SQL uses bound parameters; every owned resource is re-checked against `user_id` on each request.
- Set a strong `JWT_SECRET` before deploying — the server warns in production if the example value is still in place.
- Password-reset links are printed to the server log because no mail provider is bundled; wire up your email provider in `POST /api/auth/forgot-password` for real deployments.

## Branding

The FlashMind AI logo lives in `web/public/`:

| File | Use |
| --- | --- |
| `logo-mark-gradient.png` | Mark in brand gradient — light backgrounds |
| `logo-mark-white.png` | Mark in white — gradient/dark tiles (sidebar) |
| `logo-mark-dark.png` | Mark in ink |
| `logo-full-white.png` / `logo-full-dark.png` | Mark + wordmark lockups (auth hero) |
| `favicon.png`, `apple-touch-icon.png`, `logo-512.png` | App icons |

Original artwork is kept at `assets/logo-source.png`.
