import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { api } from '../lib/api.js';
import { useTheme } from './ToastContext.jsx';

const AuthCtx = createContext(null);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [aiStatus, setAiStatus] = useState({ configured: false, mode: 'demo', model: 'demo-generator' });
  const { theme, setTheme } = useTheme();

  const refresh = useCallback(async () => {
    try {
      const { user: u } = await api.me();
      setUser(u);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    api.aiStatus().then(setAiStatus).catch(() => {});
  }, [refresh]);

  const login = async (email, password) => {
    const { user: u } = await api.login({ email, password });
    setUser(u);
    return u;
  };

  const register = async (name, email, password) => {
    const { user: u } = await api.register({ name, email, password });
    setUser(u);
    return u;
  };

  const logout = async () => {
    try {
      await api.logout();
    } catch {}
    setUser(null);
  };

  const updateProfile = async (patch) => {
    const { user: u } = await api.updateProfile(patch);
    setUser(u);
    return u;
  };

  return (
    <AuthCtx.Provider
      value={{ user, loading, login, register, logout, refresh, updateProfile, aiStatus, theme, setTheme }}
    >
      {children}
    </AuthCtx.Provider>
  );
}
