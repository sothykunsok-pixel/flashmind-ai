import { useEffect } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import { CenteredLoader } from './components/States.jsx';
import { useAuth } from './context/AuthContext.jsx';
import Login from './pages/Login.jsx';
import ResetPassword from './pages/ResetPassword.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Decks from './pages/Decks.jsx';
import DeckDetail from './pages/DeckDetail.jsx';
import Create from './pages/Create.jsx';
import Study from './pages/Study.jsx';
import Quiz from './pages/Quiz.jsx';
import Progress from './pages/Progress.jsx';
import Settings from './pages/Settings.jsx';
import Explore from './pages/Explore.jsx';
import SharedDeck from './pages/SharedDeck.jsx';

function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <CenteredLoader label="Loading FlashMind…" />;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
  }, [pathname]);
  return null;
}

export default function App() {
  const { user, loading } = useAuth();
  const location = useLocation();

  useEffect(() => {
    const titles = {
      '/': 'Dashboard',
      '/decks': 'My Flashcards',
      '/create': 'Create Flashcards',
      '/study': 'Study Mode',
      '/quiz': 'AI Quiz',
      '/progress': 'Progress',
      '/settings': 'Settings',
      '/explore': 'Explore Decks',
    };
    const t = titles[location.pathname];
    document.title = t ? `${t} · FlashMind AI` : 'FlashMind AI — Study smarter with AI flashcards';
  }, [location.pathname]);

  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route
          path="/login"
          element={loading ? <CenteredLoader /> : user ? <Navigate to="/" replace /> : <Login />}
        />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/s/:slug" element={<SharedDeck />} />

        <Route
          element={
            <Protected>
              <Layout />
            </Protected>
          }
        >
          <Route path="/" element={<Dashboard />} />
          <Route path="/decks" element={<Decks />} />
          <Route path="/decks/:deckId" element={<DeckDetail />} />
          <Route path="/create" element={<Create />} />
          <Route path="/study" element={<Study />} />
          <Route path="/study/:deckId" element={<Study />} />
          <Route path="/quiz" element={<Quiz />} />
          <Route path="/quiz/:deckId" element={<Quiz />} />
          <Route path="/progress" element={<Progress />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/explore" element={<Explore />} />
        </Route>

        <Route
          path="*"
          element={
            <div className="page" style={{ paddingTop: 70 }}>
              <div className="empty" style={{ maxWidth: 460, margin: '0 auto' }}>
                <div className="empty-icon">
                  <img src="/logo-mark-gradient.png" alt="" style={{ height: 26 }} />
                </div>
                <h3>Page not found</h3>
                <p>That link does not exist in FlashMind.</p>
                <a className="btn btn-primary" href="/">
                  Back to dashboard
                </a>
              </div>
            </div>
          }
        />
      </Routes>
    </>
  );
}
