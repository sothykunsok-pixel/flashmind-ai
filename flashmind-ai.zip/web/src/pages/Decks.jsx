import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import DeckCard from '../components/DeckCard.jsx';
import Modal, { ConfirmDialog } from '../components/Modal.jsx';
import { DeckGridSkeleton, EmptyState, ErrorNote } from '../components/States.jsx';
import { api } from '../lib/api.js';
import { useToast } from '../context/ToastContext.jsx';

export default function Decks() {
  const navigate = useNavigate();
  const toast = useToast();
  const [decks, setDecks] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [folders, setFolders] = useState([]);
  const [search, setSearch] = useState('');
  const [subject, setSubject] = useState('All');
  const [folderId, setFolderId] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [confirm, setConfirm] = useState(null);
  const [busy, setBusy] = useState(false);
  const [folderModal, setFolderModal] = useState(false);
  const [folderName, setFolderName] = useState('');
  const [importBusy, setImportBusy] = useState(false);
  const fileRef = useRef(null);

  const load = async () => {
    setError('');
    try {
      const { decks: d, subjects: s } = await api.decks({
        search: search.trim() || undefined,
        subject: subject !== 'All' ? subject : undefined,
        folder: folderId || undefined,
      });
      setDecks(d);
      setSubjects(s);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(load, search ? 260 : 0);
    return () => clearTimeout(t);
  }, [search, subject, folderId]);

  useEffect(() => {
    setLoading(true);
    api.folders().then(({ folders: f }) => setFolders(f)).catch(() => {});
  }, []);

  const duplicate = async (deck) => {
    try {
      const { deck: copy } = await api.duplicateDeck(deck.id);
      toast.success(`Duplicated as “${copy.title}”.`);
      load();
    } catch (err) {
      toast.error(err.message);
    }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await api.deleteDeck(confirm.id);
      toast.success('Deck deleted.');
      setConfirm(null);
      load();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setBusy(false);
    }
  };

  const createFolder = async () => {
    if (!folderName.trim()) return;
    try {
      await api.createFolder({ name: folderName.trim() });
      setFolderName('');
      setFolderModal(false);
      toast.success('Folder created.');
      const { folders: f } = await api.folders();
      setFolders(f);
    } catch (err) {
      toast.error(err.message);
    }
  };

  const importCsv = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setImportBusy(true);
    try {
      const res = await api.importCsvFile(file, {
        title: file.name.replace(/\.csv$/i, ''),
        subject: 'Imported',
      });
      toast.success(`Imported ${res.imported} cards.`);
      navigate(`/decks/${res.deck.id}`);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setImportBusy(false);
    }
  };

  const hasFilters = search || subject !== 'All' || folderId;

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="eyebrow">Library</div>
          <h1>My Flashcards</h1>
          <p className="sub">Every deck you have created, organised by subject and folder.</p>
        </div>
        <div className="page-head-actions">
          <button className="btn" onClick={() => setFolderModal(true)}>
            <Icon name="folder" size={15} /> New folder
          </button>
          <button className="btn" onClick={() => fileRef.current?.click()} disabled={importBusy}>
            {importBusy ? <span className="spinner" /> : <Icon name="upload" size={15} />}
            Import CSV
          </button>
          <button className="btn btn-primary" onClick={() => navigate('/create')}>
            <Icon name="plus" size={15} /> New deck
          </button>
          <input ref={fileRef} type="file" accept=".csv,text/csv" hidden onChange={importCsv} />
        </div>
      </div>

      <div className="panel panel-pad" style={{ display: 'grid', gap: 14, marginBottom: 20 }}>
        <div className="row">
          <div className="input-icon grow" style={{ minWidth: 220 }}>
            <Icon name="search" size={16} />
            <input
              className="input"
              placeholder="Search decks by title, subject or description…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Search decks"
            />
          </div>
          <select className="select" style={{ width: 190 }} value={folderId} onChange={(e) => setFolderId(e.target.value)} aria-label="Filter by folder">
            <option value="">All folders</option>
            <option value="none">No folder</option>
            {folders.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name} ({f.deckCount})
              </option>
            ))}
          </select>
        </div>

        <div className="row" style={{ gap: 8 }}>
          {['All', ...subjects].map((s) => (
            <button key={s} className={`chip ${subject === s ? 'on' : ''}`} onClick={() => setSubject(s)}>
              {s}
            </button>
          ))}
        </div>
      </div>

      <ErrorNote message={error} onRetry={load} />

      {loading ? (
        <DeckGridSkeleton />
      ) : decks.length ? (
        <div className="deck-grid">
          {decks.map((d) => (
            <DeckCard
              key={d.id}
              deck={d}
              onOpen={() => navigate(`/decks/${d.id}`)}
              onStudy={() => navigate(`/study/${d.id}`)}
              onEdit={() => navigate(`/decks/${d.id}`)}
              onDuplicate={duplicate}
              onDelete={(deck) => setConfirm(deck)}
            />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={hasFilters ? 'search' : 'layers'}
          title={hasFilters ? 'No decks match those filters' : 'No decks yet'}
          message={
            hasFilters
              ? 'Try a different subject or clear the search to see all of your decks.'
              : 'Create a deck from a topic, some notes or a PDF — the AI does the rest.'
          }
          action={
            hasFilters ? (
              <button
                className="btn"
                onClick={() => {
                  setSearch('');
                  setSubject('All');
                  setFolderId('');
                }}
              >
                Clear filters
              </button>
            ) : (
              <button className="btn btn-primary" onClick={() => navigate('/create')}>
                <Icon name="sparkles" size={15} /> Create flashcards
              </button>
            )
          }
        />
      )}

      <ConfirmDialog
        open={Boolean(confirm)}
        onClose={() => setConfirm(null)}
        onConfirm={remove}
        busy={busy}
        title={`Delete “${confirm?.title}”?`}
        message={`This permanently removes the deck and its ${confirm?.cardCount ?? 0} cards, including study history for those cards.`}
      />

      <Modal
        open={folderModal}
        onClose={() => setFolderModal(false)}
        title="New folder"
        subtitle="Group related decks together — Biology, Finals, Languages…"
        footer={
          <>
            <button className="btn" onClick={() => setFolderModal(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={createFolder} disabled={!folderName.trim()}>
              Create folder
            </button>
          </>
        }
      >
        <div className="field">
          <label className="label" htmlFor="fname">
            Folder name
          </label>
          <input
            id="fname"
            className="input"
            value={folderName}
            onChange={(e) => setFolderName(e.target.value)}
            placeholder="e.g. Semester 2 — Biology"
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && createFolder()}
          />
        </div>
        {folders.length > 0 && (
          <div className="small muted">
            Existing folders: {folders.map((f) => f.name).join(', ')}
          </div>
        )}
      </Modal>
    </div>
  );
}
