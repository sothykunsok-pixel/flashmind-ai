import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import Modal from '../components/Modal.jsx';
import { ErrorNote } from '../components/States.jsx';
import { api, ApiError } from '../lib/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { formatDate } from '../lib/utils.js';

export default function Settings() {
  const { user, updateProfile, logout, aiStatus, theme, setTheme } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const fileRef = useRef(null);

  const [name, setName] = useState(user?.name || '');
  const [goal, setGoal] = useState(user?.dailyGoal ?? 20);
  const [reminders, setReminders] = useState(Boolean(user?.remindersEnabled));
  const [reminderTime, setReminderTime] = useState(user?.reminderTime || '19:00');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [pwOpen, setPwOpen] = useState(false);
  const [pw, setPw] = useState({ current: '', next: '', confirm: '' });
  const [importing, setImporting] = useState(false);

  useEffect(() => {
    if (!user) return;
    setName(user.name);
    setGoal(user.dailyGoal);
    setReminders(Boolean(user.remindersEnabled));
    setReminderTime(user.reminderTime || '19:00');
  }, [user]);

  const saveProfile = async () => {
    setBusy(true);
    setError('');
    try {
      await updateProfile({ name: name.trim(), dailyGoal: Number(goal) });
      toast.success('Profile saved.');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const saveReminders = async (enabled, time = reminderTime) => {
    setReminders(enabled);
    try {
      await updateProfile({ remindersEnabled: enabled, reminderTime: time });
      toast.success(enabled ? `Daily reminder set for ${time}.` : 'Reminders turned off.');
    } catch (err) {
      toast.error(err.message);
    }
  };

  const changePassword = async () => {
    setError('');
    if (pw.next !== pw.confirm) return setError('New passwords do not match.');
    if (pw.next.length < 8) return setError('New password must be at least 8 characters.');
    setBusy(true);
    try {
      await api.changePassword({ currentPassword: pw.current, newPassword: pw.next });
      toast.success('Password changed.');
      setPwOpen(false);
      setPw({ current: '', next: '', confirm: '' });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const importCsv = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setImporting(true);
    try {
      const res = await api.importCsvFile(file, { title: file.name.replace(/\.csv$/i, ''), subject: 'Imported' });
      toast.success(`Imported ${res.imported} cards.`);
      navigate(`/decks/${res.deck.id}`);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setImporting(false);
    }
  };

  const reminderPermission = () => {
    if (!('Notification' in window)) return toast.info('This browser does not support notifications.');
    Notification.requestPermission().then((p) => {
      if (p === 'granted') new Notification('FlashMind AI reminders on', { body: `We will nudge you at ${reminderTime} to review your cards.` });
      else toast.info('Notification permission declined — reminders will appear in-app instead.');
    });
  };

  return (
    <div className="page" style={{ maxWidth: 900 }}>
      <div className="page-head">
        <div>
          <div className="eyebrow">Account</div>
          <h1>Settings</h1>
          <p className="sub">Your profile, study preferences, AI configuration and data.</p>
        </div>
      </div>

      <ErrorNote message={error} />

      <div className="panel mt-2">
        <div className="panel-head">
          <h3>Profile</h3>
        </div>
        <div className="panel-body" style={{ display: 'grid', gap: 14 }}>
          <div className="grid-2">
            <div className="field">
              <label className="label">Display name</label>
              <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="field">
              <label className="label">Email</label>
              <input className="input" value={user?.email || ''} readOnly style={{ opacity: 0.7 }} />
            </div>
          </div>
          <div className="row between">
            <span className="small muted">Member since {formatDate(user?.createdAt)}</span>
            <button className="btn btn-primary" onClick={saveProfile} disabled={busy || !name.trim()}>
              {busy ? <span className="spinner" /> : <Icon name="check" size={15} />} Save changes
            </button>
          </div>
        </div>
      </div>

      <div className="panel mt-2">
        <div className="panel-head">
          <h3>Study preferences</h3>
        </div>
        <div className="setting-row">
          <div className="sr-main">
            <div className="sr-title">Daily goal</div>
            <div className="sr-sub">How many card reviews count as a completed day.</div>
          </div>
          <div className="flex" style={{ gap: 8 }}>
            <input
              type="range"
              min="5"
              max="100"
              step="5"
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              onMouseUp={() => saveProfile()}
              onTouchEnd={() => saveProfile()}
              style={{ accentColor: 'var(--brand)', width: 140 }}
              aria-label="Daily goal"
            />
            <span className="badge badge-brand" style={{ minWidth: 56, justifyContent: 'center' }}>{goal} cards</span>
          </div>
        </div>

        <div className="setting-row">
          <div className="sr-main">
            <div className="sr-title">Appearance</div>
            <div className="sr-sub">Light, dark, or follow your system setting.</div>
          </div>
          <div className="theme-dots">
            {[
              ['light', 'sun'],
              ['dark', 'moon'],
              ['system', 'settings'],
            ].map(([t, icon]) => (
              <button
                key={t}
                className={`theme-dot ${theme === t ? 'on' : ''}`}
                onClick={() => setTheme(t)}
                title={t}
                aria-label={`${t} theme`}
              >
                <Icon name={icon} size={14} />
              </button>
            ))}
          </div>
        </div>

        <div className="setting-row">
          <div className="sr-main">
            <div className="sr-title">Daily study reminder</div>
            <div className="sr-sub">
              Get a nudge when your cards are due. {reminders ? 'Currently on.' : 'Currently off.'}
            </div>
          </div>
          <div className="flex" style={{ gap: 10 }}>
            <input
              type="time"
              className="input"
              style={{ width: 108, height: 34 }}
              value={reminderTime}
              onChange={(e) => setReminderTime(e.target.value)}
              onBlur={() => reminders && saveReminders(true, reminderTime)}
              aria-label="Reminder time"
            />
            <button
              className={`switch ${reminders ? 'on' : ''}`}
              aria-label="Toggle reminders"
              onClick={() => {
                const next = !reminders;
                saveReminders(next);
                if (next) reminderPermission();
              }}
            />
          </div>
        </div>
      </div>

      <div className="panel mt-2">
        <div className="panel-head">
          <h3>AI configuration</h3>
          <span className={`badge right ${aiStatus.configured ? 'badge-success' : 'badge-warn'}`}>
            {aiStatus.configured ? 'connected' : 'demo mode'}
          </span>
        </div>
        <div className="panel-body" style={{ display: 'grid', gap: 10 }}>
          <div className="flex between">
            <span className="small muted">Provider</span>
            <span className="small" style={{ fontWeight: 600 }}>{aiStatus.providerHost || 'Local demo generator'}</span>
          </div>
          <div className="flex between">
            <span className="small muted">Model</span>
            <span className="small" style={{ fontWeight: 600 }}>{aiStatus.model}</span>
          </div>
          <div className="ai-note">
            <Icon name="lock" size={15} style={{ flex: 'none', marginTop: 1 }} />
            <div>
              The AI key lives only in your server&apos;s <code>.env</code> file as <code>AI_API_KEY</code>. The browser
              never sees it — all generation goes through <code>/api/ai/*</code>.
              {!aiStatus.configured && ' Add a key and restart the server to switch to live generation.'}
            </div>
          </div>
        </div>
      </div>

      <div className="panel mt-2">
        <div className="panel-head">
          <h3>Data</h3>
        </div>
        <div className="setting-row">
          <div className="sr-main">
            <div className="sr-title">Import cards from CSV</div>
            <div className="sr-sub">Columns: question, answer, explanation (optional), difficulty (optional).</div>
          </div>
          <button className="btn" onClick={() => fileRef.current?.click()} disabled={importing}>
            {importing ? <span className="spinner" /> : <Icon name="upload" size={15} />} Import CSV
          </button>
          <input ref={fileRef} type="file" accept=".csv" hidden onChange={importCsv} />
        </div>
        <div className="setting-row">
          <div className="sr-main">
            <div className="sr-title">Security</div>
            <div className="sr-sub">Change the password used to sign in to this account.</div>
          </div>
          <button className="btn" onClick={() => setPwOpen(true)}>
            <Icon name="lock" size={15} /> Change password
          </button>
        </div>
        <div className="setting-row">
          <div className="sr-main">
            <div className="sr-title">Sign out</div>
            <div className="sr-sub">Your decks and study history stay safe on the server.</div>
          </div>
          <button
            className="btn btn-danger-ghost"
            onClick={async () => {
              await logout();
              navigate('/login');
            }}
          >
            <Icon name="logout" size={15} /> Log out
          </button>
        </div>
      </div>

      <p className="small muted center mt-3">FlashMind AI · built with React, Express and SQLite</p>

      <Modal
        open={pwOpen}
        onClose={() => setPwOpen(false)}
        title="Change password"
        footer={
          <>
            <button className="btn" onClick={() => setPwOpen(false)} disabled={busy}>Cancel</button>
            <button className="btn btn-primary" onClick={changePassword} disabled={busy}>
              {busy ? <span className="spinner" /> : <Icon name="check" size={15} />} Update password
            </button>
          </>
        }
      >
        {['current', 'next', 'confirm'].map((k, i) => (
          <div className="field" key={k}>
            <label className="label">{['Current password', 'New password', 'Confirm new password'][i]}</label>
            <input
              className="input"
              type="password"
              value={pw[k]}
              onChange={(e) => setPw({ ...pw, [k]: e.target.value })}
              autoComplete={k === 'current' ? 'current-password' : 'new-password'}
            />
          </div>
        ))}
      </Modal>
    </div>
  );
}
