import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { api } from '../lib/api.js';

export default function Login() {
  const { login, register } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [resetSent, setResetSent] = useState(null);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (mode === 'forgot') {
        const res = await api.forgotPassword(form.email);
        setResetSent(res);
        toast.success('Reset link generated.');
      } else if (mode === 'login') {
        await login(form.email.trim(), form.password);
        navigate('/', { replace: true });
      } else {
        await register(form.name.trim(), form.email.trim(), form.password);
        toast.success('Welcome to FlashMind AI!');
        navigate('/', { replace: true });
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const fillDemo = () => {
    setMode('login');
    setForm({ name: '', email: 'demo@flashmind.app', password: 'demo1234' });
    setError('');
  };

  return (
    <div className="auth">
      <section className="auth-hero">
        <img src="/logo-full-white.png" alt="FlashMind AI" style={{ height: 74, width: 'auto', alignSelf: 'flex-start' }} />

        <h2>Turn any notes into flashcards you actually remember.</h2>
        <p className="lede">
          Paste a chapter, drop a PDF, or just name a topic. FlashMind builds accurate question-and-answer cards,
          schedules them with spaced repetition, and quizzes you until it sticks.
        </p>

        <ul className="auth-points">
          <li>
            <span className="tick">
              <Icon name="check" size={12} />
            </span>
            AI flashcards from notes, PDFs, DOCX and TXT
          </li>
          <li>
            <span className="tick">
              <Icon name="check" size={12} />
            </span>
            3D flip study mode with Again / Hard / Easy scheduling
          </li>
          <li>
            <span className="tick">
              <Icon name="check" size={12} />
            </span>
            AI quizzes: multiple choice, true/false, fill-in, short answer
          </li>
          <li>
            <span className="tick">
              <Icon name="check" size={12} />
            </span>
            Streaks, daily goals and a 7-day progress chart
          </li>
        </ul>

        <div className="auth-demo">
          Demo account — <code>demo@flashmind.app</code> / <code>demo1234</code>
        </div>
      </section>

      <section className="auth-form-wrap">
        <div className="auth-card">
          <div className="flex" style={{ marginBottom: 22 }}>
            <img src="/logo-mark-gradient.png" alt="" style={{ height: 34 }} />
            <span style={{ fontWeight: 800, fontSize: 15, letterSpacing: '-0.03em' }}>FlashMind AI</span>
          </div>

          {mode !== 'forgot' && (
            <div className="auth-tabs" role="tablist">
              <button className={mode === 'login' ? 'on' : ''} onClick={() => (setMode('login'), setError(''))} role="tab">
                Log in
              </button>
              <button className={mode === 'register' ? 'on' : ''} onClick={() => (setMode('register'), setError(''))} role="tab">
                Create account
              </button>
            </div>
          )}

          <h1>{mode === 'register' ? 'Start studying in minutes' : mode === 'forgot' ? 'Reset your password' : 'Welcome back'}</h1>
          <p className="sub">
            {mode === 'register'
              ? 'Create a free account — your decks stay private to you.'
              : mode === 'forgot'
                ? 'Enter your email and we’ll generate a reset link.'
                : 'Log in to pick up where you left off.'}
          </p>

          <form onSubmit={submit} style={{ display: 'grid', gap: 14 }}>
            {mode === 'register' && (
              <div className="field">
                <label className="label" htmlFor="name">
                  Full name
                </label>
                <input
                  id="name"
                  className="input"
                  value={form.name}
                  onChange={set('name')}
                  placeholder="Ada Lovelace"
                  autoComplete="name"
                  required
                />
              </div>
            )}

            <div className="field">
              <label className="label" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                className="input"
                type="email"
                value={form.email}
                onChange={set('email')}
                placeholder="you@university.edu"
                autoComplete="email"
                required
              />
            </div>

            {mode !== 'forgot' && (
              <div className="field">
                <label className="label" htmlFor="password">
                  Password
                  {mode === 'login' && (
                    <button
                      type="button"
                      className="link-btn right"
                      style={{ fontSize: 12 }}
                      onClick={() => (setMode('forgot'), setError(''), setResetSent(null))}
                    >
                      Forgot password?
                    </button>
                  )}
                </label>
                <input
                  id="password"
                  className="input"
                  type="password"
                  value={form.password}
                  onChange={set('password')}
                  placeholder={mode === 'register' ? 'At least 8 characters' : '••••••••'}
                  autoComplete={mode === 'register' ? 'new-password' : 'current-password'}
                  minLength={8}
                  required
                />
              </div>
            )}

            {error && <div className="alert alert-error">{error}</div>}

            {resetSent?.devResetUrl && (
              <div className="alert alert-info" style={{ display: 'grid', gap: 6 }}>
                <div>
                  <strong>Development mode:</strong> no mail server is configured, so use this link directly.
                </div>
                <Link to={resetSent.devResetUrl.replace(/^https?:\/\/[^/]+/, '')} className="link-btn">
                  Open reset link →
                </Link>
              </div>
            )}

            <button className="btn btn-primary btn-lg" type="submit" disabled={busy}>
              {busy ? <span className="spinner" /> : <Icon name={mode === 'forgot' ? 'refresh' : 'arrowRight'} size={16} />}
              {mode === 'register' ? 'Create free account' : mode === 'forgot' ? 'Send reset link' : 'Log in'}
            </button>

            {mode === 'forgot' && (
              <button type="button" className="btn btn-ghost" onClick={() => (setMode('login'), setError(''))}>
                <Icon name="left" size={15} /> Back to log in
              </button>
            )}
          </form>

          {mode === 'login' && (
            <div className="auth-switch" style={{ marginTop: 16 }}>
              <button onClick={fillDemo}>Try the demo account →</button>
            </div>
          )}

          <div className="auth-switch">
            {mode === 'login' ? (
              <>
                New here? <button onClick={() => (setMode('register'), setError(''))}>Create an account</button>
              </>
            ) : mode === 'register' ? (
              <>
                Already have an account? <button onClick={() => (setMode('login'), setError(''))}>Log in</button>
              </>
            ) : null}
          </div>
        </div>
      </section>
    </div>
  );
}
