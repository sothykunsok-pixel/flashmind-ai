import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import { DeckGridSkeleton, EmptyState, ErrorNote } from '../components/States.jsx';
import { api } from '../lib/api.js';
import { useToast } from '../context/ToastContext.jsx';
import { subjectEmoji, plural, timeAgo } from '../lib/utils.js';

export default function Explore() {
  const navigate = useNavigate();
  const toast = useToast();
  const [decks, setDecks] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [q, setQ] = useState('');
  const [subject, setSubject] = useState('All');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [cloning, setCloning] = useState(null);

  const load = async () => {
    setError('');
    try {
      const { decks: d, subjects: s } = await api.publicDecks({
        q: q.trim() || undefined,
        subject: subject !== 'All' ? subject : undefined,
      });
      setDecks(d);
      setSubjects(s);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(load, q ? 260 : 0);
    return () => clearTimeout(t);
  }, [q, subject]);

  const clone = async (deck) => {
    setCloning(deck.id);
    try {
      const { deck: copy } = await api.cloneDeck(deck.shareSlug);
      toast.success(`Added “${copy.title}” to your library.`);
      navigate(`/decks/${copy.id}`);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setCloning(null);
    }
  };

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="eyebrow">Community</div>
          <h1>Explore public decks</h1>
          <p className="sub">Decks shared by other FlashMind users. Copy any deck into your library in one click.</p>
        </div>
      </div>

      <div className="panel panel-pad" style={{ display: 'grid', gap: 14, marginBottom: 20 }}>
        <div className="input-icon">
          <Icon name="search" size={16} />
          <input
            className="input"
            placeholder="Search public decks — biology, Spanish, WWII…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            aria-label="Search public decks"
          />
        </div>
        {subjects.length > 0 && (
          <div className="row" style={{ gap: 8 }}>
            {['All', ...subjects].map((s) => (
              <button key={s} className={`chip ${subject === s ? 'on' : ''}`} onClick={() => setSubject(s)}>
                {s}
              </button>
            ))}
          </div>
        )}
      </div>

      <ErrorNote message={error} onRetry={load} />

      {loading ? (
        <DeckGridSkeleton n={3} />
      ) : decks.length ? (
        <div className="deck-grid">
          {decks.map((d) => (
            <article key={d.id} className="deck-card" onClick={() => navigate(`/s/${d.shareSlug}`)} role="button" tabIndex={0}>
              <div className="deck-card-top">
                <div className="deck-emoji">{subjectEmoji(d.subject)}</div>
                <div className="grow">
                  <h3 className="deck-title">{d.title}</h3>
                  <div className="deck-meta" style={{ marginTop: 4 }}>
                    <span>by {d.author}</span>
                    <span className="dot" />
                    <span>{plural(d.cardCount, 'card')}</span>
                  </div>
                </div>
              </div>
              {d.description && (
                <div className="small muted" style={{ lineHeight: 1.5, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                  {d.description}
                </div>
              )}
              <div className="deck-card-row">
                <span>{d.subject} · {timeAgo(d.updatedAt)}</span>
                <button
                  className="btn btn-sm btn-soft"
                  disabled={cloning === d.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    clone(d);
                  }}
                >
                  {cloning === d.id ? <span className="spinner" /> : <Icon name="copy" size={12} />} Copy deck
                </button>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <EmptyState
          icon="globe"
          title="No public decks found"
          message="Nobody has shared a deck matching that search yet. You can make one of yours public from the deck page."
          action={
            <button className="btn" onClick={() => navigate('/decks')}>
              Go to my decks
            </button>
          }
        />
      )}
    </div>
  );
}
