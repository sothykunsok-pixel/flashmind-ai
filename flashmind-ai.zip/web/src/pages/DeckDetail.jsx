import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import Modal, { ConfirmDialog } from '../components/Modal.jsx';
import { CenteredLoader, ErrorNote } from '../components/States.jsx';
import { api } from '../lib/api.js';
import { useToast } from '../context/ToastContext.jsx';
import { subjectEmoji, timeAgo, plural } from '../lib/utils.js';

export default function DeckDetail() {
  const { deckId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [deck, setDeck] = useState(null);
  const [cards, setCards] = useState([]);
  const [folders, setFolders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [editCard, setEditCard] = useState(null);
  const [savingCard, setSavingCard] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deckBusy, setDeckBusy] = useState(false);
  const [expandOpen, setExpandOpen] = useState(false);
  const [expandCount, setExpandCount] = useState(5);
  const [expanding, setExpanding] = useState(false);
  const [renameOpen, setRenameOpen] = useState(false);
  const [renameValue, setRenameValue] = useState('');
  const [explain, setExplain] = useState(null);
  const [explaining, setExplaining] = useState(false);

  const load = async () => {
    setError('');
    try {
      const { deck: d, cards: cs } = await api.deck(deckId);
      setDeck(d);
      setCards(cs);
      setRenameValue(d.title);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    api.folders().then(({ folders: f }) => setFolders(f)).catch(() => {});
  }, [deckId]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return cards;
    return cards.filter((c) => c.question.toLowerCase().includes(q) || c.answer.toLowerCase().includes(q));
  }, [cards, search]);

  const patchDeck = async (patch, message) => {
    setDeckBusy(true);
    try {
      const { deck: d } = await api.updateDeck(deckId, patch);
      setDeck(d);
      if (message) toast.success(message);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setDeckBusy(false);
    }
  };

  const saveCard = async () => {
    if (!editCard?.question.trim() || !editCard?.answer.trim()) {
      toast.error('Both a question and answer are required.');
      return;
    }
    setSavingCard(true);
    try {
      if (editCard.id) {
        const { card } = await api.updateCard(editCard.id, {
          question: editCard.question,
          answer: editCard.answer,
          explanation: editCard.explanation,
          difficulty: editCard.difficulty,
        });
        setCards((cs) => cs.map((c) => (c.id === card.id ? card : c)));
        toast.success('Card updated.');
      } else {
        const { card } = await api.createCard(deckId, editCard);
        setCards((cs) => [...cs, card]);
        toast.success('Card added.');
      }
      setEditCard(null);
      load();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSavingCard(false);
    }
  };

  const removeCard = async (card) => {
    if (!confirm('Delete this card?')) return;
    try {
      await api.deleteCard(card.id);
      setCards((cs) => cs.filter((c) => c.id !== card.id));
      toast.success('Card deleted.');
    } catch (err) {
      toast.error(err.message);
    }
  };

  const expand = async () => {
    setExpanding(true);
    try {
      const res = await api.expandDeck(deckId, { count: expandCount });
      toast.success(`Added ${res.added} new card${res.added === 1 ? '' : 's'}${res.demo ? ' (demo mode)' : ''}.`);
      setExpandOpen(false);
      load();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setExpanding(false);
    }
  };

  const onExplain = async (card) => {
    setExplain({ question: card.question, answer: card.answer, text: '' });
    setExplaining(true);
    try {
      const res = await api.explain({ question: card.question, answer: card.answer, language: deck?.language || 'English' });
      setExplain({ question: card.question, answer: card.answer, text: res.explanation });
    } catch (err) {
      setExplain({ question: card.question, answer: card.answer, text: '', error: err.message });
    } finally {
      setExplaining(false);
    }
  };

  const shareUrl = deck?.shareSlug ? `${window.location.origin}/s/${deck.shareSlug}` : '';

  const copyShare = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast.success('Share link copied.');
    } catch {
      toast.info(shareUrl);
    }
  };

  if (loading) return <CenteredLoader label="Loading deck…" />;
  if (error) return <div className="page"><ErrorNote message={error} onRetry={load} /></div>;
  if (!deck) return null;

  return (
    <div className="page">
      <div className="page-head" style={{ marginBottom: 18 }}>
        <div className="grow">
          <button className="link-btn small" onClick={() => navigate('/decks')} style={{ marginBottom: 8 }}>
            ← My Flashcards
          </button>
          <div className="flex" style={{ gap: 12, alignItems: 'flex-start' }}>
            <div className="deck-emoji" style={{ width: 46, height: 46, fontSize: 21 }}>
              {subjectEmoji(deck.subject)}
            </div>
            <div>
              <h1
                style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'text' }}
                onClick={() => setRenameOpen(true)}
                title="Click to rename"
              >
                {deck.title}
                <Icon name="edit" size={15} style={{ color: 'var(--muted)', flex: 'none' }} />
              </h1>
              <div className="deck-meta" style={{ marginTop: 6 }}>
                <span className="badge badge-brand">{deck.subject}</span>
                <span className="badge">{deck.difficulty}</span>
                <span className="badge">{deck.language}</span>
                <span>{plural(deck.cardCount, 'card')}</span>
                <span className="dot" />
                <span>{deck.dueCount} due</span>
                <span className="dot" />
                <span>{deck.lastStudiedAt ? `studied ${timeAgo(deck.lastStudiedAt)}` : 'never studied'}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="page-head-actions">
          <button className="btn" onClick={() => api.downloadExport(deck.id, `${deck.title.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.csv`)}>
            <Icon name="download" size={15} /> CSV
          </button>
          <button className="btn" onClick={() => navigate(`/quiz/${deck.id}`)}>
            <Icon name="quiz" size={15} /> Quiz
          </button>
          <button className="btn btn-primary" onClick={() => navigate(`/study/${deck.id}`)}>
            <Icon name="play" size={15} /> Study deck
          </button>
        </div>
      </div>

      <div className="grid-3" style={{ marginBottom: 18 }}>
        <div className="panel panel-pad">
          <div className="stat-value" style={{ fontSize: 23 }}>{deck.progress}%</div>
          <div className="stat-label">Mastered</div>
          <div className="progress mt-2">
            <i style={{ width: `${deck.progress}%` }} />
          </div>
        </div>
        <div className="panel panel-pad">
          <div className="stat-value" style={{ fontSize: 23 }}>{deck.struggleCount}</div>
          <div className="stat-label">Cards you struggle with</div>
          <button className="link small mt-2" onClick={() => navigate(`/study/${deck.id}`)}>
            Smart review these →
          </button>
        </div>
        <div className="panel panel-pad" style={{ display: 'grid', gap: 8 }}>
          <div className="flex between">
            <div>
              <div style={{ fontWeight: 650, fontSize: 13.5 }}>Public deck</div>
              <div className="small muted">Anyone with the link can study and copy it.</div>
            </div>
            <button
              className={`switch ${deck.isPublic ? 'on' : ''}`}
              aria-label="Toggle public sharing"
              disabled={deckBusy}
              onClick={() => patchDeck({ isPublic: !deck.isPublic }, deck.isPublic ? 'Deck is private again.' : 'Deck is now public.')}
            />
          </div>
          {deck.isPublic && (
            <div className="flex" style={{ gap: 6 }}>
              <input className="input" readOnly value={shareUrl} style={{ height: 32, fontSize: 12 }} onFocus={(e) => e.target.select()} />
              <button className="btn btn-sm" onClick={copyShare}>
                <Icon name="link" size={13} /> Copy
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h3>Cards ({cards.length})</h3>
          <div className="right flex" style={{ gap: 8 }}>
            <div className="input-icon">
              <Icon name="search" size={14} />
              <input
                className="input"
                style={{ height: 34, fontSize: 13, width: 190 }}
                placeholder="Search cards…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <button className="btn btn-sm" onClick={() => setExpandOpen(true)}>
              <Icon name="sparkles" size={13} /> Generate more
            </button>
            <button
              className="btn btn-sm btn-primary"
              onClick={() =>
                setEditCard({ question: '', answer: '', explanation: '', difficulty: deck.difficulty })
              }
            >
              <Icon name="plus" size={13} /> Add card
            </button>
          </div>
        </div>

        <div className="panel-body" style={{ display: 'grid', gap: 10 }}>
          {filtered.length === 0 && (
            <div className="empty">
              <h3>{cards.length ? 'No cards match that search' : 'This deck has no cards yet'}</h3>
              <p>{cards.length ? 'Try a different search term.' : 'Add a card manually, or let AI generate more from your notes.'}</p>
            </div>
          )}

          {filtered.map((c, i) => (
            <div key={c.id} className="card-row">
              <div className="card-row-top">
                <div className="q-index">{i + 1}</div>
                <div className="grow">
                  <div className="q-text">{c.question}</div>
                  <div className="a-text" style={{ paddingLeft: 0, marginTop: 4 }}>
                    {c.answer}
                  </div>
                  {c.explanation && (
                    <div className="small muted" style={{ marginTop: 4 }}>
                      <Icon name="bulb" size={11} style={{ verticalAlign: '-1px' }} /> {c.explanation}
                    </div>
                  )}
                  <div className="flex" style={{ gap: 6, marginTop: 8 }}>
                    <span className={`badge ${c.difficulty === 'easy' ? 'badge-success' : c.difficulty === 'hard' ? 'badge-danger' : 'badge-warn'}`}>
                      {c.difficulty}
                    </span>
                    {c.reps > 0 ? (
                      <span className="badge">seen {c.reps}× · ease {Number(c.ease).toFixed(2)}</span>
                    ) : (
                      <span className="badge">new</span>
                    )}
                    {c.lastGrade === 'again' && <span className="badge badge-danger">needs work</span>}
                  </div>
                </div>
                <div className="c-actions">
                  <button className="icon-btn" title="Explain simply" onClick={() => onExplain(c)} aria-label="Explain">
                    <Icon name="bulb" size={13} />
                  </button>
                  <button className="icon-btn" title="Edit card" onClick={() => setEditCard({ ...c })} aria-label="Edit card">
                    <Icon name="edit" size={13} />
                  </button>
                  <button className="icon-btn danger" title="Delete card" onClick={() => removeCard(c)} aria-label="Delete card">
                    <Icon name="trash" size={13} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex mt-3" style={{ gap: 10, flexWrap: 'wrap' }}>
        <button className="btn" onClick={async () => {
          try {
            const { deck: copy } = await api.duplicateDeck(deck.id);
            toast.success(`Duplicated as “${copy.title}”.`);
            navigate(`/decks/${copy.id}`);
          } catch (err) {
            toast.error(err.message);
          }
        }}>
          <Icon name="copy" size={15} /> Duplicate deck
        </button>
        <select
          className="select"
          style={{ width: 200 }}
          value={deck.folderId || ''}
          onChange={(e) => patchDeck({ folderId: e.target.value || null }, 'Moved to folder.')}
          aria-label="Move to folder"
        >
          <option value="">No folder</option>
          {folders.map((f) => (
            <option key={f.id} value={f.id}>
              {f.name}
            </option>
          ))}
        </select>
        <button className="btn btn-danger-ghost right" onClick={() => setConfirmDelete(true)}>
          <Icon name="trash" size={15} /> Delete deck
        </button>
      </div>

      {/* edit / add card */}
      <Modal
        open={Boolean(editCard)}
        onClose={() => setEditCard(null)}
        title={editCard?.id ? 'Edit card' : 'Add a card'}
        subtitle="Good cards ask one clear question and answer it directly."
        footer={
          <>
            <button className="btn" onClick={() => setEditCard(null)} disabled={savingCard}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={saveCard} disabled={savingCard}>
              {savingCard ? <span className="spinner" /> : <Icon name="check" size={15} />}
              {editCard?.id ? 'Save changes' : 'Add card'}
            </button>
          </>
        }
      >
        {editCard && (
          <>
            <div className="field">
              <label className="label">Question</label>
              <textarea
                className="textarea"
                style={{ minHeight: 80 }}
                value={editCard.question}
                onChange={(e) => setEditCard({ ...editCard, question: e.target.value })}
                autoFocus
              />
            </div>
            <div className="field">
              <label className="label">Answer</label>
              <textarea
                className="textarea"
                style={{ minHeight: 100 }}
                value={editCard.answer}
                onChange={(e) => setEditCard({ ...editCard, answer: e.target.value })}
              />
            </div>
            <div className="field">
              <label className="label">Explanation / hint</label>
              <input
                className="input"
                value={editCard.explanation || ''}
                onChange={(e) => setEditCard({ ...editCard, explanation: e.target.value })}
                placeholder="Optional — an example or memory hook"
              />
            </div>
            <div className="field">
              <label className="label">Difficulty</label>
              <select
                className="select"
                value={editCard.difficulty}
                onChange={(e) => setEditCard({ ...editCard, difficulty: e.target.value })}
              >
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </div>
          </>
        )}
      </Modal>

      {/* generate more */}
      <Modal
        open={expandOpen}
        onClose={() => setExpandOpen(false)}
        title="Generate more cards"
        subtitle="The AI reads this deck’s existing cards and adds new ones without repeating them."
        footer={
          <>
            <button className="btn" onClick={() => setExpandOpen(false)} disabled={expanding}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={expand} disabled={expanding}>
              {expanding ? <span className="spinner" /> : <Icon name="sparkles" size={15} />}
              Generate {expandCount} cards
            </button>
          </>
        }
      >
        <div className="field">
          <label className="label">How many new cards?</label>
          <div className="row" style={{ gap: 8 }}>
            {[5, 10, 15, 20].map((n) => (
              <button key={n} className={`chip ${expandCount === n ? 'on' : ''}`} onClick={() => setExpandCount(n)}>
                {n}
              </button>
            ))}
          </div>
        </div>
        <div className="ai-note">
          <Icon name="info" size={15} style={{ flex: 'none', marginTop: 1 }} />
          <div>New cards are added to the deck and scheduled as new — your existing progress is untouched.</div>
        </div>
      </Modal>

      {/* rename */}
      <Modal
        open={renameOpen}
        onClose={() => setRenameOpen(false)}
        title="Rename deck"
        footer={
          <>
            <button className="btn" onClick={() => setRenameOpen(false)}>Cancel</button>
            <button
              className="btn btn-primary"
              disabled={!renameValue.trim() || deckBusy}
              onClick={async () => {
                await patchDeck({ title: renameValue.trim() }, 'Deck renamed.');
                setRenameOpen(false);
              }}
            >
              Save
            </button>
          </>
        }
      >
        <div className="field">
          <label className="label">Deck title</label>
          <input
            className="input"
            value={renameValue}
            onChange={(e) => setRenameValue(e.target.value)}
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && e.target.blur()}
          />
        </div>
      </Modal>

      {/* explain */}
      <Modal
        open={Boolean(explain)}
        onClose={() => setExplain(null)}
        title="Explain it simply"
        subtitle={`${deck.language} · plain language`}
      >
        {explain && (
          <div style={{ display: 'grid', gap: 12 }}>
            <div className="review-item">
              <div className="rq">{explain.question}</div>
              <div className="ra">{explain.answer}</div>
            </div>
            {explaining ? (
              <div className="flex muted">
                <span className="spinner" /> Thinking…
              </div>
            ) : explain.error ? (
              <div className="alert alert-error">{explain.error}</div>
            ) : (
              <p style={{ lineHeight: 1.65, whiteSpace: 'pre-wrap' }}>{explain.text}</p>
            )}
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={confirmDelete}
        onClose={() => setConfirmDelete(false)}
        busy={deckBusy}
        title={`Delete “${deck.title}”?`}
        message={`This removes ${cards.length} cards and their study history. This cannot be undone.`}
        onConfirm={async () => {
          setDeckBusy(true);
          try {
            await api.deleteDeck(deck.id);
            toast.success('Deck deleted.');
            navigate('/decks');
          } catch (err) {
            toast.error(err.message);
            setDeckBusy(false);
          }
        }}
      />
    </div>
  );
}
