import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import ActivityChart from '../components/ActivityChart.jsx';
import DeckCard from '../components/DeckCard.jsx';
import { DeckGridSkeleton, ErrorNote, StatSkeleton, EmptyState } from '../components/States.jsx';
import { api } from '../lib/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { subjectEmoji, timeAgo } from '../lib/utils.js';

export default function Dashboard() {
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [recent, setRecent] = useState([]);
  const [continueDeck, setContinueDeck] = useState(null);
  const [activity, setActivity] = useState([]);
  const [range, setRange] = useState(7);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setError('');
    try {
      const [{ stats: s, recentDecks, continueDeck: cd }, { activity: a }] = await Promise.all([
        api.stats(),
        api.activity(range),
      ]);
      setStats(s);
      setRecent(recentDecks);
      setContinueDeck(cd);
      setActivity(a);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    api
      .activity(range)
      .then(({ activity: a }) => setActivity(a))
      .catch(() => {});
  }, [range]);

  const duplicate = async (deck) => {
    try {
      await api.duplicateDeck(deck.id);
      toast.success(`Duplicated “${deck.title}”.`);
      load();
    } catch (err) {
      toast.error(err.message);
    }
  };

  const remove = async (deck) => {
    if (!confirm(`Delete “${deck.title}” and all of its cards? This cannot be undone.`)) return;
    try {
      await api.deleteDeck(deck.id);
      toast.success('Deck deleted.');
      load();
    } catch (err) {
      toast.error(err.message);
    }
  };

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const firstName = (user?.name || 'there').split(' ')[0];

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="eyebrow">{new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</div>
          <h1>
            {greeting}, {firstName} 👋
          </h1>
          <p className="sub">
            {stats?.dueToday
              ? `You have ${stats.dueToday} card${stats.dueToday === 1 ? '' : 's'} due for review today.`
              : 'Nothing is due right now — a great time to build a new deck.'}
          </p>
        </div>
        <div className="page-head-actions">
          <button className="btn" onClick={() => navigate('/study')}>
            <Icon name="book" size={16} />
            Study mode
          </button>
          <button className="btn btn-primary" onClick={() => navigate('/create')}>
            <Icon name="sparkles" size={16} />
            Create flashcards
          </button>
        </div>
      </div>

      <ErrorNote message={error} onRetry={load} />

      {loading ? (
        <StatSkeleton n={5} />
      ) : (
        <div className="stat-grid">
          <Stat icon="layers" value={stats.cardCount} label="Total flashcards" foot={`${stats.deckCount} deck${stats.deckCount === 1 ? '' : 's'}`} footIcon="layers" />
          <Stat icon="book" value={stats.reviewsToday} label="Reviewed today" foot={`${stats.studiedToday} unique card${stats.studiedToday === 1 ? '' : 's'}`} footIcon="check" />
          <Stat icon="flame" value={`${stats.streak} day${stats.streak === 1 ? '' : 's'}`} label="Study streak" foot={stats.streak > 0 ? 'Keep it alive today' : 'Start a streak now'} footIcon="zap" />
          <Stat icon="target" value={`${stats.accuracy}%`} label="Overall accuracy" foot={`${stats.totalReviews} reviews logged`} footIcon="trophy" />
          <Stat icon="clock" value={stats.dueToday} label="Cards due now" foot={`${stats.mastered} mastered`} footIcon="checkCircle" />
        </div>
      )}

      <div className="section dash-split">
        <div className="panel">
          <div className="panel-head">
            <h3>Study activity</h3>
            <div className="right segmented">
              <button className={range === 7 ? 'on' : ''} onClick={() => setRange(7)}>
                7 days
              </button>
              <button className={range === 30 ? 'on' : ''} onClick={() => setRange(30)}>
                30 days
              </button>
            </div>
          </div>
          <div className="panel-body">
            <div className="flex between" style={{ marginBottom: 6 }}>
              <div>
                <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-0.04em' }}>
                  {activity.reduce((a, d) => a + d.reviews, 0)}
                </div>
                <div className="small muted" style={{ fontWeight: 600 }}>
                  reviews in this period
                </div>
              </div>
              <div className="chart-legend">
                <span>
                  <i style={{ background: 'linear-gradient(135deg,#8b5cf6,#3b82f6)' }} /> Reviews
                </span>
                <span>
                  <i style={{ background: 'var(--brand)', opacity: 0.5 }} /> Goal {stats?.dailyGoal ?? 20}
                </span>
              </div>
            </div>
            <ActivityChart data={activity} goal={stats?.dailyGoal ?? 20} />
          </div>
        </div>

        <div style={{ display: 'grid', gap: 16 }}>
          <div className="panel panel-pad">
            <div className="flex between">
              <h3 style={{ fontSize: 14.5 }}>Daily goal</h3>
              <span className="badge badge-brand">{stats?.goalPercent ?? 0}%</span>
            </div>
            <div className="flex" style={{ gap: 16, marginTop: 14 }}>
              <div
                className="score-ring"
                style={{ ['--pct']: stats?.goalPercent ?? 0, width: 92, height: 92, margin: 0, flex: 'none' }}
              >
                <div className="inner">
                  <div className="pct" style={{ fontSize: 20 }}>
                    {stats?.reviewsToday ?? 0}
                  </div>
                  <div className="of">of {stats?.dailyGoal ?? 20}</div>
                </div>
              </div>
              <div className="small muted" style={{ lineHeight: 1.55 }}>
                {stats?.goalPercent >= 100
                  ? 'Goal smashed for today. Anything more is bonus retention. 🔥'
                  : `Review ${Math.max(0, (stats?.dailyGoal ?? 20) - (stats?.reviewsToday ?? 0))} more cards to hit today's goal.`}
              </div>
            </div>
          </div>

          {continueDeck ? (
            <div
              className="panel panel-pad"
              style={{ background: 'var(--grad-soft)', borderColor: 'color-mix(in srgb, var(--brand) 22%, var(--border))' }}
            >
              <div className="small" style={{ fontWeight: 700, color: 'var(--brand)', letterSpacing: '0.06em', textTransform: 'uppercase', fontSize: 10.5 }}>
                Continue studying
              </div>
              <div className="flex" style={{ marginTop: 10, alignItems: 'flex-start' }}>
                <div className="deck-emoji">{subjectEmoji(continueDeck.subject)}</div>
                <div className="grow">
                  <div style={{ fontWeight: 700, fontSize: 14.5 }}>{continueDeck.title}</div>
                  <div className="small muted">
                    {continueDeck.cardCount} cards · studied {timeAgo(continueDeck.lastStudiedAt)}
                  </div>
                </div>
              </div>
              <div className="progress" style={{ marginTop: 12 }}>
                <i style={{ width: `${continueDeck.progress}%` }} />
              </div>
              <button
                className="btn btn-primary btn-block"
                style={{ marginTop: 12 }}
                onClick={() => navigate(`/study/${continueDeck.id}`)}
              >
                <Icon name="play" size={15} /> Resume deck
              </button>
            </div>
          ) : (
            <div className="panel panel-pad">
              <h3 style={{ fontSize: 14.5 }}>Continue studying</h3>
              <p className="small muted mt-1">Study a deck and it will show up here for a one-click resume.</p>
              <button className="btn btn-block mt-2" onClick={() => navigate('/decks')}>
                Browse decks
              </button>
            </div>
          )}
        </div>
      </div>

      <section className="section">
        <div className="section-head">
          <h2>Recent decks</h2>
          <button className="link" onClick={() => navigate('/decks')}>
            View all <Icon name="arrowRight" size={14} />
          </button>
        </div>
        {loading ? (
          <DeckGridSkeleton n={3} />
        ) : recent.length ? (
          <div className="deck-grid">
            {recent.map((d) => (
              <DeckCard
                key={d.id}
                deck={d}
                onOpen={() => navigate(`/decks/${d.id}`)}
                onStudy={() => navigate(`/study/${d.id}`)}
                onEdit={() => navigate(`/decks/${d.id}`)}
                onDuplicate={duplicate}
                onDelete={remove}
              />
            ))}
          </div>
        ) : (
          <EmptyState
            icon="sparkles"
            title="Your flashcard library is empty"
            message="Create your first deck from a topic, some notes, or a PDF — it takes about 20 seconds."
            action={
              <button className="btn btn-primary" onClick={() => navigate('/create')} style={{ marginTop: 6 }}>
                <Icon name="sparkles" size={15} /> Create flashcards with AI
              </button>
            }
          />
        )}
      </section>

      <section className="section">
        <div className="section-head">
          <h2>Jump back in</h2>
        </div>
        <div className="grid-3">
          {[
            { t: 'Create from a PDF', d: 'Upload lecture slides or a chapter and get cards instantly.', i: 'file', to: '/create', c: '#8b5cf6' },
            { t: 'Take an AI quiz', d: 'Turn any deck into a multiple-choice or short-answer test.', i: 'quiz', to: '/quiz', c: '#3b82f6' },
            { t: 'Track your progress', d: 'See mastery per deck and every quiz attempt.', i: 'progress', to: '/progress', c: '#10b981' },
          ].map((x) => (
            <button
              key={x.t}
              className="panel panel-pad"
              onClick={() => navigate(x.to)}
              style={{ textAlign: 'left', cursor: 'pointer', display: 'grid', gap: 8 }}
            >
              <div className="stat-icon" style={{ background: `${x.c}1a`, color: x.c }}>
                <Icon name={x.i} size={17} />
              </div>
              <div style={{ fontWeight: 680, fontSize: 14.5 }}>{x.t}</div>
              <div className="small muted" style={{ lineHeight: 1.5 }}>
                {x.d}
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ icon, value, label, foot, footIcon }) {
  return (
    <div className="stat">
      <div className="stat-icon">
        <Icon name={icon} size={17} />
      </div>
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
      {foot && (
        <div className="stat-foot" style={{ color: 'var(--muted)' }}>
          <Icon name={footIcon} size={12} />
          {foot}
        </div>
      )}
    </div>
  );
}
