import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import { api } from '../lib/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';

export default function ResetPassword() {
  const [params] = useSearchParams();
  const token = params.get('token') || '';
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const { refresh } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (password !== confirm) return setError('Those passwords do not match.');
    setBusy(true);
    try {
      await api.resetPassword(token, password);
      await refresh();
      toast.success('Password updated — you are logged in.');
      navigate('/', { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth" style={{ gridTemplateColumns: '1fr' }}>
      <section className="auth-form-wrap" style={{ minHeight: '100vh' }}>
        <div className="auth-card">
          <img src="/logo-mark-gradient.png" alt="FlashMind AI" style={{ height: 38, marginBottom: 18 }} />
          <h1>Choose a new password</h1>
          <p className="sub">Pick something at least 8 characters long.</p>

          {!token ? (
            <div className="alert alert-error">
              This reset link is missing its token. Request a new one from the login page.
            </div>
          ) : (
            <form onSubmit={submit} style={{ display: 'grid', gap: 14 }}>
              <div className="field">
                <label className="label" htmlFor="pw">
                  New password
                </label>
                <input
                  id="pw"
                  className="input"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  minLength={8}
                  required
                  autoComplete="new-password"
                />
              </div>
              <div className="field">
                <label className="label" htmlFor="pw2">
                  Confirm password
                </label>
                <input
                  id="pw2"
                  className="input"
                  type="password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  minLength={8}
                  required
                  autoComplete="new-password"
                />
              </div>
              {error && <div className="alert alert-error">{error}</div>}
              <button className="btn btn-primary btn-lg" disabled={busy}>
                {busy ? <span className="spinner" /> : <Icon name="lock" size={16} />}
                Update password
              </button>
            </form>
          )}

          <div className="auth-switch">
            <Link to="/login" className="link-btn">
              ← Back to login
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
