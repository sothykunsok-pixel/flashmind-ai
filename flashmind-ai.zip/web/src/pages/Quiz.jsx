import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import { CenteredLoader, ErrorNote, EmptyState } from '../components/States.jsx';
import { api } from '../lib/api.js';
import { useToast } from '../context/ToastContext.jsx';
import { isAnswerClose, keywordScore, subjectEmoji, plural } from '../lib/utils.js';

const TYPES = [
  { id: 'mixed', label: 'Mixed', icon: 'layers' },
  { id: 'multiple_choice', label: 'Multiple choice', icon: 'checkCircle' },
  { id: 'true_false', label: 'True / False', icon: 'flag' },
  { id: 'fill_blank', label: 'Fill in the blank', icon: 'edit' },
  { id: 'short_answer', label: 'Short answer', icon: 'book' },
];

const TYPE_LABEL = {
  multiple_choice: 'Multiple choice',
  true_false: 'True / False',
  fill_blank: 'Fill in the blank',
  short_answer: 'Short answer',
};

export default function Quiz() {
  const { deckId: routeDeckId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [decks, setDecks] = useState(null);
  const [deckId, setDeckId] = useState(routeDeckId ? Number(routeDeckId) : '');
  const [type, setType] = useState('mixed');
  const [count, setCount] = useState(8);
  const [phase, setPhase] = useState('setup');
  const [error, setError] = useState('');

  const [questions, setQuestions] = useState([]);
  const [index, setIndex] = useState(0);
  const [answer, setAnswer] = useState(null);
  const [checked, setChecked] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [results, setResults] = useState([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api
      .decks()
      .then(({ decks: d }) => {
        setDecks(d);
        if (!routeDeckId && d.length) setDeckId(d[0].id);
      })
      .catch((err) => setError(err.message));
  }, [routeDeckId]);

  const selectedDeck = useMemo(() => (decks || []).find((d) => d.id === Number(deckId)), [decks, deckId]);
  const current = questions[index];

  const start = async () => {
    if (!deckId) {
      setError('Choose a deck first.');
      return;
    }
    setError('');
    setBusy(true);
    try {
      const res = await api.generateQuiz({
        deckId: Number(deckId),
        type,
        count,
        language: selectedDeck?.language || 'English',
        deckTitle: selectedDeck?.title || '',
      });
      setQuestions(res.questions);
      setIndex(0);
      setAnswer(null);
      setChecked(false);
      setResults([]);
      setPhase('playing');
      if (res.demo) toast.info('Demo mode: quiz built from the deck’s own cards. Add AI_API_KEY for AI-written questions.', 6000);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const evaluate = (q, a) => {
    if (a === null || a === undefined || a === '') return false;
    if (q.type === 'multiple_choice') return a === q.answerIndex;
    if (q.type === 'true_false') return a === q.answer;
    if (q.type === 'fill_blank') return (q.acceptedAnswers || [q.answer]).some((x) => isAnswerClose(a, x));
    if (q.type === 'short_answer') return keywordScore(a, q.acceptedKeywords || []) >= 0.6;
    return false;
  };

  const submit = () => {
    if (answer === null || answer === '') return;
    const ok = evaluate(current, answer);
    setIsCorrect(ok);
    setChecked(true);
    setResults((r) => [...r, { question: current, given: answer, correct: ok }]);
  };

  const next = async () => {
    if (index + 1 >= questions.length) {
      const correct = results.filter((r) => r.correct).length;
      setPhase('results');
      try {
        await api.saveQuizAttempt({ deckId: Number(deckId), type, total: questions.length, correct });
      } catch {}
    } else {
      setIndex((i) => i + 1);
      setAnswer(null);
      setChecked(false);
    }
  };

  const restart = () => {
    setPhase('setup');
    setQuestions([]);
    setResults([]);
    setIndex(0);
    setAnswer(null);
    setChecked(false);
  };

  /* ───────────────── setup ───────────────── */
  if (phase === 'setup') {
    return (
      <div className="page">
        <div className="page-head">
          <div>
            <div className="eyebrow">AI quiz</div>
            <h1>Test yourself</h1>
            <p className="sub">Turn any deck into a quiz. The AI writes new questions grounded in your own cards.</p>
          </div>
        </div>

        <ErrorNote message={error} />

        {decks === null ? (
          <CenteredLoader label="Loading decks…" />
        ) : decks.length === 0 ? (
          <EmptyState
            icon="quiz"
            title="You need a deck first"
            message="Quizzes are generated from your flashcards. Create a deck and come back."
            action={
              <Link to="/create" className="btn btn-primary">
                <Icon name="sparkles" size={15} /> Create flashcards
              </Link>
            }
          />
        ) : (
          <div className="create-grid">
            <div className="panel panel-pad" style={{ display: 'grid', gap: 18 }}>
              <div className="field">
                <label className="label">Deck</label>
                <div style={{ display: 'grid', gap: 8, maxHeight: 320, overflow: 'auto' }}>
                  {decks.map((d) => (
                    <button
                      key={d.id}
                      className="option"
                      style={{ borderColor: Number(deckId) === d.id ? 'var(--brand)' : undefined, background: Number(deckId) === d.id ? 'var(--brand-soft)' : undefined }}
                      onClick={() => setDeckId(d.id)}
                    >
                      <span className="deck-emoji" style={{ width: 32, height: 32, fontSize: 15 }}>
                        {subjectEmoji(d.subject)}
                      </span>
                      <span className="grow">
                        <span style={{ display: 'block', fontWeight: 650 }}>{d.title}</span>
                        <span className="small muted">
                          {plural(d.cardCount, 'card')} · {d.subject}
                        </span>
                      </span>
                      {Number(deckId) === d.id && <Icon name="check" size={16} style={{ color: 'var(--brand)' }} />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="field">
                <label className="label">Quiz type</label>
                <div className="row" style={{ gap: 8 }}>
                  {TYPES.map((t) => (
                    <button key={t.id} className={`chip ${type === t.id ? 'on' : ''}`} onClick={() => setType(t.id)}>
                      <Icon name={t.icon} size={12} /> {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="field">
                <label className="label">Number of questions</label>
                <div className="row" style={{ gap: 8 }}>
                  {[5, 8, 10, 15, 20].map((n) => (
                    <button key={n} className={`chip ${count === n ? 'on' : ''}`} onClick={() => setCount(n)}>
                      {n}
                    </button>
                  ))}
                </div>
                <span className="hint">
                  {selectedDeck && count > selectedDeck.cardCount
                    ? `This deck only has ${selectedDeck.cardCount} cards — you may get fewer questions.`
                    : 'Questions are written fresh each time from your cards.'}
                </span>
              </div>

              <button className="btn btn-primary btn-lg btn-block" onClick={start} disabled={busy || !deckId}>
                {busy ? <span className="spinner" /> : <Icon name="sparkles" size={17} />}
                {busy ? 'Writing your quiz…' : 'Generate quiz'}
              </button>
            </div>

            <div className="panel panel-pad" style={{ display: 'grid', gap: 14, alignSelf: 'start' }}>
              <h3 style={{ fontSize: 14.5 }}>How it works</h3>
              {[
                ['Grounded in your deck', 'Questions only test facts that appear in the selected deck’s cards.'],
                ['Instant feedback', 'You see the correct answer and an explanation right after answering.'],
                ['Tracked over time', 'Every attempt is saved so you can watch your scores improve on the Progress page.'],
              ].map(([t, d]) => (
                <div key={t} style={{ display: 'grid', gap: 3 }}>
                  <div style={{ fontWeight: 650, fontSize: 13 }}>{t}</div>
                  <div className="small muted" style={{ lineHeight: 1.5 }}>
                    {d}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  /* ───────────────── results ───────────────── */
  if (phase === 'results') {
    const correct = results.filter((r) => r.correct).length;
    const pct = Math.round((correct / Math.max(1, questions.length)) * 100);
    const wrong = results.filter((r) => !r.correct);

    return (
      <div className="page">
        <div className="quiz-card panel">
          <div className="result-hero">
            <div className="score-ring" style={{ ['--pct']: pct }}>
              <div className="inner">
                <div className="pct">{pct}%</div>
                <div className="of">
                  {correct}/{questions.length} correct
                </div>
              </div>
            </div>
            <h2 style={{ fontSize: 23 }}>
              {pct >= 90 ? 'Outstanding 🏆' : pct >= 70 ? 'Solid work — keep going' : pct >= 50 ? 'Getting there' : 'Time for another review'}
            </h2>
            <p className="muted mt-1">
              {pct >= 90
                ? 'You have this deck locked down. Try a harder deck or expand this one.'
                : 'Review the missed questions below, then run the quiz again.'}
            </p>
          </div>

          <div className="row mt-3" style={{ justifyContent: 'center' }}>
            <button className="btn" onClick={() => setPhase('playing')} disabled={!questions.length}>
              <Icon name="eye" size={15} /> Review answers
            </button>
            <button className="btn" onClick={start} disabled={busy}>
              <Icon name="refresh" size={15} /> Retake
            </button>
            <button className="btn" onClick={restart}>
              <Icon name="settings" size={15} /> New quiz
            </button>
            <button className="btn btn-primary" onClick={() => navigate(`/study/${deckId}`)}>
              <Icon name="book" size={15} /> Study this deck
            </button>
          </div>

          {wrong.length > 0 && (
            <div className="mt-3" style={{ display: 'grid', gap: 8 }}>
              <h3 style={{ fontSize: 14 }}>Missed questions ({wrong.length})</h3>
              {wrong.map((r, i) => (
                <div key={i} className="review-item">
                  <div className="rq">{r.question.question}</div>
                  <div className="ra">
                    Correct answer:{' '}
                    {r.question.type === 'multiple_choice'
                      ? r.question.options[r.question.answerIndex]
                      : r.question.type === 'true_false'
                        ? r.question.answer
                          ? 'True'
                          : 'False'
                        : r.question.answer}
                  </div>
                  {r.question.explanation && <div className="small muted">{r.question.explanation}</div>}
                </div>
              ))}
            </div>
          )}

          <div className="mt-3" style={{ display: 'grid', gap: 6 }}>
            <h3 style={{ fontSize: 14 }}>All answers</h3>
            {results.map((r, i) => (
              <div key={i} className="flex between" style={{ padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                <span className="small truncate" style={{ maxWidth: '75%' }}>
                  {r.question.question}
                </span>
                <span className={`badge ${r.correct ? 'badge-success' : 'badge-danger'}`}>{r.correct ? 'correct' : 'missed'}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  /* ───────────────── playing ───────────────── */
  if (!current) return <CenteredLoader label="Building your quiz…" />;

  const optionDisabled = checked;

  return (
    <div className="page">
      <div className="quiz-card panel">
        <div className="quiz-progress">
          <span>
            Question {index + 1} of {questions.length}
          </span>
          <div className="progress">
            <i style={{ width: `${((index + (checked ? 1 : 0)) / questions.length) * 100}%` }} />
          </div>
          <span>{results.filter((r) => r.correct).length} correct</span>
        </div>

        <div className="flex between">
          <span className="badge badge-brand">{TYPE_LABEL[current.type] || current.type}</span>
          <button className="link-btn small" onClick={restart}>
            Exit quiz
          </button>
        </div>

        <div className="quiz-q">{current.question}</div>

        {current.type === 'multiple_choice' && (
          <div className="option-list">
            {current.options.map((opt, i) => {
              const cls = checked
                ? i === current.answerIndex
                  ? 'option correct'
                  : i === answer
                    ? 'option wrong'
                    : 'option'
                : `option ${answer === i ? 'correct' : ''}`;
              return (
                <button key={i} className={cls} onClick={() => !checked && setAnswer(i)} disabled={optionDisabled}>
                  <span className="opt-key">{String.fromCharCode(65 + i)}</span>
                  <span>{opt}</span>
                  {checked && i === current.answerIndex && <Icon name="check" size={16} style={{ marginLeft: 'auto' }} />}
                </button>
              );
            })}
          </div>
        )}

        {current.type === 'true_false' && (
          <div className="option-list">
            {[true, false].map((v) => {
              const cls = checked
                ? v === current.answer
                  ? 'option correct'
                  : v === answer
                    ? 'option wrong'
                    : 'option'
                : `option ${answer === v ? 'correct' : ''}`;
              return (
                <button key={String(v)} className={cls} onClick={() => !checked && setAnswer(v)} disabled={optionDisabled}>
                  <span className="opt-key">{v ? 'T' : 'F'}</span>
                  <span>{v ? 'True' : 'False'}</span>
                </button>
              );
            })}
          </div>
        )}

        {(current.type === 'fill_blank' || current.type === 'short_answer') && (
          <div className="quiz-input">
            <input
              className="input"
              style={{ height: 48, fontSize: 15 }}
              placeholder={current.type === 'fill_blank' ? 'Type the missing word or phrase…' : 'Type your answer…'}
              value={answer || ''}
              onChange={(e) => setAnswer(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !checked && submit()}
              disabled={checked}
              autoFocus
            />
            {current.type === 'short_answer' && (
              <span className="hint">Short answers are graded on key terms — exact wording is not required.</span>
            )}
          </div>
        )}

        {checked && (
          <div className={`feedback ${isCorrect ? 'ok' : 'no'}`}>
            <div style={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
              <Icon name={isCorrect ? 'checkCircle' : 'xCircle'} size={17} />
              {isCorrect ? 'Correct' : 'Not quite'}
            </div>
            <div style={{ marginTop: 6 }}>
              {!isCorrect && (
                <div>
                  <strong>Answer:</strong>{' '}
                  {current.type === 'multiple_choice'
                    ? current.options[current.answerIndex]
                    : current.type === 'true_false'
                      ? current.answer
                        ? 'True'
                        : 'False'
                      : current.answer}
                </div>
              )}
              {current.explanation && <div style={{ marginTop: 4 }}>{current.explanation}</div>}
            </div>
          </div>
        )}

        <div className="row mt-3" style={{ justifyContent: 'flex-end' }}>
          {!checked ? (
            <button
              className="btn btn-primary"
              onClick={submit}
              disabled={answer === null || answer === ''}
            >
              Check answer <Icon name="arrowRight" size={15} />
            </button>
          ) : (
            <button className="btn btn-primary" onClick={next}>
              {index + 1 >= questions.length ? 'See results' : 'Next question'} <Icon name="arrowRight" size={15} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
