import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import ActivityChart from '../components/ActivityChart.jsx';
import { CenteredLoader, ErrorNote } from '../components/States.jsx';
import { api } from '../lib/api.js';
import { subjectEmoji, timeAgo, plural } from '../lib/utils.js';

export default function Progress() {
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [decks, setDecks] = useState([]);
  const [activity, setActivity] = useState([]);
  const [attempts, setAttempts] = useState([]);
  const [range, setRange] = useState(7);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = async () => {
    setError('');
    try {
      const [{ stats: s }, { decks: d }, { activity: a }, { attempts: q }] = await Promise.all([
        api.stats(),
        api.decks(),
        api.activity(range),
        api.quizAttempts(),
      ]);
      setStats(s);
      setDecks(d);
      setActivity(a);
      setAttempts(q);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    api.activity(range).then(({ activity: a }) => setActivity(a)).catch(() => {});
  }, [range]);

  if (loading) return <CenteredLoader label="Crunching your numbers…" />;

  const totalReviews = activity.reduce((a, d) => a + d.reviews, 0);
  const totalCorrect = activity.reduce((a, d) => a + d.correct, 0);
  const periodAccuracy = totalReviews ? Math.round((totalCorrect / totalReviews) * 100) : 0;

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="eyebrow">Analytics</div>
          <h1>Your progress</h1>
          <p className="sub">Retention, mastery and quiz scores across every deck you have built.</p>
        </div>
      </div>

      <ErrorNote message={error} onRetry={load} />

      <div className="stat-grid">
        <Stat icon="flame" value={`${stats.streak}d`} label="Current streak" />
        <Stat icon="target" value={`${stats.accuracy}%`} label="All-time accuracy" />
        <Stat icon="checkCircle" value={stats.mastered} label="Cards mastered" />
        <Stat icon="clock" value={stats.totalReviews} label="Total reviews" />
      </div>

      <div className="panel mt-3">
        <div className="panel-head">
          <h3>Review activity</h3>
          <div className="right segmented">
            <button className={range === 7 ? 'on' : ''} onClick={() => setRange(7)}>7 days</button>
            <button className={range === 30 ? 'on' : ''} onClick={() => setRange(30)}>30 days</button>
          </div>
        </div>
        <div className="panel-body">
          <div className="row" style={{ gap: 26, marginBottom: 12 }}>
            <div>
              <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.03em' }}>{totalReviews}</div>
              <div className="small muted" style={{ fontWeight: 600 }}>reviews</div>
            </div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.03em' }}>{periodAccuracy}%</div>
              <div className="small muted" style={{ fontWeight: 600 }}>accuracy</div>
            </div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.03em' }}>
                {Math.round(totalReviews / Math.max(1, range))}
              </div>
              <div className="small muted" style={{ fontWeight: 600 }}>per day avg</div>
            </div>
          </div>
          <ActivityChart data={activity} goal={stats.dailyGoal} />
        </div>
      </div>

      <div className="grid-2 mt-3" style={{ alignItems: 'start' }}>
        <div className="panel">
          <div className="panel-head">
            <h3>Mastery by deck</h3>
          </div>
          <div className="panel-body">
            {decks.length === 0 && <span className="small muted">No decks yet.</span>}
            {decks.map((d) => (
              <div key={d.id} className="hbar" style={{ cursor: 'pointer' }} onClick={() => navigate(`/decks/${d.id}`)}>
                <div className="hbar-top">
                  <span className="flex" style={{ gap: 6 }}>
                    <span aria-hidden="true">{subjectEmoji(d.subject)}</span>
                    <span className="truncate" style={{ maxWidth: 200 }}>{d.title}</span>
                  </span>
                  <span className="v">
                    {d.masteredCount}/{d.cardCount} · {d.progress}%
                  </span>
                </div>
                <div className="progress">
                  <i style={{ width: `${d.progress}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="panel">
          <div className="panel-head">
            <h3>Quiz history</h3>
            <button className="link right" onClick={() => navigate('/quiz')}>
              Take a quiz <Icon name="arrowRight" size={13} />
            </button>
          </div>
          <div className="panel-body">
            {attempts.length === 0 ? (
              <div className="small muted">No quiz attempts yet. Quizzes are a fast way to find gaps.</div>
            ) : (
              attempts.map((a) => (
                <div key={a.id} className="list-row">
                  <div
                    className="avatar"
                    style={{ background: a.score >= 70 ? 'linear-gradient(135deg,#10b981,#059669)' : 'var(--grad)', width: 32, height: 32, fontSize: 11 }}
                  >
                    {a.score}%
                  </div>
                  <div className="lr-main">
                    <div className="lr-title">{a.deckTitle || 'Deck removed'}</div>
                    <div className="lr-sub">
                      {a.type.replace(/_/g, ' ')} · {a.correct}/{a.total} correct · {timeAgo(a.createdAt)}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <div className="panel mt-3">
        <div className="panel-head">
          <h3>What to focus on</h3>
        </div>
        <div className="panel-body" style={{ display: 'grid', gap: 10 }}>
          {[...decks]
            .sort((a, b) => b.dueCount - a.dueCount || b.struggleCount - a.struggleCount)
            .slice(0, 4)
            .map((d) => (
              <div key={d.id} className="flex between" style={{ gap: 10, flexWrap: 'wrap' }}>
                <div className="flex grow" style={{ gap: 10, minWidth: 0 }}>
                  <span className="deck-emoji" style={{ width: 32, height: 32, fontSize: 15 }}>
                    {subjectEmoji(d.subject)}
                  </span>
                  <div style={{ minWidth: 0 }}>
                    <div className="truncate" style={{ fontWeight: 650, fontSize: 13.5 }}>{d.title}</div>
                    <div className="small muted">
                      {plural(d.dueCount, 'card')} due · {d.struggleCount} marked “again” before
                    </div>
                  </div>
                </div>
                <button className="btn btn-sm btn-primary" onClick={() => navigate(`/study/${d.id}`)}>
                  <Icon name="play" size={12} /> Review
                </button>
              </div>
            ))}
          {decks.length === 0 && <span className="small muted">Create a deck to see personalised recommendations.</span>}
        </div>
      </div>
    </div>
  );
}

function Stat({ icon, value, label }) {
  return (
    <div className="stat">
      <div className="stat-icon">
        <Icon name={icon} size={17} />
      </div>
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}
