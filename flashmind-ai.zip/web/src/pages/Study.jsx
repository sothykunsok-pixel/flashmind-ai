import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import Flashcard from '../components/Flashcard.jsx';
import Modal from '../components/Modal.jsx';
import { CenteredLoader, EmptyState, ErrorNote } from '../components/States.jsx';
import { api } from '../lib/api.js';
import { useToast } from '../context/ToastContext.jsx';
import { subjectEmoji, plural } from '../lib/utils.js';

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function Study() {
  const { deckId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [decks, setDecks] = useState(null);
  const [deck, setDeck] = useState(null);
  const [cards, setCards] = useState([]);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [loading, setLoading] = useState(Boolean(deckId));
  const [error, setError] = useState('');
  const [session, setSession] = useState({ again: 0, hard: 0, easy: 0 });
  const [done, setDone] = useState(false);
  const [explain, setExplain] = useState(null);
  const [explaining, setExplaining] = useState(false);
  const [starting, setStarting] = useState(false);

  /* deck picker */
  useEffect(() => {
    if (deckId) return;
    api
      .decks()
      .then(({ decks: d }) => setDecks(d))
      .catch((err) => setError(err.message));
  }, [deckId]);

  const loadDeck = useCallback(async () => {
    if (!deckId) return;
    setLoading(true);
    setError('');
    try {
      const [{ deck: d, cards: cs }] = await Promise.all([api.deck(deckId)]);
      if (!cs.length) {
        setDeck(d);
        setCards([]);
        setLoading(false);
        return;
      }
      setDeck(d);
      setCards(shuffleArray(cs));
      setIndex(0);
      setFlipped(false);
      setSession({ again: 0, hard: 0, easy: 0 });
      setDone(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [deckId]);

  useEffect(() => {
    loadDeck();
  }, [loadDeck]);

  const startSmartQueue = async () => {
    setStarting(true);
    setError('');
    try {
      const { cards: q } = await api.queue({ limit: 50, smart: true });
      if (!q.length) {
        toast.info('No cards available yet — create a deck first.');
        setStarting(false);
        return;
      }
      setDeck({ id: 'mixed', title: 'Smart review', subject: 'All decks', cardCount: q.length });
      setCards(q);
      setIndex(0);
      setFlipped(false);
      setSession({ again: 0, hard: 0, easy: 0 });
      setDone(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setStarting(false);
    }
  };

  const card = cards[index];

  const grade = useCallback(
    async (value) => {
      if (!card) return;
      setSession((s) => ({ ...s, [value]: s[value] + 1 }));
      try {
        await api.review(card.id, value);
      } catch (err) {
        toast.error(err.message);
      }
      if (index + 1 >= cards.length) {
        setDone(true);
      } else {
        setIndex((i) => i + 1);
        setFlipped(false);
      }
    },
    [card, index, cards.length, toast],
  );

  const go = (dir) => {
    setFlipped(false);
    setIndex((i) => Math.min(cards.length - 1, Math.max(0, i + dir)));
  };

  // keyboard shortcuts
  useEffect(() => {
    if (!card || done) return;
    const onKey = (e) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        setFlipped((f) => !f);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        if (flipped) grade('easy');
        else go(1);
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        go(-1);
      } else if (flipped && ['1', '2', '3'].includes(e.key)) {
        grade({ 1: 'again', 2: 'hard', 3: 'easy' }[e.key]);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [card, flipped, done, grade]);

  const onExplain = async (c) => {
    setExplaining(true);
    setExplain({ question: c.question, answer: c.answer, text: '' });
    try {
      const res = await api.explain({ question: c.question, answer: c.answer, language: deck?.language || 'English' });
      setExplain({ question: c.question, answer: c.answer, text: res.explanation });
    } catch (err) {
      setExplain({ question: c.question, answer: c.answer, text: '', error: err.message });
    } finally {
      setExplaining(false);
    }
  };

  const totals = session.again + session.hard + session.easy;
  const accuracy = totals ? Math.round(((session.hard + session.easy) / totals) * 100) : 0;

  /* ── no deck selected → picker ── */
  if (!deckId) {
    return (
      <div className="page">
        <div className="page-head">
          <div>
            <div className="eyebrow">Study mode</div>
            <h1>What do you want to study?</h1>
            <p className="sub">Pick a deck, or let Smart Review pull the cards you struggle with across all decks.</p>
          </div>
          <div className="page-head-actions">
            <button className="btn btn-primary" onClick={startSmartQueue} disabled={starting}>
              {starting ? <span className="spinner" /> : <Icon name="zap" size={15} />}
              Smart review
            </button>
          </div>
        </div>

        <ErrorNote message={error} />

        {decks === null ? (
          <CenteredLoader label="Loading your decks…" />
        ) : decks.length ? (
          <div className="deck-grid">
            {decks.map((d) => (
              <div key={d.id} className="deck-card" onClick={() => navigate(`/study/${d.id}`)} role="button" tabIndex={0}>
                <div className="deck-card-top">
                  <div className="deck-emoji">{subjectEmoji(d.subject)}</div>
                  <div className="grow">
                    <h3 className="deck-title">{d.title}</h3>
                    <div className="deck-meta" style={{ marginTop: 4 }}>
                      <span>{d.subject}</span>
                      <span className="dot" />
                      <span>{plural(d.cardCount, 'card')}</span>
                      {d.dueCount > 0 && (
                        <>
                          <span className="dot" />
                          <span style={{ color: 'var(--brand)', fontWeight: 650 }}>{d.dueCount} due</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="progress">
                  <i style={{ width: `${d.progress}%` }} />
                </div>
                <div className="deck-card-row">
                  <span>{d.progress}% mastered</span>
                  <span className="btn btn-sm btn-soft">
                    <Icon name="play" size={12} /> Study
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            icon="book"
            title="Nothing to study yet"
            message="Create a deck first — then study mode will shuffle the cards and schedule them for you."
            action={
              <Link to="/create" className="btn btn-primary">
                <Icon name="sparkles" size={15} /> Create flashcards
              </Link>
            }
          />
        )}
      </div>
    );
  }

  /* ── studying a deck ── */
  if (loading) return <CenteredLoader label="Shuffling your cards…" />;

  if (error) {
    return (
      <div className="page">
        <ErrorNote message={error} onRetry={loadDeck} />
      </div>
    );
  }

  if (!cards.length) {
    return (
      <div className="page">
        <EmptyState
          icon="layers"
          title="This deck has no cards"
          message="Add cards to this deck, or generate them with AI from your notes."
          action={
            <Link to={`/decks/${deckId}`} className="btn btn-primary">
              Open deck
            </Link>
          }
        />
      </div>
    );
  }

  if (done) {
    return (
      <div className="page">
        <div className="study-wrap">
          <div className="panel panel-pad" style={{ textAlign: 'center' }}>
            <div className="gen-orb" style={{ margin: '6px auto 18px' }}>
              <Icon name="trophy" size={26} />
            </div>
            <h1 style={{ fontSize: 26 }}>Session complete</h1>
            <p className="muted mt-1">
              You reviewed {totals} card{totals === 1 ? '' : 's'} from “{deck?.title}”.
            </p>

            <div className="grid-3 mt-3">
              {[
                ['Again', session.again, 'var(--danger)'],
                ['Hard', session.hard, 'var(--warn)'],
                ['Easy', session.easy, 'var(--success)'],
              ].map(([label, n, color]) => (
                <div key={label} className="panel panel-pad">
                  <div style={{ fontSize: 24, fontWeight: 800, color }}>{n}</div>
                  <div className="stat-label">{label}</div>
                </div>
              ))}
            </div>

            <div className="flex mt-3" style={{ justifyContent: 'center' }}>
              <button
                className="btn"
                onClick={() => {
                  setCards(shuffleArray(cards));
                  setIndex(0);
                  setFlipped(false);
                  setSession({ again: 0, hard: 0, easy: 0 });
                  setDone(false);
                }}
              >
                <Icon name="refresh" size={15} /> Study again
              </button>
              <button className="btn" onClick={() => navigate('/quiz')}>
                <Icon name="quiz" size={15} /> Take a quiz
              </button>
              <button className="btn btn-primary" onClick={() => navigate('/')}>
                Back to dashboard
              </button>
            </div>
            <div className="small muted mt-2">{accuracy}% of this session was recalled without a lapse.</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="study-wrap">
        <div className="study-top">
          <button className="btn btn-sm btn-ghost" onClick={() => navigate('/study')}>
            <Icon name="left" size={14} /> Decks
          </button>
          <div className="grow">
            <div style={{ fontWeight: 700, fontSize: 15 }}>{deck?.title}</div>
            <div className="small muted">
              {deck?.subject} · {cards.length} cards this session
            </div>
          </div>
          <button
            className="btn btn-sm"
            onClick={() => {
              setCards(shuffleArray(cards));
              setIndex(0);
              setFlipped(false);
              toast.info('Cards shuffled.');
            }}
          >
            <Icon name="shuffle" size={14} /> <span className="btn-label">Shuffle</span>
          </button>
          <Link to={`/decks/${deck?.id}`} className="btn btn-sm">
            <Icon name="edit" size={14} /> <span className="btn-label">Deck</span>
          </Link>
        </div>

        <div className="quiz-progress">
          <span>
            {index + 1} of {cards.length}
          </span>
          <div className="progress">
            <i style={{ width: `${((index + (flipped ? 0.5 : 0)) / cards.length) * 100}%` }} />
          </div>
          <span>{Math.round((index / cards.length) * 100)}%</span>
        </div>

        <Flashcard
          card={card}
          flipped={flipped}
          onFlip={() => setFlipped((f) => !f)}
          onExplain={onExplain}
          explaining={explaining}
          index={index}
          total={cards.length}
        />

        <div className="grade-row">
          <button className="grade-btn again" onClick={() => grade('again')} disabled={!flipped && false}>
            Again
            <small>Forgot it · 10 min</small>
          </button>
          <button className="grade-btn hard" onClick={() => grade('hard')}>
            Hard
            <small>Struggled · sooner</small>
          </button>
          <button className="grade-btn easy" onClick={() => grade('easy')}>
            Easy
            <small>Knew it · later</small>
          </button>
        </div>

        <div className="study-controls">
          <button className="btn" onClick={() => go(-1)} disabled={index === 0}>
            <Icon name="left" size={15} /> <span className="btn-label">Previous</span>
          </button>
          <button className="btn grow" onClick={() => setFlipped((f) => !f)}>
            <Icon name="refresh" size={15} /> {flipped ? 'Show question' : 'Show answer'}
          </button>
          <button className="btn" onClick={() => go(1)} disabled={index >= cards.length - 1}>
            <span className="btn-label">Next</span> <Icon name="right" size={15} />
          </button>
        </div>

        <div className="kbd-hint">
          <span>
            <kbd>Space</kbd> flip
          </span>
          <span>
            <kbd>←</kbd> <kbd>→</kbd> navigate
          </span>
          <span>
            <kbd>1</kbd> again · <kbd>2</kbd> hard · <kbd>3</kbd> easy
          </span>
        </div>
      </div>

      <Modal
        open={Boolean(explain)}
        onClose={() => setExplain(null)}
        title="Explain it simply"
        subtitle={`${deck?.language || 'English'} · plain language`}
      >
        {explain && (
          <div style={{ display: 'grid', gap: 12 }}>
            <div className="review-item">
              <div className="rq">{explain.question}</div>
              <div className="ra">{explain.answer}</div>
            </div>
            {explaining ? (
              <div className="flex muted">
                <span className="spinner" /> Thinking of a simpler way to say it…
              </div>
            ) : explain.error ? (
              <div className="alert alert-error">{explain.error}</div>
            ) : (
              <p style={{ lineHeight: 1.65, whiteSpace: 'pre-wrap' }}>{explain.text}</p>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
