import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import { ErrorNote } from '../components/States.jsx';
import { api } from '../lib/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';

const LANGUAGES = [
  'English', 'Spanish', 'French', 'German', 'Portuguese', 'Italian', 'Dutch', 'Polish', 'Swedish',
  'Turkish', 'Russian', 'Arabic', 'Hindi', 'Bengali', 'Indonesian', 'Vietnamese', 'Thai',
  'Chinese (Simplified)', 'Japanese', 'Korean',
];

const SUBJECTS = [
  'Biology', 'Chemistry', 'Physics', 'Mathematics', 'History', 'Geography', 'Economics',
  'Psychology', 'Computer Science', 'Medicine', 'Anatomy', 'Law', 'Literature', 'Languages',
  'Business', 'Philosophy', 'Engineering', 'General',
];

const COUNT_OPTIONS = [5, 10, 20, 30, 50];

export default function Create() {
  const navigate = useNavigate();
  const toast = useToast();
  const { aiStatus } = useAuth();
  const fileRef = useRef(null);
  const dropRef = useRef(null);

  const [step, setStep] = useState('form');
  const [form, setForm] = useState({
    title: '',
    subject: 'General',
    topic: '',
    material: '',
    mode: 'source',
    count: 10,
    difficulty: 'medium',
    language: 'English',
  });
  const [uploading, setUploading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [drag, setDrag] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');
  const [cards, setCards] = useState([]);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [summary, setSummary] = useState(null);
  const [summarizing, setSummarizing] = useState(false);
  const [showSummary, setShowSummary] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e?.target ? e.target.value : e }));

  const handleFile = async (file) => {
    if (!file) return;
    const ok = /\.(pdf|docx|txt|md|text|csv)$/i.test(file.name);
    if (!ok) {
      setError('Upload a PDF, DOCX or TXT file.');
      return;
    }
    setError('');
    setUploading(true);
    try {
      const res = await api.upload(file);
      setUploadedFile({ name: res.filename, chars: res.chars, truncated: res.truncated });
      setForm((f) => ({
        ...f,
        material: f.material.trim() ? `${f.material}\n\n${res.text}` : res.text,
        mode: 'source',
        title: f.title || res.filename.replace(/\.[^.]+$/, ''),
      }));
      toast.success(`Extracted ${res.chars.toLocaleString()} characters from ${res.filename}.`);
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDrag(false);
    handleFile(e.dataTransfer.files?.[0]);
  };

  const summarize = async () => {
    if (form.material.trim().length < 80) {
      setError('Paste at least a few sentences of study material to summarize.');
      return;
    }
    setSummarizing(true);
    setShowSummary(true);
    setError('');
    try {
      const res = await api.summarize({ material: form.material, language: form.language });
      setSummary(res);
    } catch (err) {
      setError(err.message);
    } finally {
      setSummarizing(false);
    }
  };

  const generate = async (e) => {
    e?.preventDefault?.();
    setError('');
    if (!form.material.trim() && !form.topic.trim()) {
      setError('Add a topic or paste some study material to generate cards from.');
      return;
    }
    if (!form.title.trim()) {
      setError('Give your deck a title so you can find it later.');
      return;
    }
    setGenerating(true);
    try {
      const res = await api.generateFlashcards({
        title: form.title,
        topic: form.topic || form.title,
        material: form.material,
        mode: form.mode,
        count: Number(form.count),
        difficulty: form.difficulty,
        language: form.language,
      });
      setCards(res.cards.map((c) => ({ ...c, _key: crypto.randomUUID() })));
      setStep('preview');
      if (res.demo) {
        toast.info('Demo mode: cards were built locally from your text. Add AI_API_KEY for real AI generation.', 6500);
      } else {
        toast.success(`Generated ${res.cards.length} flashcards with ${res.status?.model || 'AI'}.`);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setGenerating(false);
    }
  };

  const save = async () => {
    setSaving(true);
    setError('');
    try {
      const payload = {
        title: form.title.trim(),
        subject: form.subject || 'General',
        language: form.language,
        difficulty: form.difficulty,
        sourceType: form.mode === 'topic' ? 'topic' : uploadedFile ? 'file' : 'notes',
        cards: cards.filter((c) => c.question.trim() && c.answer.trim()),
      };
      if (!payload.cards.length) {
        setError('Keep at least one card with a question and an answer.');
        setSaving(false);
        return;
      }
      const { deck } = await api.createDeck(payload);
      toast.success(`Saved “${deck.title}” with ${deck.cardCount} cards.`);
      navigate(`/decks/${deck.id}`);
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  };

  const updateCard = (key, patch) => setCards((cs) => cs.map((c) => (c._key === key ? { ...c, ...patch } : c)));
  const removeCard = (key) => setCards((cs) => cs.filter((c) => c._key !== key));
  const addCard = () =>
    setCards((cs) => [...cs, { _key: crypto.randomUUID(), question: '', answer: '', explanation: '', difficulty: form.difficulty }]);

  /* ───────────────────────── preview ───────────────────────── */
  if (step === 'preview') {
    return (
      <div className="page">
        <div className="page-head">
          <div>
            <div className="eyebrow">Preview & edit</div>
            <h1>Review your {cards.length} cards</h1>
            <p className="sub">Tweak anything that looks off, delete weak cards, then save the deck to start studying.</p>
          </div>
          <div className="page-head-actions">
            <button className="btn" onClick={() => setStep('form')}>
              <Icon name="left" size={15} /> Back
            </button>
            <button className="btn" onClick={addCard}>
              <Icon name="plus" size={15} /> Add card
            </button>
            <button className="btn btn-primary" onClick={save} disabled={saving}>
              {saving ? <span className="spinner" /> : <Icon name="check" size={15} />}
              Save deck
            </button>
          </div>
        </div>

        <ErrorNote message={error} />

        <div className="panel panel-pad mt-2">
          <div className="flex between flex-wrap" style={{ gap: 10 }}>
            <div className="flex">
              <span className="badge badge-brand">
                <Icon name="sparkles" size={11} /> {cards.length} cards
              </span>
              <span className="badge">{form.subject}</span>
              <span className="badge">{form.difficulty}</span>
              <span className="badge">{form.language}</span>
            </div>
            <span className="small muted">
              {cards.filter((c) => c.edited).length > 0 ? `${cards.filter((c) => c.edited).length} edited` : 'Click a card to edit'}
            </span>
          </div>
        </div>

        <div className="card-list mt-2">
          {cards.map((c, i) => (
            <div key={c._key} className={`card-row ${editing === c._key ? 'editing' : ''}`}>
              <div className="card-row-top">
                <div className="q-index">{i + 1}</div>
                <div className="grow" onClick={() => setEditing(editing === c._key ? null : c._key)} style={{ cursor: 'pointer' }}>
                  <div className="q-text">{c.question || 'Untitled question'}</div>
                </div>
                <div className="c-actions">
                  <button
                    className="icon-btn"
                    title="Edit card"
                    onClick={() => setEditing(editing === c._key ? null : c._key)}
                    aria-label="Edit card"
                  >
                    <Icon name="edit" size={13} />
                  </button>
                  <button className="icon-btn danger" title="Delete card" onClick={() => removeCard(c._key)} aria-label="Delete card">
                    <Icon name="trash" size={13} />
                  </button>
                </div>
              </div>

              {editing === c._key ? (
                <div style={{ display: 'grid', gap: 10, paddingLeft: 34 }}>
                  <div className="field">
                    <label className="label">Question</label>
                    <textarea
                      className="textarea"
                      style={{ minHeight: 70 }}
                      value={c.question}
                      onChange={(e) => updateCard(c._key, { question: e.target.value, edited: true })}
                    />
                  </div>
                  <div className="field">
                    <label className="label">Answer</label>
                    <textarea
                      className="textarea"
                      style={{ minHeight: 90 }}
                      value={c.answer}
                      onChange={(e) => updateCard(c._key, { answer: e.target.value, edited: true })}
                    />
                  </div>
                  <div className="field">
                    <label className="label">Explanation / hint (optional)</label>
                    <input
                      className="input"
                      value={c.explanation || ''}
                      onChange={(e) => updateCard(c._key, { explanation: e.target.value, edited: true })}
                    />
                  </div>
                  <div className="row">
                    <select
                      className="select"
                      style={{ width: 150 }}
                      value={c.difficulty}
                      onChange={(e) => updateCard(c._key, { difficulty: e.target.value })}
                    >
                      <option value="easy">Easy</option>
                      <option value="medium">Medium</option>
                      <option value="hard">Hard</option>
                    </select>
                    <button className="btn btn-sm btn-primary" onClick={() => setEditing(null)}>
                      Done
                    </button>
                  </div>
                </div>
              ) : (
                <div className="a-text">{c.answer}</div>
              )}
            </div>
          ))}
        </div>

        <div className="flex mt-3" style={{ justifyContent: 'center', gap: 10, flexWrap: 'wrap' }}>
          <button className="btn" onClick={addCard}>
            <Icon name="plus" size={15} /> Add another card
          </button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? <span className="spinner" /> : <Icon name="check" size={15} />} Save deck
          </button>
        </div>
      </div>
    );
  }

  /* ───────────────────────── form ───────────────────────── */
  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="eyebrow">AI generator</div>
          <h1>Create flashcards</h1>
          <p className="sub">
            Paste your notes, upload a PDF or DOCX, or just describe a topic. FlashMind extracts the key facts and writes
            the questions for you.
          </p>
        </div>
      </div>

      <ErrorNote message={error} />

      <form className="create-grid" onSubmit={generate} style={{ marginTop: 16 }}>
        <div className="panel panel-pad" style={{ display: 'grid', gap: 16 }}>
          <div className="grid-2">
            <div className="field">
              <label className="label" htmlFor="title">
                Deck title <span className="req">*</span>
              </label>
              <input
                id="title"
                className="input"
                value={form.title}
                onChange={set('title')}
                placeholder="e.g. Cellular Respiration — Chapter 7"
              />
            </div>
            <div className="field">
              <label className="label" htmlFor="subject">
                Subject
              </label>
              <input
                id="subject"
                className="input"
                list="subject-list"
                value={form.subject}
                onChange={set('subject')}
                placeholder="Biology"
              />
              <datalist id="subject-list">
                {SUBJECTS.map((s) => (
                  <option key={s} value={s} />
                ))}
              </datalist>
            </div>
          </div>

          <div className="segmented" style={{ justifySelf: 'start' }}>
            <button type="button" className={form.mode === 'source' ? 'on' : ''} onClick={() => setForm((f) => ({ ...f, mode: 'source' }))}>
              <Icon name="file" size={14} /> From my material
            </button>
            <button type="button" className={form.mode === 'topic' ? 'on' : ''} onClick={() => setForm((f) => ({ ...f, mode: 'topic' }))}>
              <Icon name="sparkles" size={14} /> From a topic
            </button>
          </div>

          {form.mode === 'topic' ? (
            <div className="field">
              <label className="label" htmlFor="topic">
                Topic or subject
              </label>
              <input
                id="topic"
                className="input"
                value={form.topic}
                onChange={set('topic')}
                placeholder="e.g. The causes of World War I"
              />
              <span className="hint">
                The AI will build cards from general knowledge. Switch to “From my material” if you need strict grounding.
              </span>
            </div>
          ) : (
            <div className="field">
              <label className="label" htmlFor="material">
                Study material <span className="req">*</span>
              </label>
              <textarea
                id="material"
                className="textarea"
                value={form.material}
                onChange={set('material')}
                placeholder="Paste lecture notes, a textbook section, or a summary of the topic…&#10;&#10;Tip: 300–5,000 words gives the best cards."
                style={{ minHeight: 180 }}
              />
              <div className="flex between">
                <span className="hint">{form.material.trim() ? `${form.material.trim().length.toLocaleString()} characters` : 'No material yet'}</span>
                <button type="button" className="btn btn-sm" onClick={summarize} disabled={summarizing}>
                  {summarizing ? <span className="spinner" /> : <Icon name="bulb" size={13} />}
                  Smart summarize
                </button>
              </div>
            </div>
          )}

          <div
            ref={dropRef}
            className={`dropzone ${drag ? 'drag' : ''}`}
            onClick={() => fileRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault();
              setDrag(true);
            }}
            onDragLeave={() => setDrag(false)}
            onDrop={onDrop}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && fileRef.current?.click()}
          >
            {uploading ? (
              <>
                <span className="spinner lg" style={{ color: 'var(--brand)' }} />
                <strong>Reading your file…</strong>
                <span>Extracting text from PDF / DOCX</span>
              </>
            ) : (
              <>
                <Icon name="upload" size={22} style={{ color: 'var(--brand)' }} />
                <strong>{uploadedFile ? uploadedFile.name : 'Upload a PDF, DOCX or TXT file'}</strong>
                <span>
                  {uploadedFile
                    ? `${uploadedFile.chars.toLocaleString()} characters extracted${uploadedFile.truncated ? ' · will be trimmed for the AI' : ''} — click to replace`
                    : 'Drag & drop, or click to browse · max 15 MB'}
                </span>
              </>
            )}
          </div>
          <input
            ref={fileRef}
            type="file"
            accept=".pdf,.docx,.txt,.md,application/pdf,text/plain"
            hidden
            onChange={(e) => {
              handleFile(e.target.files?.[0]);
              e.target.value = '';
            }}
          />

          <div className="grid-3">
            <div className="field">
              <label className="label" htmlFor="count">
                Number of cards
              </label>
              <select id="count" className="select" value={form.count} onChange={set('count')}>
                {COUNT_OPTIONS.map((n) => (
                  <option key={n} value={n}>
                    {n} cards
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label className="label" htmlFor="lang">
                Language
              </label>
              <select id="lang" className="select" value={form.language} onChange={set('language')}>
                {LANGUAGES.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label className="label">Difficulty</label>
              <div className="segmented" style={{ width: '100%' }}>
                {['easy', 'medium', 'hard'].map((d) => (
                  <button
                    type="button"
                    key={d}
                    className={form.difficulty === d ? 'on' : ''}
                    style={{ flex: 1, justifyContent: 'center', textTransform: 'capitalize' }}
                    onClick={() => setForm((f) => ({ ...f, difficulty: d }))}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button className="btn btn-primary btn-lg btn-block" type="submit" disabled={generating}>
            {generating ? <span className="spinner" /> : <Icon name="sparkles" size={18} />}
            {generating ? 'Generating flashcards…' : 'Generate Flashcards with AI'}
          </button>
          <span className="hint center">
            {aiStatus.configured
              ? `Powered by ${aiStatus.model}. Generation usually takes 10–40 seconds.`
              : 'Demo mode: cards are generated locally from your text until an AI key is configured.'}
          </span>
        </div>

        <div style={{ display: 'grid', gap: 16 }}>
          {generating && (
            <div className="panel panel-pad">
              <div className="gen-overlay">
                <div className="gen-orb">
                  <Icon name="sparkles" size={26} />
                </div>
                <div>
                  <div style={{ fontWeight: 700 }}>Analysing your material…</div>
                  <div className="gen-steps">
                    <div className="on">1 · Reading and segmenting the source</div>
                    <div>2 · Extracting key concepts &amp; definitions</div>
                    <div>3 · Writing question / answer pairs</div>
                    <div>4 · Removing duplicates and weak cards</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {showSummary && (
            <div className="panel">
              <div className="panel-head">
                <h3>Smart summary</h3>
                <button className="icon-btn right" onClick={() => setShowSummary(false)} aria-label="Close summary">
                  <Icon name="x" size={14} />
                </button>
              </div>
              <div className="panel-body" style={{ display: 'grid', gap: 12, maxHeight: 420, overflow: 'auto' }}>
                {summarizing ? (
                  <div className="flex" style={{ color: 'var(--muted)' }}>
                    <span className="spinner" /> Summarizing…
                  </div>
                ) : summary ? (
                  <>
                    <p className="small" style={{ lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
                      {summary.summary}
                    </p>
                    {summary.keyConcepts?.length > 0 && (
                      <div>
                        <div className="label" style={{ marginBottom: 8 }}>
                          Key concepts
                        </div>
                        <div style={{ display: 'grid', gap: 8 }}>
                          {summary.keyConcepts.map((k, i) => (
                            <div key={i} className="review-item">
                              <div className="rq">{k.term}</div>
                              <div className="ra">{k.definition}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    <button
                      className="btn btn-sm"
                      onClick={() => {
                        setForm((f) => ({ ...f, material: `${summary.summary}\n\n${f.material}` }));
                        toast.success('Summary added to the top of your material.');
                      }}
                    >
                      <Icon name="plus" size={13} /> Prepend summary to material
                    </button>
                  </>
                ) : (
                  <span className="small muted">No summary yet.</span>
                )}
              </div>
            </div>
          )}

          <div className="panel panel-pad" style={{ display: 'grid', gap: 12 }}>
            <h3 style={{ fontSize: 14.5 }}>What makes good source material</h3>
            {[
              ['Lots of concrete facts', 'Definitions, dates, formulas and processes turn into the best cards.'],
              ['One deck per topic', 'Small focused decks are easier to review than one giant one.'],
              ['Keep it real', 'In “From my material” mode the AI will not invent facts that are not in your text.'],
            ].map(([t, d]) => (
              <div key={t} className="flex" style={{ alignItems: 'flex-start', gap: 10 }}>
                <span className="stat-icon" style={{ width: 26, height: 26, borderRadius: 8, marginBottom: 0, flex: 'none' }}>
                  <Icon name="check" size={13} />
                </span>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 650 }}>{t}</div>
                  <div className="small muted" style={{ lineHeight: 1.5 }}>
                    {d}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className={`ai-note ${aiStatus.configured ? '' : 'solid'}`}>
            <Icon name={aiStatus.configured ? 'zap' : 'bulb'} size={16} style={{ flex: 'none', marginTop: 1 }} />
            <div>
              <strong>{aiStatus.configured ? 'AI connected' : 'AI not configured — demo mode'}</strong>
              <div style={{ marginTop: 3 }}>
                {aiStatus.configured
                  ? `Requests go through your server to ${aiStatus.providerHost || 'your provider'} using ${aiStatus.model}. Your API key is never sent to the browser.`
                  : 'Add AI_API_KEY to your .env file and restart the server for real AI generation. Everything else works now.'}
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
