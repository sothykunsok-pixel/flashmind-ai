import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import Icon from '../components/Icons.jsx';
import Flashcard from '../components/Flashcard.jsx';
import { CenteredLoader, ErrorNote } from '../components/States.jsx';
import { api } from '../lib/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { subjectEmoji, plural } from '../lib/utils.js';

export default function SharedDeck() {
  const { slug } = useParams();
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const [deck, setDeck] = useState(null);
  const [cards, setCards] = useState([]);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [cloning, setCloning] = useState(false);

  useEffect(() => {
    api
      .publicDeck(slug)
      .then(({ deck: d, cards: c }) => {
        setDeck(d);
        setCards(c);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [slug]);

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === ' ') setFlipped((f) => !f);
      if (e.key === 'ArrowRight') {
        setIndex((i) => Math.min(cards.length - 1, i + 1));
        setFlipped(false);
      }
      if (e.key === 'ArrowLeft') {
        setIndex((i) => Math.max(0, i - 1));
        setFlipped(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [cards.length]);

  const copyDeck = async () => {
    if (!user) return navigate('/login');
    setCloning(true);
    try {
      const { deck: copy } = await api.cloneDeck(slug);
      toast.success(`Added “${copy.title}” to your library.`);
      navigate(`/decks/${copy.id}`);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setCloning(false);
    }
  };

  if (loading) return <CenteredLoader label="Loading shared deck…" />;

  if (error) {
    return (
      <div className="page" style={{ paddingTop: 60 }}>
        <div className="empty" style={{ maxWidth: 520, margin: '0 auto' }}>
          <div className="empty-icon">
            <Icon name="lock" size={24} />
          </div>
          <h3>This deck is not available</h3>
          <p>{error}</p>
          <Link to={user ? '/' : '/login'} className="btn btn-primary">
            {user ? 'Back to dashboard' : 'Log in to FlashMind'}
          </Link>
        </div>
      </div>
    );
  }

  const card = cards[index];

  return (
    <div className="page">
      <div className="study-wrap">
        <div className="panel panel-pad" style={{ display: 'grid', gap: 12, marginBottom: 18 }}>
          <div className="flex" style={{ gap: 12, alignItems: 'flex-start' }}>
            <div className="deck-emoji" style={{ width: 46, height: 46, fontSize: 21 }}>
              {subjectEmoji(deck.subject)}
            </div>
            <div className="grow">
              <h1 style={{ fontSize: 24 }}>{deck.title}</h1>
              <div className="deck-meta" style={{ marginTop: 6 }}>
                <span className="badge badge-brand">{deck.subject}</span>
                <span className="badge">{deck.difficulty}</span>
                <span>{plural(deck.cardCount, 'card')}</span>
                <span className="dot" />
                <span>shared by {deck.author}</span>
              </div>
              {deck.description && <p className="small muted mt-1" style={{ lineHeight: 1.55 }}>{deck.description}</p>}
            </div>
          </div>
          <div className="flex" style={{ gap: 10, flexWrap: 'wrap' }}>
            <button className="btn btn-primary" onClick={copyDeck} disabled={cloning}>
              {cloning ? <span className="spinner" /> : <Icon name="copy" size={15} />}
              {user ? 'Copy to my library' : 'Log in to copy this deck'}
            </button>
            {user && (
              <Link to="/" className="btn">
                Dashboard
              </Link>
            )}
          </div>
        </div>

        {cards.length === 0 ? (
          <div className="empty">
            <h3>This deck has no cards yet</h3>
          </div>
        ) : (
          <>
            <div className="quiz-progress">
              <span>
                {index + 1} of {cards.length}
              </span>
              <div className="progress">
                <i style={{ width: `${((index + 1) / cards.length) * 100}%` }} />
              </div>
              <span>preview</span>
            </div>

            <Flashcard
              card={card}
              flipped={flipped}
              onFlip={() => setFlipped((f) => !f)}
              index={index}
              total={cards.length}
            />

            <div className="study-controls">
              <button
                className="btn"
                onClick={() => {
                  setIndex((i) => Math.max(0, i - 1));
                  setFlipped(false);
                }}
                disabled={index === 0}
              >
                <Icon name="left" size={15} /> <span className="btn-label">Previous</span>
              </button>
              <button className="btn grow" onClick={() => setFlipped((f) => !f)}>
                <Icon name="refresh" size={15} /> {flipped ? 'Show question' : 'Show answer'}
              </button>
              <button
                className="btn"
                onClick={() => {
                  setIndex((i) => Math.min(cards.length - 1, i + 1));
                  setFlipped(false);
                }}
                disabled={index >= cards.length - 1}
              >
                <span className="btn-label">Next</span> <Icon name="right" size={15} />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
