import { useMemo, useState } from 'react';

function dayLabel(iso) {
  const d = new Date(`${iso}T00:00:00`);
  return d.toLocaleDateString(undefined, { weekday: 'short' });
}

export default function ActivityChart({ data = [], goal = 20, height = 220 }) {
  const [hover, setHover] = useState(null);
  const W = 720;
  const H = height;
  const padL = 34;
  const padR = 8;
  const padT = 14;
  const padB = 30;
  const innerW = W - padL - padR;
  const innerH = H - padT - padB;

  const max = Math.max(goal, ...data.map((d) => d.reviews), 4);
  const step = innerW / Math.max(1, data.length);
  const x = (i) => padL + step * i + step / 2;
  const y = (v) => padT + innerH - (v / max) * innerH;

  const { line, area, ticks } = useMemo(() => {
    if (!data.length) return { line: '', area: '', ticks: [] };
    const pts = data.map((d, i) => [x(i), y(d.reviews)]);
    // smooth curve (catmull-rom-ish)
    let linePath = `M ${pts[0][0]} ${pts[0][1]}`;
    for (let i = 1; i < pts.length; i++) {
      const [x0, y0] = pts[i - 1];
      const [x1, y1] = pts[i];
      const cx = (x0 + x1) / 2;
      linePath += ` C ${cx} ${y0}, ${cx} ${y1}, ${x1} ${y1}`;
    }
    const areaPath = `${linePath} L ${pts[pts.length - 1][0]} ${padT + innerH} L ${pts[0][0]} ${padT + innerH} Z`;
    const tickVals = [0, Math.round(max / 2), max];
    return { line: linePath, area: areaPath, ticks: tickVals };
  }, [data, max, height]);

  if (!data.length) return <div className="skeleton" style={{ height }} />;

  const goalY = y(goal);

  return (
    <div style={{ position: 'relative' }}>
      <svg viewBox={`0 0 ${W} ${H}`} className="chart" role="img" aria-label="Study activity over the last days">
        <defs>
          <linearGradient id="chartArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.34" />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="chartLine" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#8b5cf6" />
            <stop offset="100%" stopColor="#3b82f6" />
          </linearGradient>
        </defs>

        {ticks.map((t) => (
          <g key={t}>
            <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} stroke="var(--border)" strokeDasharray="3 5" />
            <text x={padL - 8} y={y(t) + 4} textAnchor="end" fontSize="10" fill="var(--muted)" fontWeight="600">
              {t}
            </text>
          </g>
        ))}

        {goal > 0 && goal <= max && (
          <line x1={padL} x2={W - padR} y1={goalY} y2={goalY} stroke="var(--brand)" strokeOpacity="0.5" strokeDasharray="6 4" />
        )}

        <path d={area} fill="url(#chartArea)" />
        <path d={line} fill="none" stroke="url(#chartLine)" strokeWidth="2.6" strokeLinecap="round" />

        {data.map((d, i) => (
          <g key={d.date}>
            <rect
              x={x(i) - step / 2}
              y={padT}
              width={step}
              height={innerH}
              fill="transparent"
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
            />
            {(hover === i || d.reviews > 0) && (
              <circle
                cx={x(i)}
                cy={y(d.reviews)}
                r={hover === i ? 5.5 : 3.4}
                fill="var(--surface)"
                stroke="url(#chartLine)"
                strokeWidth="2.4"
              />
            )}
            <text x={x(i)} y={H - 10} textAnchor="middle" fontSize="10.5" fill="var(--muted)" fontWeight="600">
              {dayLabel(d.date)}
            </text>
          </g>
        ))}
      </svg>

      {hover !== null && (
        <div
          style={{
            position: 'absolute',
            left: `${((x(hover) / W) * 100).toFixed(2)}%`,
            top: 4,
            transform: 'translateX(-50%)',
            background: 'var(--surface)',
            border: '1px solid var(--border)',
            boxShadow: 'var(--shadow-sm)',
            borderRadius: 10,
            padding: '6px 10px',
            fontSize: 11.5,
            fontWeight: 600,
            pointerEvents: 'none',
            whiteSpace: 'nowrap',
          }}
        >
          {new Date(`${data[hover].date}T00:00:00`).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} ·{' '}
          {data[hover].reviews} reviews
          {data[hover].accuracy !== null ? ` · ${data[hover].accuracy}% correct` : ''}
        </div>
      )}
    </div>
  );
}
