import Icon from './Icons.jsx';

export default function Flashcard({ card, flipped, onFlip, onExplain, explaining, index, total }) {
  if (!card) return null;
  const diffClass =
    card.difficulty === 'easy' ? 'badge-success' : card.difficulty === 'hard' ? 'badge-danger' : 'badge-warn';

  return (
    <button
      type="button"
      className="flashcard-scene"
      onClick={onFlip}
      aria-label={flipped ? 'Show question' : 'Show answer'}
    >
      <div className={`flashcard ${flipped ? 'flipped' : ''}`}>
        <div className="face front" aria-hidden={flipped}>
          <div className="face-label">
            Question
            <span className={`badge ${diffClass}`}>{card.difficulty}</span>
            {card.reps > 0 && <span className="badge">seen {card.reps}×</span>}
          </div>
          <div className="face-content">
            <div className="q">{card.question}</div>
          </div>
          <div className="face-foot">
            <span className="flip-hint">
              <Icon name="refresh" size={13} /> Click the card or press <kbd>Space</kbd> to flip
            </span>
            <span>
              {index + 1} of {total}
            </span>
          </div>
        </div>

        <div className="face back" aria-hidden={!flipped}>
          <div className="face-label">
            Answer
            <span className={`badge ${diffClass}`}>{card.difficulty}</span>
          </div>
          <div className="face-content">
            <div>
              <div className="a">{card.answer}</div>
              {card.explanation && (
                <div
                  className="small"
                  style={{
                    marginTop: 16,
                    padding: '10px 14px',
                    borderRadius: 12,
                    background: 'var(--surface-2)',
                    color: 'var(--text-2)',
                    maxWidth: '46ch',
                    marginInline: 'auto',
                    lineHeight: 1.55,
                  }}
                >
                  <Icon name="bulb" size={13} style={{ verticalAlign: '-2px', marginRight: 6 }} />
                  {card.explanation}
                </div>
              )}
            </div>
          </div>
          <div className="face-foot">
            <button
              type="button"
              className="btn btn-sm btn-soft"
              disabled={explaining}
              onClick={(e) => {
                e.stopPropagation();
                onExplain?.(card);
              }}
            >
              {explaining ? <span className="spinner" /> : <Icon name="sparkles" size={13} />}
              Explain simply
            </button>
            <span>How well did you remember?</span>
          </div>
        </div>
      </div>
    </button>
  );
}
