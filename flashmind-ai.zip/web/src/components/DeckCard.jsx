import Icon from './Icons.jsx';
import { subjectEmoji, timeAgo, plural } from '../lib/utils.js';

export default function DeckCard({ deck, onOpen, onStudy, onEdit, onDuplicate, onDelete }) {
  const stop = (e, fn) => {
    e.stopPropagation();
    fn?.(deck);
  };

  return (
    <article
      className="deck-card"
      onClick={() => onOpen?.(deck)}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onOpen?.(deck))}
      tabIndex={0}
      role="button"
      aria-label={`Open deck ${deck.title}`}
    >
      <div className="deck-card-actions">
        <button className="icon-btn" title="Study deck" onClick={(e) => stop(e, onStudy)} aria-label="Study deck">
          <Icon name="play" size={13} />
        </button>
        <button className="icon-btn" title="Edit deck" onClick={(e) => stop(e, onEdit)} aria-label="Edit deck">
          <Icon name="edit" size={13} />
        </button>
        <button className="icon-btn" title="Duplicate deck" onClick={(e) => stop(e, onDuplicate)} aria-label="Duplicate deck">
          <Icon name="copy" size={13} />
        </button>
        <button
          className="icon-btn danger"
          title="Delete deck"
          onClick={(e) => stop(e, onDelete)}
          aria-label="Delete deck"
        >
          <Icon name="trash" size={13} />
        </button>
      </div>

      <div className="deck-card-top">
        <div className="deck-emoji" aria-hidden="true">
          {subjectEmoji(deck.subject)}
        </div>
        <div className="grow" style={{ paddingRight: 4 }}>
          <h3 className="deck-title">{deck.title}</h3>
          <div className="deck-meta" style={{ marginTop: 4 }}>
            <span>{deck.subject}</span>
            <span className="dot" />
            <span className="badge">{deck.difficulty}</span>
            {deck.isPublic && (
              <span className="badge badge-info" title="Public deck">
                <Icon name="globe" size={10} /> public
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="deck-meta">
        <Icon name="layers" size={13} />
        {plural(deck.cardCount, 'card')}
        {deck.dueCount > 0 && (
          <>
            <span className="dot" />
            <span style={{ color: 'var(--brand)', fontWeight: 650 }}>{deck.dueCount} due</span>
          </>
        )}
        <span className="dot" />
        <span>{deck.lastStudiedAt ? `studied ${timeAgo(deck.lastStudiedAt)}` : 'not studied yet'}</span>
      </div>

      <div className="deck-card-foot">
        <div className="progress" aria-hidden="true">
          <i style={{ width: `${deck.progress}%` }} />
        </div>
        <div className="deck-card-row">
          <span>{deck.progress}% mastered</span>
          <span>{deck.masteredCount}/{deck.cardCount}</span>
        </div>
      </div>
    </article>
  );
}
