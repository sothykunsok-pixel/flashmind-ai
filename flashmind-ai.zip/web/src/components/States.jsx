import Icon from './Icons.jsx';

export function EmptyState({ icon = 'layers', title, message, action }) {
  return (
    <div className="empty">
      <div className="empty-icon">
        <Icon name={icon} size={24} />
      </div>
      <h3>{title}</h3>
      {message && <p>{message}</p>}
      {action}
    </div>
  );
}

export function Skeleton({ h = 16, w = '100%', r = 8, style }) {
  return <div className="skeleton" style={{ height: h, width: w, borderRadius: r, ...style }} />;
}

export function DeckGridSkeleton({ n = 6 }) {
  return (
    <div className="deck-grid">
      {Array.from({ length: n }).map((_, i) => (
        <div key={i} className="panel panel-pad" style={{ display: 'grid', gap: 12 }}>
          <div className="flex">
            <Skeleton h={40} w={40} r={12} />
            <div style={{ flex: 1, display: 'grid', gap: 6 }}>
              <Skeleton h={14} w="75%" />
              <Skeleton h={11} w="45%" />
            </div>
          </div>
          <Skeleton h={11} w="60%" />
          <Skeleton h={6} />
        </div>
      ))}
    </div>
  );
}

export function StatSkeleton({ n = 4 }) {
  return (
    <div className="stat-grid">
      {Array.from({ length: n }).map((_, i) => (
        <div key={i} className="stat">
          <Skeleton h={34} w={34} r={10} />
          <div style={{ height: 12 }} />
          <Skeleton h={24} w="55%" />
          <div style={{ height: 8 }} />
          <Skeleton h={11} w="70%" />
        </div>
      ))}
    </div>
  );
}

export function CenteredLoader({ label = 'Loading…' }) {
  return (
    <div style={{ display: 'grid', placeItems: 'center', gap: 12, padding: '70px 20px', color: 'var(--muted)' }}>
      <span className="spinner lg" style={{ color: 'var(--brand)' }} />
      <span className="small" style={{ fontWeight: 600 }}>
        {label}
      </span>
    </div>
  );
}

export function ErrorNote({ message, onRetry }) {
  if (!message) return null;
  return (
    <div className="alert alert-error">
      <Icon name="alert" size={16} style={{ flex: 'none', marginTop: 1 }} />
      <div className="grow">{message}</div>
      {onRetry && (
        <button className="btn btn-sm" onClick={onRetry} style={{ flex: 'none' }}>
          <Icon name="refresh" size={13} /> Retry
        </button>
      )}
    </div>
  );
}
