import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import Icon from './Icons.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { initials } from '../lib/utils.js';

const NAV = [
  { to: '/', label: 'Dashboard', icon: 'dashboard', end: true },
  { to: '/decks', label: 'My Flashcards', icon: 'layers' },
  { to: '/create', label: 'Create Flashcards', icon: 'sparkles' },
  { to: '/study', label: 'Study Mode', icon: 'book' },
  { to: '/quiz', label: 'AI Quiz', icon: 'quiz' },
  { to: '/progress', label: 'Progress', icon: 'progress' },
  { to: '/explore', label: 'Explore Decks', icon: 'globe' },
];

const TITLES = {
  '/': 'Dashboard',
  '/decks': 'My Flashcards',
  '/create': 'Create Flashcards',
  '/study': 'Study Mode',
  '/quiz': 'AI Quiz',
  '/progress': 'Progress',
  '/settings': 'Settings',
  '/explore': 'Explore Decks',
};

export default function Layout() {
  const { user, logout, aiStatus, theme, setTheme } = useAuth();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => setOpen(false), [location.pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 6);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const title =
    TITLES[location.pathname] ||
    (location.pathname.startsWith('/decks/')
      ? 'Deck'
      : location.pathname.startsWith('/study/')
        ? 'Study Mode'
        : location.pathname.startsWith('/quiz/')
          ? 'AI Quiz'
          : 'FlashMind AI');

  const toggleTheme = () => setTheme(theme === 'dark' ? 'light' : 'dark');

  return (
    <div className="app">
      <aside className={`sidebar ${open ? 'open' : ''}`} aria-label="Main navigation">
        <div className="brand">
          <div className="brand-mark">
            <img src="/logo-mark-white.png" alt="" style={{ height: 22, width: 'auto' }} />
          </div>
          <div>
            <div className="brand-name">
              Flash<span>Mind</span> AI
            </div>
            <div className="brand-sub">Study smarter</div>
          </div>
          <button className="icon-btn topbar-menu right" onClick={() => setOpen(false)} aria-label="Close menu">
            <Icon name="x" size={15} />
          </button>
        </div>

        <nav style={{ display: 'grid', gap: 2 }}>
          {NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
            >
              <Icon name={item.icon} size={17} />
              {item.label}
            </NavLink>
          ))}
          <div className="nav-group-label">Account</div>
          <NavLink to="/settings" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <Icon name="settings" size={17} />
            Settings
          </NavLink>
        </nav>

        <div className="sidebar-foot">
          <div className="side-card">
            <h4>
              <Icon name={aiStatus.configured ? 'zap' : 'bulb'} size={14} />
              {aiStatus.configured ? 'AI connected' : 'Demo mode'}
            </h4>
            <p>
              {aiStatus.configured
                ? `Generating with ${aiStatus.model}.`
                : 'Add an AI_API_KEY in .env to generate real AI flashcards.'}
            </p>
          </div>

          <div className="user-chip">
            <div className="avatar">{initials(user?.name)}</div>
            <div className="u-meta">
              <div className="u-name">{user?.name}</div>
              <div className="u-mail">{user?.email}</div>
            </div>
            <button
              className="icon-btn"
              title="Log out"
              aria-label="Log out"
              onClick={async () => {
                await logout();
                navigate('/login');
              }}
            >
              <Icon name="logout" size={15} />
            </button>
          </div>
        </div>
      </aside>

      {open && <div className="sidebar-scrim" onClick={() => setOpen(false)} />}

      <div className="main">
        <header className={`topbar ${scrolled ? 'scrolled' : ''}`}>
          <button className="icon-btn topbar-menu" onClick={() => setOpen(true)} aria-label="Open menu">
            <Icon name="menu" size={16} />
          </button>
          <div className="topbar-title">{title}</div>
          <div className="topbar-spacer" />
          <div className="flex" style={{ gap: 8 }}>
            <button className="icon-btn" onClick={toggleTheme} aria-label="Toggle dark mode" title="Toggle theme">
              <Icon name={theme === 'dark' ? 'sun' : 'moon'} size={16} />
            </button>
            <button className="btn btn-primary btn-sm" onClick={() => navigate('/create')}>
              <Icon name="plus" size={15} />
              New deck
            </button>
          </div>
        </header>

        <main>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
